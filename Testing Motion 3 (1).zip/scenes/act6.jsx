// Act 6 — The Close (36s → 44s)

function Act6Close() {
  const act = React.useContext(SpriteContext);
  const t = act.localTime;
  const { time } = useTimeline();

  const badgeP = clamp(t / 0.5, 0, 1);
  const subP = clamp((t - 2.8) / 0.8, 0, 1);
  const ctaP = clamp((t - 3.4) / 0.8, 0, 1);
  const trustP = clamp((t - 4.5) / 0.8, 0, 1);

  // Pulse on CTA
  const pulse = 1 + Math.sin(time * 3) * 0.02;
  const pulseGlow = 0.4 + Math.sin(time * 3) * 0.2;

  return (
    <React.Fragment>
      <div style={{ position: 'absolute', inset: 0, background: M.navy }}/>

      {/* Moving cinematic light rays */}
      <div style={{
        position: 'absolute', inset: 0,
        background: `
          radial-gradient(ellipse 80% 60% at ${20 + t * 4}% 30%, rgba(212,169,66,0.22) 0%, transparent 50%),
          radial-gradient(ellipse 60% 80% at ${80 - t * 3}% 70%, rgba(230,57,70,0.12) 0%, transparent 50%)
        `,
      }}/>

      {/* Moving light streaks */}
      {[...Array(8)].map((_, i) => {
        const speed = 20 + i * 8;
        const x = ((t * speed + i * 240) % 2200) - 200;
        return (
          <div key={i} style={{
            position: 'absolute',
            left: x,
            top: 80 + i * 120,
            width: 180,
            height: 1,
            background: `linear-gradient(90deg, transparent, ${i % 2 ? M.gold : M.off}, transparent)`,
            opacity: 0.5,
            transform: `rotate(-8deg)`,
          }}/>
        );
      })}

      {/* Section label */}
      <div style={{ position: 'absolute', left: 120, top: 120, opacity: badgeP, transform: `translateY(${(1 - badgeP) * 10}px)` }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
          <div style={{ width: 40, height: 1, background: M.gold }}/>
          <div style={{ fontFamily: M.mono, fontSize: 13, color: M.gold, letterSpacing: '0.25em' }}>
            06 / THE CLOSE
          </div>
        </div>
      </div>

      {/* Massive headline kinetic */}
      <div style={{ position: 'absolute', left: 120, top: 260, right: 120 }}>
        <KineticLine
          text="Your next post"
          start={0.3}
          perWord={0.12}
          size={120}
          weight={700}
          color={M.off}
          font={M.display}
          style={{ lineHeight: 0.95, letterSpacing: '-0.035em' }}
        />
        <div style={{ marginTop: 8 }}>
          <KineticLine
            text="shouldn't look like a post."
            start={0.7}
            perWord={0.1}
            size={120}
            weight={700}
            color={M.off}
            font={M.display}
            style={{ lineHeight: 0.95, letterSpacing: '-0.035em' }}
          />
        </div>
        <div style={{
          marginTop: 30,
          fontFamily: M.display,
          fontSize: 60,
          fontWeight: 400,
          fontStyle: 'italic',
          color: M.gold,
          letterSpacing: '-0.02em',
          lineHeight: 1,
          opacity: subP,
          transform: `translateY(${(1 - subP) * 20}px)`,
        }}>
          It should look like a premiere.
        </div>
      </div>

      {/* CTA row */}
      <div style={{
        position: 'absolute',
        left: 120, top: 720,
        display: 'flex', gap: 20, alignItems: 'center',
        opacity: ctaP,
        transform: `translateY(${(1 - ctaP) * 16}px)`,
      }}>
        <button style={{
          padding: '22px 38px',
          background: M.red,
          color: M.off,
          border: 'none',
          fontFamily: M.body,
          fontSize: 18,
          fontWeight: 700,
          letterSpacing: '0.05em',
          cursor: 'pointer',
          transform: `scale(${pulse})`,
          boxShadow: `0 0 40px rgba(230,57,70,${pulseGlow}), 0 10px 30px rgba(0,0,0,0.4)`,
          willChange: 'transform',
        }}>
          BOOK YOUR CREATIVE CALL →
        </button>
        <button style={{
          padding: '22px 32px',
          background: 'transparent',
          color: M.off,
          border: `1px solid ${M.off}`,
          fontFamily: M.body,
          fontSize: 18,
          fontWeight: 500,
          letterSpacing: '0.05em',
          cursor: 'pointer',
        }}>
          See Sample Reel
        </button>
      </div>

      {/* Trust row */}
      <div style={{
        position: 'absolute',
        left: 120, bottom: 120,
        opacity: trustP,
      }}>
        <div style={{ fontFamily: M.mono, fontSize: 11, color: M.gray, letterSpacing: '0.25em', marginBottom: 16 }}>
          TRUSTED BY
        </div>
        <div style={{ display: 'flex', gap: 28, alignItems: 'center' }}>
          {['BERKSHIRE HATHAWAY', 'PENN STATE', 'WELLS FARGO', 'INC. 5000 #651'].map((name, i) => (
            <div key={i} style={{
              padding: '10px 18px',
              border: `1px dashed ${M.grayDim}`,
              fontFamily: M.mono,
              fontSize: 11,
              color: M.gray,
              letterSpacing: '0.18em',
              opacity: clamp((t - 4.5 - i * 0.1) / 0.4, 0, 1),
            }}>
              {name}
            </div>
          ))}
        </div>
      </div>

      {/* Footer with logo */}
      <div style={{
        position: 'absolute',
        right: 120, bottom: 100,
        opacity: trustP,
        textAlign: 'right',
      }}>
        <img
          src="assets/momentum-logo.png"
          alt="Momentum 360"
          style={{ height: 56, display: 'block', marginLeft: 'auto', marginBottom: 12 }}
        />
        <div style={{ fontFamily: M.mono, fontSize: 13, color: M.off, letterSpacing: '0.15em' }}>
          (215) 607-6482
        </div>
        <div style={{ fontFamily: M.mono, fontSize: 11, color: M.gray, letterSpacing: '0.2em', marginTop: 4 }}>
          MOMENTUMVIRTUALTOURS.COM
        </div>
      </div>

      <FilmGrain opacity={0.08}/>
      <Vignette/>
    </React.Fragment>
  );
}

window.Act6Close = Act6Close;
