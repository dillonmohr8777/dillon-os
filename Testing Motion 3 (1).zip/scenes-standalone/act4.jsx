// Act 4 — What You Get (21s → 28s)
// Four feature cards with staggered entry + micro-animations

function FeatureIcon({ kind, t }) {
  const size = 60;
  if (kind === 'motion') {
    // Kinetic type abstract
    return (
      <svg width={size} height={size} viewBox="0 0 60 60">
        <rect x="8" y={14 + Math.sin(t * 2) * 2} width="44" height="6" fill={M.gold}/>
        <rect x="14" y={28 + Math.sin(t * 2 + 1) * 2} width="32" height="6" fill={M.off}/>
        <rect x="8" y={42 + Math.sin(t * 2 + 2) * 2} width="38" height="6" fill={M.gold}/>
      </svg>
    );
  }
  if (kind === 'formats') {
    return (
      <svg width={size} height={size} viewBox="0 0 60 60">
        <rect x="6" y="18" width="18" height="28" fill="none" stroke={M.gold} strokeWidth="2"/>
        <rect x="26" y="14" width="18" height="18" fill="none" stroke={M.off} strokeWidth="2"/>
        <rect x="26" y="36" width="28" height="12" fill="none" stroke={M.goldDim} strokeWidth="2"/>
      </svg>
    );
  }
  if (kind === 'brand') {
    return (
      <svg width={size} height={size} viewBox="0 0 60 60">
        <circle cx="30" cy="30" r={14 + Math.sin(t) * 2} fill="none" stroke={M.gold} strokeWidth="2"/>
        <circle cx="30" cy="30" r="6" fill={M.gold}/>
        <path d="M30 8 L30 14 M30 46 L30 52 M8 30 L14 30 M46 30 L52 30" stroke={M.off} strokeWidth="2"/>
      </svg>
    );
  }
  // drops
  return (
    <svg width={size} height={size} viewBox="0 0 60 60">
      <rect x="10" y="14" width="40" height="36" fill="none" stroke={M.gold} strokeWidth="2"/>
      <line x1="10" y1="22" x2="50" y2="22" stroke={M.gold} strokeWidth="2"/>
      <circle cx="20" cy="32" r="2" fill={M.off}/>
      <circle cx="30" cy="32" r="2" fill={M.gold}/>
      <circle cx="40" cy="32" r="2" fill={M.goldDim}/>
      <rect x="16" y="40" width="28" height="3" fill={M.gold}/>
    </svg>
  );
}

function FeatureCard({ idx, title, body, kind, t, stagger = 0.15 }) {
  const appear = t - idx * stagger;
  const p = clamp(appear / 0.6, 0, 1);
  const ease = Easing.easeOutCubic(p);
  return (
    <div style={{
      flex: 1,
      padding: 40,
      background: 'rgba(255,255,255,0.02)',
      border: `1px solid rgba(212,169,66,0.18)`,
      opacity: ease,
      transform: `translateY(${(1 - ease) * 30}px)`,
      position: 'relative',
      minHeight: 420,
    }}>
      <div style={{
        fontFamily: M.mono, fontSize: 11, color: M.gold,
        letterSpacing: '0.25em', marginBottom: 30,
      }}>
        0{idx + 1}
      </div>
      <div style={{ marginBottom: 40 }}>
        <FeatureIcon kind={kind} t={t}/>
      </div>
      <div style={{
        fontFamily: M.display,
        fontSize: 28,
        fontWeight: 700,
        color: M.off,
        lineHeight: 1.05,
        letterSpacing: '-0.015em',
        marginBottom: 16,
      }}>{title}</div>
      <div style={{
        fontFamily: M.body,
        fontSize: 16,
        color: M.gray,
        lineHeight: 1.5,
      }}>{body}</div>
    </div>
  );
}

function Act4Features() {
  const act = React.useContext(SpriteContext);
  const t = act.localTime;

  const headP = clamp(t / 0.7, 0, 1);
  const headEase = Easing.easeOutCubic(headP);

  return (
    <React.Fragment>
      <div style={{ position: 'absolute', inset: 0, background: M.navy }}/>
      <LightLeak progress={t / 7} strength={0.4}/>

      <div style={{ position: 'absolute', left: 120, top: 100, opacity: headEase, transform: `translateY(${(1 - headEase) * 10}px)` }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 12 }}>
          <div style={{ width: 40, height: 1, background: M.gold }}/>
          <div style={{ fontFamily: M.mono, fontSize: 13, color: M.gold, letterSpacing: '0.25em' }}>
            04 / WHAT YOU GET
          </div>
        </div>
        <div style={{
          fontFamily: M.display, fontSize: 76, fontWeight: 700,
          color: M.off, letterSpacing: '-0.03em', lineHeight: 0.98,
        }}>
          Built for the <span style={{ color: M.gold, fontStyle: 'italic' }}>scroll stop.</span>
        </div>
      </div>

      <div style={{
        position: 'absolute', left: 120, right: 120, top: 360,
        display: 'flex', gap: 24,
      }}>
        <FeatureCard idx={0} t={t - 0.6} kind="motion"
          title="Cinematic Motion Graphics"
          body="Kinetic type, layered parallax, and cinematic transitions that stop the scroll."/>
        <FeatureCard idx={1} t={t - 0.6} kind="formats"
          title="Platform-Native Formatting"
          body="Delivered in 9:16, 1:1, and 16:9. Optimized for Instagram, TikTok, LinkedIn, and YouTube Shorts."/>
        <FeatureCard idx={2} t={t - 0.6} kind="brand"
          title="Brand-Locked Styling"
          body="Your colors, your fonts, your logo. Every video looks like it came from your brand team."/>
        <FeatureCard idx={3} t={t - 0.6} kind="drops"
          title="Monthly Content Drops"
          body="Consistent, scheduled output so your feed never goes cold."/>
      </div>

      <FilmGrain opacity={0.06}/>
    </React.Fragment>
  );
}

window.Act4Features = Act4Features;
