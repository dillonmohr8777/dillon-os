// Act 5 — Pricing Tiers (28s → 36s)

function TierCard({ idx, name, price, bullets, caption, featured, t, stagger = 0.2 }) {
  const appear = t - idx * stagger;
  const p = clamp(appear / 0.7, 0, 1);
  const ease = Easing.easeOutCubic(p);

  return (
    <div style={{
      flex: featured ? 1.1 : 1,
      padding: featured ? '52px 40px' : '44px 36px',
      background: featured ? 'linear-gradient(180deg, #141A2E 0%, #0A0E1A 100%)' : 'rgba(255,255,255,0.02)',
      border: featured ? `2px solid ${M.gold}` : `1px solid rgba(212,169,66,0.2)`,
      opacity: ease,
      transform: `translateY(${(1 - ease) * 40}px) scale(${featured ? 1.03 : 1})`,
      position: 'relative',
      boxShadow: featured ? `0 30px 80px rgba(212,169,66,0.15), 0 0 60px rgba(212,169,66,0.1)` : 'none',
    }}>
      {featured && (
        <div style={{
          position: 'absolute', top: -14, left: 36,
          padding: '4px 12px',
          background: M.gold,
          color: M.navy,
          fontFamily: M.mono,
          fontSize: 11,
          fontWeight: 700,
          letterSpacing: '0.22em',
        }}>MOST POPULAR</div>
      )}
      <div style={{ fontFamily: M.mono, fontSize: 11, color: featured ? M.gold : M.gray, letterSpacing: '0.25em', marginBottom: 10 }}>
        TIER 0{idx + 1}
      </div>
      <div style={{
        fontFamily: M.display, fontSize: 38, fontWeight: 700,
        color: M.off, letterSpacing: '-0.02em', marginBottom: 4, lineHeight: 1,
      }}>{name}</div>
      <div style={{ display: 'flex', alignItems: 'baseline', gap: 6, marginBottom: 28 }}>
        <div style={{ fontFamily: M.display, fontSize: 48, fontWeight: 700, color: featured ? M.gold : M.off, letterSpacing: '-0.03em' }}>{price}</div>
        <div style={{ fontFamily: M.mono, fontSize: 12, color: M.gray, letterSpacing: '0.1em' }}>/ MONTH</div>
      </div>
      <div style={{ height: 1, background: 'rgba(212,169,66,0.15)', marginBottom: 20 }}/>
      <ul style={{ listStyle: 'none', padding: 0, margin: 0, marginBottom: 20 }}>
        {bullets.map((b, i) => (
          <li key={i} style={{
            fontFamily: M.body, fontSize: 14, color: M.off,
            lineHeight: 1.5, marginBottom: 10,
            paddingLeft: 18, position: 'relative',
            opacity: clamp((t - idx * stagger - 0.5 - i * 0.08) / 0.4, 0, 1),
          }}>
            <span style={{ position: 'absolute', left: 0, color: featured ? M.gold : M.goldDim }}>→</span>
            {b}
          </li>
        ))}
      </ul>
      <div style={{
        fontFamily: M.body, fontSize: 13, color: M.gray,
        fontStyle: 'italic', lineHeight: 1.4,
      }}>{caption}</div>
    </div>
  );
}

function Act5Pricing() {
  const act = React.useContext(SpriteContext);
  const t = act.localTime;

  const headP = clamp(t / 0.7, 0, 1);
  const headEase = Easing.easeOutCubic(headP);

  return (
    <React.Fragment>
      <div style={{ position: 'absolute', inset: 0, background: `linear-gradient(180deg, ${M.navy} 0%, #05080f 100%)` }}/>

      <div style={{ position: 'absolute', left: 120, top: 80, opacity: headEase, transform: `translateY(${(1 - headEase) * 10}px)` }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 12 }}>
          <div style={{ width: 40, height: 1, background: M.gold }}/>
          <div style={{ fontFamily: M.mono, fontSize: 13, color: M.gold, letterSpacing: '0.25em' }}>
            05 / PRICING
          </div>
        </div>
        <div style={{
          fontFamily: M.display, fontSize: 64, fontWeight: 700,
          color: M.off, letterSpacing: '-0.03em', lineHeight: 1,
        }}>
          Pick your <span style={{ color: M.gold, fontStyle: 'italic' }}>production tier.</span>
        </div>
      </div>

      <div style={{
        position: 'absolute', left: 120, right: 120, top: 280,
        display: 'flex', gap: 20, alignItems: 'stretch',
      }}>
        <TierCard idx={0} t={t - 0.5}
          name="Essentials"
          price="$750"
          bullets={[
            '5 Interactive Motion Videos / month',
            'First video on us — risk-free trial',
            '1 platform format per video (9:16 or 1:1)',
            '48-hour revision window',
            'Standard brand kit application',
          ]}
          caption="Best for small businesses getting started."
          featured={false}
        />
        <TierCard idx={1} t={t - 0.5}
          name="Signature"
          price="$1,250"
          bullets={[
            '10 Interactive Motion Videos / month',
            'All three formats per video (9:16, 1:1, 16:9)',
            'Priority 24-hour revision window',
            'Custom motion design per video',
            'Monthly performance report',
          ]}
          caption="Best for growing brands scaling social presence."
          featured={true}
        />
        <TierCard idx={2} t={t - 0.5}
          name="Studio"
          price="$1,500"
          bullets={[
            '15 Interactive Motion Videos / month',
            'All formats plus custom aspect ratios',
            'Dedicated motion designer',
            'Same-day revisions',
            'Quarterly creative strategy call',
            'Branded thumbnail and end-card system',
          ]}
          caption="Best for multi-location brands and franchises."
          featured={false}
        />
      </div>

      <div style={{
        position: 'absolute',
        left: 0, right: 0, bottom: 60,
        textAlign: 'center',
        fontFamily: M.body, fontSize: 15, color: M.gray,
        fontStyle: 'italic',
        opacity: clamp((t - 3.0) / 0.6, 0, 1),
      }}>
        All tiers include licensed music, commercial rights, and full ownership of final assets.
      </div>

      <FilmGrain opacity={0.05}/>
    </React.Fragment>
  );
}

window.Act5Pricing = Act5Pricing;
