// Shared helpers, tokens, and tiny primitives used across scenes.

const M = {
  navy: '#0A0E1A',
  navy2: '#141A2E',
  navy3: '#0F1424',
  gold: '#D4A942',
  goldDim: 'rgba(212, 169, 66, 0.6)',
  red: '#E63946',
  off: '#F5F2EC',
  gray: '#8A8F9C',
  grayDim: 'rgba(138, 143, 156, 0.4)',
  display: '"Fraunces", "Playfair Display", Georgia, serif',
  body: '"Inter", system-ui, sans-serif',
  mono: '"JetBrains Mono", ui-monospace, monospace',
};

// Grain / film texture — CSS-only
function FilmGrain({ opacity = 0.06 }) {
  const svg = encodeURIComponent(
    `<svg xmlns='http://www.w3.org/2000/svg' width='240' height='240'>
      <filter id='n'><feTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='2' stitchTiles='stitch'/><feColorMatrix values='0 0 0 0 1  0 0 0 0 1  0 0 0 0 1  0 0 0 0.6 0'/></filter>
      <rect width='100%' height='100%' filter='url(%23n)'/>
    </svg>`.replace(/\n\s+/g, ' ')
  );
  return (
    <div style={{
      position: 'absolute', inset: 0,
      backgroundImage: `url("data:image/svg+xml,${svg}")`,
      backgroundSize: '240px 240px',
      opacity,
      mixBlendMode: 'overlay',
      pointerEvents: 'none',
    }}/>
  );
}

// Gold light leak gradient that slowly drifts
function LightLeak({ progress = 0, strength = 0.5 }) {
  const cx = 20 + progress * 60;
  const cy = 30 + Math.sin(progress * 3) * 20;
  return (
    <div style={{
      position: 'absolute', inset: 0,
      background: `radial-gradient(ellipse 80% 60% at ${cx}% ${cy}%, rgba(212,169,66,${0.22 * strength}) 0%, rgba(212,169,66,0.05) 35%, transparent 70%)`,
      pointerEvents: 'none',
    }}/>
  );
}

// Vignette
function Vignette() {
  return (
    <div style={{
      position: 'absolute', inset: 0,
      background: 'radial-gradient(ellipse 100% 70% at 50% 50%, transparent 40%, rgba(0,0,0,0.55) 100%)',
      pointerEvents: 'none',
    }}/>
  );
}

// Scan lines
function ScanLines({ opacity = 0.04 }) {
  return (
    <div style={{
      position: 'absolute', inset: 0,
      background: 'repeating-linear-gradient(0deg, rgba(255,255,255,0.08) 0 1px, transparent 1px 3px)',
      opacity,
      pointerEvents: 'none',
      mixBlendMode: 'overlay',
    }}/>
  );
}

// Cinematic letterbox bars (decorative)
function Letterbox({ height = 40, visible = true }) {
  if (!visible) return null;
  return (
    <React.Fragment>
      <div style={{ position: 'absolute', left: 0, right: 0, top: 0, height, background: '#000', zIndex: 900 }}/>
      <div style={{ position: 'absolute', left: 0, right: 0, bottom: 0, height, background: '#000', zIndex: 900 }}/>
    </React.Fragment>
  );
}

// Kinetic word-by-word text
function KineticLine({ text, start = 0, perWord = 0.06, size = 80, weight = 800, color = M.off, font = M.display, letterSpacing = '-0.02em', italic = false, style = {} }) {
  const { time } = useTimeline();
  const words = text.split(' ');
  return (
    <div style={{
      fontFamily: font,
      fontSize: size,
      fontWeight: weight,
      color,
      letterSpacing,
      lineHeight: 1.02,
      fontStyle: italic ? 'italic' : 'normal',
      ...style,
    }}>
      {words.map((w, i) => {
        const s = start + i * perWord;
        const local = clamp((time - s) / 0.5, 0, 1);
        const eased = Easing.easeOutCubic(local);
        return (
          <span key={i} style={{
            display: 'inline-block',
            opacity: eased,
            transform: `translateY(${(1 - eased) * 24}px)`,
            marginRight: '0.4em',
            willChange: 'transform, opacity',
          }}>
            {w}
          </span>
        );
      })}
    </div>
  );
}

// Character-by-character typer
function Typer({ text, start = 0, cps = 28, size = 28, color = M.off, font = M.mono, weight = 500, style = {}, caret = true }) {
  const { time } = useTimeline();
  const elapsed = Math.max(0, time - start);
  const chars = Math.floor(elapsed * cps);
  const shown = text.slice(0, Math.min(chars, text.length));
  const done = chars >= text.length;
  const blink = Math.floor(time * 2) % 2 === 0;
  return (
    <span style={{ fontFamily: font, fontSize: size, fontWeight: weight, color, letterSpacing: '0.02em', ...style }}>
      {shown}
      {caret && (
        <span style={{
          display: 'inline-block',
          width: '0.55em',
          height: '1em',
          background: color,
          marginLeft: 2,
          opacity: done ? (blink ? 1 : 0) : 1,
          verticalAlign: '-0.12em',
        }}/>
      )}
    </span>
  );
}

// Momentum logo (image)
function MomentumLogo({ x, y, scale = 1, opacity = 1 }) {
  return (
    <img
      src={window.__resources.momentumLogo}
      alt="Momentum 360"
      style={{
        position: 'absolute',
        left: x, top: y,
        height: 44 * scale,
        width: 'auto',
        opacity,
        willChange: 'transform, opacity',
      }}
    />
  );
}

// Social post mockup — generic "competition" style (INTENTIONALLY UGLY)
function StaticPostMock({ width = 420, height = 520 }) {
  return (
    <div style={{
      width, height,
      background: '#fff',
      borderRadius: 4,
      boxShadow: '0 30px 80px rgba(0,0,0,0.6), 0 0 0 1px rgba(255,255,255,0.06)',
      overflow: 'hidden',
      display: 'flex', flexDirection: 'column',
      fontFamily: 'Arial, sans-serif',
    }}>
      {/* header */}
      <div style={{ padding: '12px 14px', display: 'flex', alignItems: 'center', gap: 10, borderBottom: '1px solid #eee' }}>
        <div style={{ width: 32, height: 32, borderRadius: 16, background: '#d8d4cb', display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#8a7a5a', fontWeight: 700, fontSize: 13 }}>B</div>
        <div style={{ flex: 1 }}>
          <div style={{ fontSize: 13, fontWeight: 600, color: '#222' }}>@bobs_realty_2008</div>
          <div style={{ fontSize: 11, color: '#888' }}>Posted 4d ago</div>
        </div>
        <div style={{ fontSize: 18, color: '#bbb' }}>•••</div>
      </div>
      {/* image area — the ugly stock photo */}
      <div style={{ flex: 1, position: 'relative', overflow: 'hidden', background: '#d8d4cb' }}>
        <img
          src={window.__resources.uglyHouse}
          alt=""
          style={{ width: '100%', height: '100%', objectFit: 'cover', filter: 'saturate(0.7) contrast(0.9)', display: 'block' }}
        />
      </div>
      {/* Caption */}
      <div style={{ padding: '10px 14px 6px', fontSize: 13, color: '#222', lineHeight: 1.3 }}>
        <b>JUST LISTED!!!</b> 🏠🏠🏠 DREAM HOME AWAITS!! 4bd/3ba in great neighborhood must see!!! DM for details #realestate #forsale #philly #dreamhome
      </div>
      {/* engagement bar */}
      <div style={{ padding: '8px 14px 12px', display: 'flex', gap: 16, alignItems: 'center', color: '#888', fontSize: 12 }}>
        <span>♡ 14 likes</span>
        <span>💬 2</span>
        <span>↗ 0</span>
      </div>
    </div>
  );
}

// Animated text-box wrapper — every text block gets motion around it
function MotionTextBox({ children, color = M.gold, t = 0, variant = 'brackets', style = {} }) {
  // Running border, flickering corner brackets, underline sweep
  const sweep = (t * 0.5) % 1;
  const flicker = Math.floor(t * 12) % 8 !== 0 ? 1 : 0.4;
  return (
    <div style={{ position: 'relative', display: 'inline-block', padding: '16px 24px', ...style }}>
      {/* Corner brackets */}
      {['tl','tr','bl','br'].map((k) => {
        const base = { position: 'absolute', width: 18, height: 18, border: `2px solid ${color}`, opacity: flicker };
        const pos = {
          tl: { left: 0, top: 0, borderRight: 'none', borderBottom: 'none' },
          tr: { right: 0, top: 0, borderLeft: 'none', borderBottom: 'none' },
          bl: { left: 0, bottom: 0, borderRight: 'none', borderTop: 'none' },
          br: { right: 0, bottom: 0, borderLeft: 'none', borderTop: 'none' },
        }[k];
        return <div key={k} style={{ ...base, ...pos }}/>;
      })}
      {/* Sweeping underline */}
      <div style={{
        position: 'absolute',
        bottom: -3, left: 0,
        height: 2,
        width: `${sweep * 100}%`,
        background: `linear-gradient(90deg, transparent, ${color}, transparent)`,
      }}/>
      {/* Content */}
      {children}
    </div>
  );
}

// Flash / strobe overlay — bright white pulses
function StrobeFlash({ active = false, intensity = 1 }) {
  if (!active) return null;
  return (
    <div style={{
      position: 'absolute', inset: 0,
      background: `rgba(255,255,255,${intensity})`,
      pointerEvents: 'none',
      zIndex: 800,
      mixBlendMode: 'screen',
    }}/>
  );
}

// Paparazzi camera flash particles
function CameraFlashes({ t, count = 14 }) {
  const flashes = [];
  for (let i = 0; i < count; i++) {
    const cycle = 0.4 + (i % 3) * 0.15;
    const offset = (i * 0.17) % cycle;
    const phase = ((t + offset) % cycle) / cycle;
    const visible = phase < 0.1;
    if (!visible) continue;
    const alpha = 1 - (phase / 0.1);
    const x = ((i * 137) % 1800) + 60;
    const y = ((i * 211) % 900) + 60;
    flashes.push(
      <div key={i} style={{
        position: 'absolute',
        left: x, top: y,
        width: 80, height: 80,
        marginLeft: -40, marginTop: -40,
        background: `radial-gradient(circle, rgba(255,255,255,${alpha}) 0%, rgba(255,255,255,${alpha*0.3}) 30%, transparent 70%)`,
        pointerEvents: 'none',
        zIndex: 700,
      }}/>
    );
  }
  return <>{flashes}</>;
}

// Red carpet spotlight beams
function Spotlights({ t }) {
  return (
    <>
      {[0, 1, 2].map((i) => {
        const x = 200 + i * 700 + Math.sin(t * 0.8 + i) * 120;
        return (
          <div key={i} style={{
            position: 'absolute',
            left: x, top: -200,
            width: 200, height: 1400,
            background: `linear-gradient(180deg, rgba(212,169,66,0.35) 0%, rgba(212,169,66,0.1) 60%, transparent 100%)`,
            transform: `rotate(${Math.sin(t * 0.6 + i * 2) * 15}deg)`,
            transformOrigin: 'top center',
            pointerEvents: 'none',
            mixBlendMode: 'screen',
          }}/>
        );
      })}
    </>
  );
}

Object.assign(window, {
  M, FilmGrain, LightLeak, Vignette, ScanLines, Letterbox,
  KineticLine, Typer, MomentumLogo, StaticPostMock,
  MotionTextBox, StrobeFlash, CameraFlashes, Spotlights,
});
