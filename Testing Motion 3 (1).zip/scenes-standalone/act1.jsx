// Act 1 — COLD OPEN with heavy camera cuts, flashing lights, movie-star reveal
// Beats (0-7s):
//  0.0-1.0 : Ugly post slams in (heavy shake)
//  0.3-2.5 : "This is what your competition is posting." (boxed, shaking)
//  2.5-2.8 : HARD CAMERA CUT — strobe flash, post SHATTERS
//  2.8-3.5 : Second cut — black frame flicker, red slug "CUT." appears
//  3.5-4.5 : Zoom/whip into new post, spotlights spin up
//  4.3-5.5 : Paparazzi flashes + boxed line "THIS IS WHAT YOU'LL POST."
//  5.3-7.0 : "You'll be a movie star. Overnight." kinetic + red carpet glow

function AnimatedPostMock({ progress = 0, width = 420, height = 520 }) {
  const p = progress;
  const float = Math.sin(p * Math.PI * 2) * 4;
  return (
    <div style={{
      width, height,
      background: '#0A0E1A',
      borderRadius: 18,
      boxShadow: '0 40px 100px rgba(212,169,66,0.25), 0 0 0 1px rgba(212,169,66,0.4), 0 0 60px rgba(212,169,66,0.15)',
      overflow: 'hidden',
      position: 'relative',
      fontFamily: M.body,
    }}>
      <div style={{ padding: '14px 16px', display: 'flex', alignItems: 'center', gap: 10, borderBottom: '1px solid rgba(255,255,255,0.08)', position: 'relative', zIndex: 10 }}>
        <div style={{ width: 32, height: 32, borderRadius: 16, background: `conic-gradient(from ${p * 360}deg, ${M.gold}, ${M.red}, ${M.gold})` }}/>
        <div style={{ flex: 1 }}>
          <div style={{ fontSize: 13, fontWeight: 700, color: M.off }}>@yourbrand</div>
          <div style={{ fontSize: 11, color: M.gold, fontFamily: M.mono, letterSpacing: '0.1em' }}>● LIVE · MOTION</div>
        </div>
      </div>
      <div style={{ flex: 1, position: 'relative', height: height - 120, overflow: 'hidden' }}>
        <div style={{ position: 'absolute', inset: -20, background: `radial-gradient(ellipse at ${30 + p*40}% ${50 + float}%, #1a2858 0%, #0a0e1a 60%)`, transform: `scale(${1.05 + p * 0.1})` }}/>
        <div style={{ position: 'absolute', inset: 0, background: 'repeating-linear-gradient(0deg, rgba(212,169,66,0.08) 0 1px, transparent 1px 28px), repeating-linear-gradient(90deg, rgba(212,169,66,0.08) 0 1px, transparent 1px 28px)', transform: `translateY(${p * 20 - 10}px)` }}/>
        <svg viewBox="0 0 420 400" style={{ position: 'absolute', bottom: 0, left: 0, width: '100%', transform: `translateY(${float * 0.5}px)` }}>
          <polygon points="0,400 0,280 40,240 80,260 120,200 180,220 240,180 300,210 360,170 420,190 420,400" fill="#0A0E1A" stroke={M.gold} strokeWidth="1" opacity="0.9"/>
          <rect x="60" y="280" width="10" height="20" fill={M.gold} opacity="0.6"/>
          <rect x="140" y="250" width="8" height="15" fill={M.gold} opacity="0.5"/>
          <rect x="200" y="230" width="10" height="20" fill={M.gold} opacity="0.7"/>
          <rect x="260" y="250" width="8" height="15" fill={M.gold} opacity="0.5"/>
          <rect x="320" y="220" width="10" height="20" fill={M.gold} opacity="0.6"/>
        </svg>
        <div style={{ position: 'absolute', left: 24, right: 24, top: 40, color: M.off, fontFamily: M.display, fontSize: 38, fontWeight: 800, lineHeight: 0.95, letterSpacing: '-0.02em', textShadow: '0 2px 20px rgba(0,0,0,0.8)' }}>
          <div style={{ transform: `translateY(${-float * 0.6}px)` }}>
            A HOME<br/>
            <span style={{ color: M.gold, fontStyle: 'italic' }}>reimagined.</span>
          </div>
        </div>
        <div style={{ position: 'absolute', left: 0, right: 0, bottom: 60, padding: '10px 24px', background: 'rgba(212,169,66,0.95)', color: M.navy, fontFamily: M.mono, fontSize: 11, letterSpacing: '0.15em', fontWeight: 700, transform: `translateX(${p < 0.5 ? -300 + p * 600 : 0}px)` }}>
          4 BED · 3 BATH · $1.2M
        </div>
        <FilmGrain opacity={0.12}/>
      </div>
      <div style={{ padding: '12px 16px', display: 'flex', gap: 16, alignItems: 'center', color: M.off, fontSize: 12, fontFamily: M.mono, letterSpacing: '0.08em', borderTop: '1px solid rgba(255,255,255,0.08)', position: 'relative', zIndex: 10 }}>
          <span style={{ color: M.red }}>♥ {Math.floor(2400 + p * 8000).toLocaleString()}</span>
          <span>💬 {Math.floor(60 + p * 180)}</span>
          <span style={{ color: M.gold }}>↗ {Math.floor(120 + p * 400)}</span>
      </div>
    </div>
  );
}
window.AnimatedPostMock = AnimatedPostMock;

function Act1ColdOpen() {
  const act = React.useContext(SpriteContext);
  const t = act.localTime;
  const { time } = useTimeline();

  // Shake on static post
  const shakeX = Math.sin(t * 30) * 3 + Math.sin(t * 47) * 2;
  const shakeY = Math.cos(t * 33) * 3 + Math.cos(t * 51) * 2;

  // Entry
  const inP = clamp(t / 0.4, 0, 1);
  const inEase = Easing.easeOutBack(inP);

  // CAMERA CUT 1 — strobe at 2.5, post shatters
  const cut1 = t >= 2.48 && t < 2.58;
  const shatterP = clamp((t - 2.6) / 0.5, 0, 1);

  // BLACK FLICKER / "CUT." slug
  const slugStart = 2.85;
  const slugP = clamp((t - slugStart) / 0.2, 0, 1);
  const slugOut = clamp((t - 3.4) / 0.2, 0, 1);
  const slugVis = slugP > 0 && slugOut < 1;
  const blackFrame = (t >= 2.6 && t < 2.72) || (t >= 3.2 && t < 3.28);

  // CAMERA CUT 2 — whip into new post at 3.5
  const cut2 = t >= 3.48 && t < 3.56;

  // New animated post
  const newInP = clamp((t - 3.5) / 0.6, 0, 1);
  const newInEase = Easing.easeOutCubic(newInP);
  const animPostProg = clamp((t - 3.9) / 3.1, 0, 1);

  // Paparazzi active window
  const paparazziActive = t >= 4.3 && t < 7.0;

  // "Movie star. Overnight." beat
  const movieStarP = clamp((t - 5.3) / 0.4, 0, 1);

  // Random quick flash during movie-star beat
  const quickStrobe = t > 5.3 && t < 7 && (Math.floor(t * 8) % 7 === 0);

  return (
    <React.Fragment>
      {/* Background — shifts on cuts */}
      <div style={{
        position: 'absolute', inset: 0,
        background: blackFrame ? '#000' : (t < 3.5
          ? `radial-gradient(ellipse at 50% 40%, ${M.navy2} 0%, ${M.navy} 70%)`
          : `radial-gradient(ellipse at 50% 50%, #1a2858 0%, ${M.navy} 60%, #000 100%)`),
      }}/>

      {/* Spotlights in second half */}
      {t >= 3.7 && t < 7 && <Spotlights t={t}/>}

      <LightLeak progress={t / 7} strength={0.6}/>

      {/* STATIC POST (ugly) */}
      {t < 2.7 && (
        <div style={{
          position: 'absolute',
          left: 760, top: 240,
          opacity: inEase * (1 - shatterP),
          transform: `
            translate(${shakeX + (1-inEase)*-50}px, ${shakeY}px)
            scale(${0.9 + 0.1 * inEase})
            rotate(${-2 + shakeX * 0.4}deg)
            ${shatterP > 0 ? `translateY(${shatterP * 400}px) rotate(${shatterP * 45}deg)` : ''}
          `,
          filter: `blur(${shatterP * 10}px)`,
        }}>
          <StaticPostMock/>
          {/* Red circle-and-arrow highlight */}
          <svg style={{ position: 'absolute', left: -40, top: -40, width: 520, height: 620, pointerEvents: 'none' }} viewBox="0 0 520 620">
            <ellipse cx="250" cy="280" rx={170 + Math.sin(t*6)*3} ry={200 + Math.cos(t*6)*3}
              fill="none" stroke={M.red} strokeWidth="4"
              strokeDasharray="8 6"
              opacity={clamp((t - 0.5)/0.3, 0, 1) * (1 - shatterP)}/>
            <path d={`M 440 120 L 360 200`} stroke={M.red} strokeWidth="5" fill="none"
              opacity={clamp((t - 0.7)/0.3, 0, 1) * (1 - shatterP)}/>
            <polygon points="340,195 380,200 370,225" fill={M.red}
              opacity={clamp((t - 0.7)/0.3, 0, 1) * (1 - shatterP)}/>
          </svg>
        </div>
      )}

      {/* Shatter debris */}
      {shatterP > 0 && shatterP < 1 && (
        <React.Fragment>
          {[...Array(20)].map((_, i) => {
            const angle = (i / 20) * Math.PI * 2;
            const dist = shatterP * (300 + (i % 4) * 100);
            return (
              <div key={i} style={{
                position: 'absolute',
                left: 970 + Math.cos(angle) * dist,
                top: 500 + Math.sin(angle) * dist,
                width: 16 + (i % 4) * 12,
                height: 16 + (i % 4) * 12,
                background: i % 2 ? '#d8d4cb' : '#8a7a5a',
                opacity: (1 - shatterP) * 0.9,
                transform: `rotate(${shatterP * 540 * (i % 2 ? 1 : -1)}deg)`,
              }}/>
            );
          })}
        </React.Fragment>
      )}

      {/* Competition line — boxed, gently shaking */}
      {t >= 0.4 && t < 2.7 && (
        <div style={{
          position: 'absolute',
          left: 120, top: 320,
          transform: `translate(${shakeX*0.3}px, ${shakeY*0.3}px)`,
        }}>
          <div style={{
            fontFamily: M.mono, fontSize: 13, color: M.red,
            letterSpacing: '0.25em', marginBottom: 20,
            opacity: clamp((t - 0.4)/0.3, 0, 1),
          }}>
            ● REC · 01 / COLD OPEN
          </div>
          <MotionTextBox color={M.red} t={t}>
            <div style={{
              fontFamily: M.display, fontSize: 52, fontWeight: 600,
              color: M.off, letterSpacing: '-0.02em', lineHeight: 1.05,
              maxWidth: 620,
            }}>
              <Typer
                text="This is what your competition is posting."
                start={0.6} cps={24}
                size={52} color={M.off} font={M.display} weight={600}
                style={{ lineHeight: 1.05, letterSpacing: '-0.02em' }}
                caret={t < 2.5}
              />
            </div>
          </MotionTextBox>
        </div>
      )}

      {/* "CUT." slug */}
      {slugVis && (
        <div style={{
          position: 'absolute', inset: 0,
          background: '#000',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          zIndex: 600,
          opacity: 1 - slugOut,
        }}>
          <div style={{ textAlign: 'center' }}>
            <div style={{
              fontFamily: M.mono, fontSize: 14, color: M.red,
              letterSpacing: '0.35em', marginBottom: 18,
            }}>▸ SCENE 02 · TAKE 01</div>
            <div style={{
              fontFamily: M.display, fontSize: 220, fontWeight: 800,
              color: M.off, letterSpacing: '-0.05em', lineHeight: 1,
              transform: `scale(${0.96 + slugP * 0.04})`,
            }}>
              CUT<span style={{ color: M.red }}>.</span>
            </div>
            <div style={{
              fontFamily: M.mono, fontSize: 14, color: M.gold,
              letterSpacing: '0.3em', marginTop: 18,
            }}>ROLL CAMERA →</div>
          </div>
        </div>
      )}

      {/* NEW ANIMATED POST */}
      {t >= 3.5 && (
        <div style={{
          position: 'absolute',
          left: 760, top: 240,
          opacity: newInEase,
          transform: `
            translate(${(1 - newInEase) * 800}px, 0)
            scale(${0.88 + 0.12 * newInEase})
            rotate(${(1 - newInEase) * -8}deg)
          `,
          filter: `blur(${(1 - newInEase) * 6}px)`,
        }}>
          <AnimatedPostMock progress={animPostProg}/>
          {/* Gold glow ring */}
          <div style={{
            position: 'absolute', inset: -20,
            border: `2px solid ${M.gold}`,
            borderRadius: 22,
            opacity: (0.3 + Math.sin(t*4)*0.3) * newInEase,
            pointerEvents: 'none',
          }}/>
        </div>
      )}

      {/* "THIS IS WHAT YOU'LL POST." boxed label */}
      {t >= 4.0 && t < 5.4 && (
        <div style={{
          position: 'absolute',
          left: 120, top: 260,
          opacity: clamp((t - 4.0)/0.3, 0, 1) * (1 - clamp((t - 5.2)/0.2, 0, 1)),
        }}>
          <MotionTextBox color={M.gold} t={t}>
            <div style={{
              fontFamily: M.mono, fontSize: 14, color: M.gold,
              letterSpacing: '0.3em', fontWeight: 700,
            }}>
              → THIS IS WHAT YOU'LL POST.
            </div>
          </MotionTextBox>
        </div>
      )}

      {/* MOVIE STAR OVERNIGHT kinetic */}
      {t >= 5.3 && (
        <div style={{
          position: 'absolute',
          left: 120, top: 280,
          width: 1100,
          opacity: movieStarP,
        }}>
          <KineticLine
            text="You'll be a movie star."
            start={5.4} perWord={0.1}
            size={84} weight={700}
            color={M.off} font={M.display}
            style={{ lineHeight: 0.98, letterSpacing: '-0.02em', wordSpacing: '0.12em' }}
          />
          <div style={{ marginTop: 12 }}>
            <KineticLine
              text="Overnight."
              start={6.0} perWord={0.05}
              size={120} weight={800}
              color={M.gold} font={M.display}
              italic={true}
              style={{ lineHeight: 0.95, letterSpacing: '-0.03em', wordSpacing: '0.12em' }}
            />
          </div>
          <div style={{ marginTop: 20 }}>
            <MotionTextBox color={M.red} t={t} style={{ opacity: clamp((t - 6.3)/0.4, 0, 1) }}>
              <span style={{
                fontFamily: M.mono, fontSize: 13, color: M.red,
                letterSpacing: '0.28em', fontWeight: 700,
              }}>NO AUDITION REQUIRED</span>
            </MotionTextBox>
          </div>
        </div>
      )}

      {/* Paparazzi flashes */}
      {paparazziActive && <CameraFlashes t={t}/>}

      {/* Hard camera-cut strobes */}
      <StrobeFlash active={cut1} intensity={1}/>
      <StrobeFlash active={cut2} intensity={1}/>
      <StrobeFlash active={quickStrobe} intensity={0.4}/>

      {/* Cinematic clapperboard timecode corner */}
      <div style={{
        position: 'absolute', left: 120, bottom: 120,
        fontFamily: M.mono, fontSize: 11, color: M.red,
        letterSpacing: '0.25em',
        opacity: 0.8,
        zIndex: 501,
      }}>
        ● REC · 001 · A-CAM · T={t.toFixed(2)}
      </div>

      <ScanLines opacity={0.06}/>
      <Vignette/>
      <FilmGrain opacity={0.1}/>
    </React.Fragment>
  );
}

window.Act1ColdOpen = Act1ColdOpen;
