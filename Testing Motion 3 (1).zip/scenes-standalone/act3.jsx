// Act 3 — Before/After Showcase (13s → 21s)
// Split screen: static post left, animated post right.
// Animated engagement stats tick up.

function StatCounter({ label, from, to, progress, color = M.off, suffix = '' }) {
  const val = Math.floor(from + (to - from) * Easing.easeOutCubic(progress));
  return (
    <div>
      <div style={{
        fontFamily: M.mono,
        fontSize: 11,
        color: M.gray,
        letterSpacing: '0.2em',
        marginBottom: 6,
      }}>{label}</div>
      <div style={{
        fontFamily: M.display,
        fontSize: 42,
        fontWeight: 700,
        color,
        letterSpacing: '-0.02em',
        fontVariantNumeric: 'tabular-nums',
      }}>{val.toLocaleString()}{suffix}</div>
    </div>
  );
}

function Act3BeforeAfter() {
  const act = React.useContext(SpriteContext);
  const t = act.localTime;

  // Intro label + titles
  const labelP = clamp(t / 0.4, 0, 1);
  const splitP = clamp((t - 0.3) / 0.8, 0, 1);
  const splitEase = Easing.easeOutCubic(splitP);

  // Stats animate on reveal
  const statsStart = 1.8;
  const statsP = clamp((t - statsStart) / 2.0, 0, 1);

  // Sweep handle moves across
  const sweepStart = 4.0;
  const sweepP = clamp((t - sweepStart) / 2.5, 0, 1);
  const sweepEase = Easing.easeInOutCubic(sweepP);

  // Dividing slider position (center, then sweeps right past halfway then back)
  const dividerPct = 50; // always 50% for clean split — arrow just shows interactivity

  const animPostProg = clamp((t - 1.0) / 6.5, 0, 1);

  return (
    <React.Fragment>
      <div style={{ position: 'absolute', inset: 0, background: `linear-gradient(180deg, ${M.navy} 0%, #05080f 100%)` }}/>

      {/* Section label */}
      <div style={{
        position: 'absolute', left: 120, top: 80,
        opacity: labelP,
        transform: `translateY(${(1 - labelP) * 10}px)`,
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
          <div style={{ width: 40, height: 1, background: M.gold }}/>
          <div style={{ fontFamily: M.mono, fontSize: 13, color: M.gold, letterSpacing: '0.25em' }}>
            03 / BEFORE & AFTER
          </div>
        </div>
        <div style={{
          fontFamily: M.display,
          fontSize: 64,
          fontWeight: 700,
          color: M.off,
          letterSpacing: '-0.03em',
          marginTop: 12,
          lineHeight: 1,
        }}>
          Same content. <span style={{ color: M.gold, fontStyle: 'italic' }}>Different orbit.</span>
        </div>
      </div>

      {/* Left post — "before" */}
      <div style={{
        position: 'absolute',
        left: 160, top: 280,
        opacity: splitEase,
        transform: `translateX(${(1 - splitEase) * -40}px)`,
      }}>
        <div style={{
          fontFamily: M.mono, fontSize: 12, color: M.gray,
          letterSpacing: '0.25em', marginBottom: 14,
        }}>YOUR CURRENT POST</div>
        <div style={{ filter: 'saturate(0.7) brightness(0.95)' }}>
          <StaticPostMock width={360} height={460}/>
        </div>
        {/* stats row */}
        <div style={{
          marginTop: 28,
          display: 'flex', gap: 36,
          opacity: clamp((t - 1.5) / 0.5, 0, 1),
        }}>
          <StatCounter label="IMPRESSIONS" from={0} to={2400} progress={statsP} color={M.gray}/>
          <StatCounter label="SHARES" from={0} to={14} progress={statsP} color={M.gray}/>
        </div>
      </div>

      {/* Right post — "after" */}
      <div style={{
        position: 'absolute',
        right: 160, top: 280,
        opacity: splitEase,
        transform: `translateX(${(1 - splitEase) * 40}px)`,
      }}>
        <div style={{
          fontFamily: M.mono, fontSize: 12, color: M.gold,
          letterSpacing: '0.25em', marginBottom: 14,
          textAlign: 'right',
        }}>INTERACTIVE MOTION VERSION ↗</div>
        <AnimatedPostMock width={360} height={460} progress={animPostProg}/>
        {/* stats row */}
        <div style={{
          marginTop: 28,
          display: 'flex', gap: 36,
          justifyContent: 'flex-end',
          opacity: clamp((t - 1.5) / 0.5, 0, 1),
        }}>
          <StatCounter label="IMPRESSIONS" from={0} to={187000} progress={statsP} color={M.off}/>
          <StatCounter label="SHARES" from={0} to={2140} progress={statsP} color={M.gold}/>
        </div>
      </div>

      {/* Middle divider + drag handle (decorative, shows interactivity) */}
      <div style={{
        position: 'absolute',
        left: '50%',
        top: 280,
        bottom: 80,
        width: 1,
        background: `linear-gradient(180deg, transparent, ${M.goldDim} 20%, ${M.goldDim} 80%, transparent)`,
        opacity: splitEase,
      }}>
        <div style={{
          position: 'absolute',
          left: -22, top: `${20 + sweepEase * 60}%`,
          width: 44, height: 44,
          borderRadius: 22,
          background: M.gold,
          border: `2px solid ${M.off}`,
          boxShadow: `0 0 30px rgba(212,169,66,0.6), 0 10px 20px rgba(0,0,0,0.4)`,
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          color: M.navy,
          fontFamily: M.mono,
          fontSize: 18,
          fontWeight: 800,
          transition: 'top 0s linear',
        }}>
          ‹›
        </div>
      </div>

      {/* Watch time / saves pair */}
      <div style={{
        position: 'absolute',
        left: '50%', transform: 'translateX(-50%)',
        bottom: 60,
        display: 'flex', gap: 80, alignItems: 'center',
        opacity: clamp((t - 2.8) / 0.6, 0, 1),
      }}>
        <StatCounter label="WATCH TIME" from={0} to={8.4} progress={statsP} color={M.off} suffix="s"/>
        <div style={{ fontFamily: M.mono, fontSize: 11, color: M.gold, letterSpacing: '0.25em' }}>
          × 78 ENGAGEMENT LIFT
        </div>
        <StatCounter label="SAVES" from={0} to={612} progress={statsP} color={M.gold}/>
      </div>

      <FilmGrain opacity={0.06}/>
      <Vignette/>
    </React.Fragment>
  );
}

window.Act3BeforeAfter = Act3BeforeAfter;
window.StatCounter = StatCounter;
