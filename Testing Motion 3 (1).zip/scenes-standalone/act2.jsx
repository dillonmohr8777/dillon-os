// Act 2 — The Reveal (7s → 13s)
// Big headline "Interactive Motion Videos" scales in.
// Subhead + paragraph. Slow ambient gold drift.

function Act2Reveal() {
  const act = React.useContext(SpriteContext);
  const t = act.localTime;

  const titleP = clamp(t / 1.0, 0, 1);
  const titleEase = Easing.easeOutCubic(titleP);

  const subP = clamp((t - 0.9) / 0.8, 0, 1);
  const paraP = clamp((t - 1.6) / 1.0, 0, 1);

  const badgeP = clamp(t / 0.4, 0, 1);

  // Slow camera creep
  const camX = t * 8;

  return (
    <React.Fragment>
      <div style={{ position: 'absolute', inset: 0, background: M.navy }}/>

      {/* Slow ambient radial */}
      <div style={{
        position: 'absolute', inset: 0,
        background: `radial-gradient(ellipse 60% 80% at ${40 + Math.sin(t / 2) * 15}% ${50 + Math.cos(t / 3) * 10}%, rgba(212,169,66,0.18) 0%, rgba(212,169,66,0.04) 40%, transparent 70%)`,
      }}/>

      {/* Floating gold particles */}
      {[...Array(18)].map((_, i) => {
        const seed = i * 37;
        const x = (seed % 1920);
        const y = ((seed * 13) % 1080);
        const drift = Math.sin(t + i) * 20;
        return (
          <div key={i} style={{
            position: 'absolute',
            left: x + camX,
            top: y + drift,
            width: 2 + (i % 3),
            height: 2 + (i % 3),
            background: M.gold,
            borderRadius: '50%',
            opacity: 0.3 + (i % 3) * 0.15,
            boxShadow: `0 0 ${6 + (i % 3) * 4}px rgba(212,169,66,0.6)`,
          }}/>
        );
      })}

      {/* Section label */}
      <div style={{
        position: 'absolute',
        left: 120, top: 140,
        opacity: badgeP,
        transform: `translateY(${(1 - badgeP) * 10}px)`,
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
          <div style={{ width: 40, height: 1, background: M.gold }}/>
          <div style={{ fontFamily: M.mono, fontSize: 13, color: M.gold, letterSpacing: '0.25em' }}>
            02 / THE REVEAL
          </div>
        </div>
      </div>

      {/* Giant headline */}
      <div style={{
        position: 'absolute',
        left: 120, top: 220,
        right: 120,
      }}>
        <div style={{
          fontFamily: M.display,
          fontSize: 180,
          fontWeight: 800,
          color: M.off,
          lineHeight: 0.92,
          letterSpacing: '-0.045em',
          opacity: titleEase,
          transform: `scale(${0.94 + 0.06 * titleEase}) translateY(${(1 - titleEase) * 30}px)`,
          transformOrigin: 'left center',
          willChange: 'transform',
        }}>
          Interactive<br/>
          <span style={{ color: M.gold, fontStyle: 'italic', fontWeight: 400 }}>Motion</span>
          <span style={{ color: M.off }}> Videos.</span>
        </div>
      </div>

      {/* Subhead */}
      <div style={{
        position: 'absolute',
        left: 120, top: 700,
        right: 120,
        opacity: subP,
        transform: `translateY(${(1 - subP) * 14}px)`,
      }}>
        <div style={{
          fontFamily: M.display,
          fontSize: 40,
          fontWeight: 400,
          color: M.off,
          letterSpacing: '-0.01em',
          lineHeight: 1.15,
          fontStyle: 'italic',
          maxWidth: 900,
        }}>
          Social media, upgraded to movie quality.
        </div>
      </div>

      {/* Paragraph */}
      <div style={{
        position: 'absolute',
        left: 120, top: 820,
        maxWidth: 780,
        opacity: paraP,
        transform: `translateY(${(1 - paraP) * 14}px)`,
      }}>
        <div style={{
          fontFamily: M.body,
          fontSize: 22,
          color: M.gray,
          lineHeight: 1.5,
          letterSpacing: '-0.005em',
        }}>
          We take the content you'd already post and rebuild it as cinematic, scroll-triggered motion video. Built for feed-stopping scroll rate. Engineered for shares.
        </div>
      </div>

      {/* Right-side visual: stack of format frames */}
      <div style={{
        position: 'absolute',
        right: 120, top: 640,
        width: 520, height: 280,
        opacity: clamp((t - 2.5) / 0.8, 0, 1),
        transform: `translateY(${(1 - clamp((t - 2.5) / 0.8, 0, 1)) * 20}px)`,
      }}>
        <FormatStack progress={t - 2.5}/>
      </div>

      <FilmGrain opacity={0.07}/>
      <Vignette/>
    </React.Fragment>
  );
}

function FormatStack({ progress = 0 }) {
  const p = Math.max(0, progress);
  return (
    <div style={{ position: 'relative', width: '100%', height: '100%' }}>
      {/* 16:9 */}
      <div style={{
        position: 'absolute',
        right: 0, top: 20,
        width: 280, height: 158,
        background: `linear-gradient(135deg, #1a2858, ${M.navy})`,
        border: `1px solid ${M.goldDim}`,
        boxShadow: '0 20px 40px rgba(0,0,0,0.5)',
        transform: `translateX(${(1 - clamp(p / 0.6, 0, 1)) * 60}px)`,
        opacity: clamp(p / 0.6, 0, 1),
      }}>
        <div style={{ padding: 12, fontFamily: M.mono, fontSize: 10, color: M.gold, letterSpacing: '0.2em' }}>16:9</div>
        <div style={{ position: 'absolute', right: 12, bottom: 12, fontFamily: M.mono, fontSize: 10, color: M.gray, letterSpacing: '0.15em' }}>YOUTUBE</div>
      </div>
      {/* 1:1 */}
      <div style={{
        position: 'absolute',
        right: 200, top: 60,
        width: 180, height: 180,
        background: `linear-gradient(135deg, #0a0e1a, #1a2040)`,
        border: `2px solid ${M.gold}`,
        boxShadow: '0 30px 60px rgba(212,169,66,0.2)',
        transform: `translateY(${(1 - clamp((p - 0.15) / 0.6, 0, 1)) * 40}px) rotate(${-2 + p * 1}deg)`,
        opacity: clamp((p - 0.15) / 0.6, 0, 1),
      }}>
        <div style={{ padding: 12, fontFamily: M.mono, fontSize: 10, color: M.gold, letterSpacing: '0.2em' }}>1:1</div>
        <div style={{ position: 'absolute', right: 12, bottom: 12, fontFamily: M.mono, fontSize: 10, color: M.off, letterSpacing: '0.15em' }}>INSTAGRAM</div>
      </div>
      {/* 9:16 */}
      <div style={{
        position: 'absolute',
        right: 380, top: 0,
        width: 130, height: 230,
        background: `linear-gradient(160deg, ${M.navy}, #1a2858)`,
        border: `1px solid ${M.goldDim}`,
        boxShadow: '0 30px 60px rgba(0,0,0,0.6)',
        transform: `translateX(${(1 - clamp((p - 0.3) / 0.6, 0, 1)) * -60}px) rotate(${3 - p * 1}deg)`,
        opacity: clamp((p - 0.3) / 0.6, 0, 1),
      }}>
        <div style={{ padding: 12, fontFamily: M.mono, fontSize: 10, color: M.gold, letterSpacing: '0.2em' }}>9:16</div>
        <div style={{ position: 'absolute', right: 12, bottom: 12, fontFamily: M.mono, fontSize: 10, color: M.gray, letterSpacing: '0.15em' }}>TIKTOK</div>
      </div>
    </div>
  );
}

window.Act2Reveal = Act2Reveal;
