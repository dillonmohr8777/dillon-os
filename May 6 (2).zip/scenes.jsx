// SmartCare Animated Video — scenes
// ------------------------------------------------
// 4K canvas: 3840x2160. Duration: 60s.
// Scenes:
//   0.0 – 8.0   : Intro — logo build + eyebrow + tagline
//   8.0 – 18.0  : "Your HCM platform is live. Now what?" + 82% stat
//   18.0 – 30.0 : Journey rings — Stabilize → Essentials → Accelerate → Transform
//   30.0 – 42.0 : Managed services — 3 cards + $200K-$400K savings
//   42.0 – 52.0 : Live telemetry terminal — typing out scan results
//   52.0 – 60.0 : Closing CTA — "Your platform has more to give."

const W = 3840;
const H = 2160;

// ── palette ──────────────────────────────────────
const C = {
  ink0: '#0a0410',
  ink1: '#120618',
  ink2: '#1a0a22',
  gold: '#FFD66B',
  amber: '#FFC267',
  orange: '#FF7A2E',
  ember: '#FF4D17',
  coral: '#FF7A2E',
  peach: '#FFB277',
  cream: '#FFF3E6',
  white: '#FFF8EC',
  dim: 'rgba(255,230,200,0.82)',
};

// ── drifting tokens background (subtle, edge-weighted) ──
function Tokens({ dense = false }) {
  const time = useTime();
  const count = dense ? 24 : 16;
  const tokens = React.useMemo(() => {
    const words = ['HCM','API','ROI','WFM','UKG','SQL','KPI','ERP','SaaS','$','%','#'];
    const rand = (seed) => {
      const x = Math.sin(seed * 9283.1) * 43758.5453;
      return x - Math.floor(x);
    };
    return Array.from({ length: count }, (_, i) => {
      const edge = rand(i + 1);
      let top, left;
      if (edge < 0.3) { top = rand(i + 99) * 18; left = rand(i + 2) * 100; }
      else if (edge < 0.55) { top = 82 + rand(i + 50) * 18; left = rand(i + 3) * 100; }
      else if (edge < 0.8) { top = rand(i + 60) * 100; left = rand(i + 4) * 14; }
      else { top = rand(i + 70) * 100; left = 86 + rand(i + 5) * 14; }
      return {
        t: words[Math.floor(rand(i + 9) * words.length)],
        top, left,
        size: 40 + rand(i + 10) * 80,
        rot: -20 + rand(i + 11) * 40,
        speed: 0.8 + rand(i + 12) * 1.4,
        offset: rand(i + 13) * 10,
      };
    });
  }, [count]);

  return (
    <div style={{ position: 'absolute', inset: 0, pointerEvents: 'none', overflow: 'hidden' }}>
      {tokens.map((tk, i) => {
        const drift = Math.sin((time + tk.offset) * tk.speed * 0.6) * 30;
        const driftY = Math.cos((time + tk.offset) * tk.speed * 0.4) * 20;
        return (
          <div key={i} style={{
            position: 'absolute',
            top: `${tk.top}%`, left: `${tk.left}%`,
            fontSize: tk.size,
            fontFamily: 'Geist, sans-serif',
            fontWeight: 800,
            color: 'transparent',
            WebkitTextStroke: '1.5px rgba(255,180,120,0.18)',
            transform: `translate(${drift}px, ${driftY}px) rotate(${tk.rot}deg)`,
            whiteSpace: 'nowrap',
            willChange: 'transform',
          }}>{tk.t}</div>
        );
      })}
    </div>
  );
}

// ── rising sparks/embers ──
function Sparks({ count = 40 }) {
  const time = useTime();
  const sparks = React.useMemo(() => {
    const rand = (seed) => {
      const x = Math.sin(seed * 4839.2) * 43758.5453;
      return x - Math.floor(x);
    };
    return Array.from({ length: count }, (_, i) => ({
      x: rand(i + 1) * 100,
      baseY: 60 + rand(i + 2) * 50,
      speed: 20 + rand(i + 3) * 60,
      size: 4 + rand(i + 4) * 8,
      offset: rand(i + 5) * 4,
    }));
  }, [count]);

  return (
    <div style={{ position: 'absolute', inset: 0, pointerEvents: 'none' }}>
      {sparks.map((s, i) => {
        const cycle = ((time + s.offset) * s.speed) % 700;
        const y = s.baseY - (cycle / 700) * 80;
        const opacity = cycle < 50 ? cycle / 50 : cycle > 600 ? (700 - cycle) / 100 : 1;
        return (
          <div key={i} style={{
            position: 'absolute',
            left: `${s.x}%`,
            top: `${y}%`,
            width: s.size, height: s.size,
            borderRadius: '50%',
            background: 'radial-gradient(circle, #fff 0%, #FFC267 45%, transparent 75%)',
            boxShadow: `0 0 ${s.size * 3}px ${s.size}px rgba(255,180,100,0.6)`,
            opacity: opacity * 0.85,
            willChange: 'transform, opacity',
          }} />
        );
      })}
    </div>
  );
}

// ── sun glow ──
function SunGlow({ x = '85%', y = '50%', size = 1800, intensity = 1 }) {
  const time = useTime();
  const pulse = 1 + Math.sin(time * 1.2) * 0.06;
  return (
    <div style={{
      position: 'absolute',
      left: x, top: y,
      width: size, height: size,
      transform: `translate(-50%, -50%) scale(${pulse})`,
      background: `radial-gradient(closest-side, rgba(255,210,140,${0.6 * intensity}), rgba(255,130,60,${0.3 * intensity}) 35%, transparent 70%)`,
      filter: 'blur(20px)',
      pointerEvents: 'none',
      willChange: 'transform',
    }} />
  );
}

// ── background grid ──
function Grid() {
  return (
    <div style={{
      position: 'absolute', inset: 0,
      backgroundImage: `linear-gradient(rgba(255,190,130,0.07) 2px, transparent 2px), linear-gradient(90deg, rgba(255,190,130,0.07) 2px, transparent 2px)`,
      backgroundSize: '144px 144px',
      maskImage: 'radial-gradient(120% 80% at 50% 50%, #000 40%, transparent 95%)',
      WebkitMaskImage: 'radial-gradient(120% 80% at 50% 50%, #000 40%, transparent 95%)',
      pointerEvents: 'none',
    }} />
  );
}

// ── scene container with cross-fade timing built-in ──
function SceneBg({ bright = false }) {
  return (
    <div style={{
      position: 'absolute', inset: 0,
      background: bright
        ? `radial-gradient(120% 80% at 85% 50%, rgba(255,180,100,0.55) 0%, rgba(255,120,40,0.28) 30%, transparent 60%),
           radial-gradient(90% 70% at 15% 30%, rgba(255,150,80,0.35) 0%, transparent 55%),
           linear-gradient(180deg, #2a0f1a 0%, #3a1510 45%, #2a0a14 100%)`
        : `radial-gradient(120% 80% at 85% 50%, rgba(255,120,40,0.28) 0%, rgba(255,60,20,0.1) 30%, transparent 55%),
           radial-gradient(90% 70% at 15% 80%, rgba(226,75,255,0.12) 0%, transparent 55%),
           linear-gradient(180deg, #0d0513 0%, #120619 40%, #0a0410 100%)`,
    }} />
  );
}

// ── title / eyebrow helpers ──
function Eyebrow({ x, y, label, start, end }) {
  return (
    <Sprite start={start} end={end}>
      {({ localTime, duration }) => {
        const entry = clamp(localTime / 0.7, 0, 1);
        const exit = localTime > duration - 0.6 ? clamp((localTime - (duration - 0.6)) / 0.6, 0, 1) : 0;
        const lineW = Easing.easeOutCubic(entry) * 104 * (1 - exit);
        const opacity = Easing.easeOutCubic(entry) * (1 - exit);
        return (
          <div style={{
            position: 'absolute',
            left: x, top: y,
            display: 'flex', alignItems: 'center', gap: 36,
            opacity,
          }}>
            <div style={{
              width: lineW, height: 4,
              background: `linear-gradient(90deg, ${C.ember}, ${C.gold})`,
              boxShadow: `0 0 28px ${C.orange}`,
              borderRadius: 2,
            }} />
            <div style={{
              fontFamily: 'Geist Mono, monospace',
              fontSize: 40,
              letterSpacing: '0.28em',
              textTransform: 'uppercase',
              color: C.orange,
              fontWeight: 600,
            }}>{label}</div>
          </div>
        );
      }}
    </Sprite>
  );
}

// ── reveal-from-mask text (with shimmer gradient accent) ──
function BigText({ x, y, children, start, end, size = 240, accent = false, italic = false, align = 'left', maxWidth }) {
  return (
    <Sprite start={start} end={end}>
      {({ localTime, duration }) => {
        const entry = Easing.easeOutCubic(clamp(localTime / 0.9, 0, 1));
        const exitStart = duration - 0.7;
        const exit = localTime > exitStart ? Easing.easeInCubic(clamp((localTime - exitStart) / 0.7, 0, 1)) : 0;
        const ty = (1 - entry) * 80 - exit * 40;
        const opacity = entry * (1 - exit);
        return (
          <div style={{
            position: 'absolute',
            left: x, top: y,
            maxWidth,
            transform: `translateY(${ty}px)`,
            opacity,
            fontFamily: italic ? 'Instrument Serif, serif' : 'Geist, sans-serif',
            fontStyle: italic ? 'italic' : 'normal',
            fontWeight: italic ? 400 : 800,
            fontSize: size,
            letterSpacing: italic ? '-0.01em' : '-0.035em',
            lineHeight: 1.02,
            textAlign: align,
            willChange: 'transform, opacity',
            ...(accent ? {
              background: `linear-gradient(92deg, ${C.gold} 0%, ${C.orange} 45%, #FF5F8A 85%)`,
              WebkitBackgroundClip: 'text',
              backgroundClip: 'text',
              color: 'transparent',
              filter: 'drop-shadow(0 0 60px rgba(255,120,60,0.45))',
            } : {
              color: C.white,
              textShadow: '0 4px 80px rgba(0,0,0,0.7)',
            }),
          }}>{children}</div>
        );
      }}
    </Sprite>
  );
}

function Lead({ x, y, children, start, end, size = 56, maxWidth = 1800, align = 'left' }) {
  return (
    <Sprite start={start} end={end}>
      {({ localTime, duration }) => {
        const entry = Easing.easeOutCubic(clamp((localTime - 0.2) / 0.9, 0, 1));
        const exitStart = duration - 0.6;
        const exit = localTime > exitStart ? clamp((localTime - exitStart) / 0.6, 0, 1) : 0;
        return (
          <div style={{
            position: 'absolute',
            left: x, top: y, maxWidth,
            transform: `translateY(${(1 - entry) * 40}px)`,
            opacity: entry * (1 - exit),
            fontFamily: 'Geist, sans-serif',
            fontSize: size,
            fontWeight: 400,
            lineHeight: 1.4,
            color: C.cream,
            textAlign: align,
            textShadow: '0 2px 40px rgba(0,0,0,0.8)',
            willChange: 'transform, opacity',
          }}>{children}</div>
        );
      }}
    </Sprite>
  );
}

// ── chrome overlays (persistent through film) ──
function Chrome() {
  const time = useTime();
  const pulse = 0.7 + 0.3 * Math.abs(Math.sin(time * 2));
  return (
    <>
      <div style={{
        position: 'absolute', top: 80, left: 120,
        fontFamily: 'Geist Mono, monospace', fontSize: 32,
        letterSpacing: '0.28em', textTransform: 'uppercase',
        color: 'rgba(255,220,190,0.5)', fontWeight: 500,
      }}>SmartCare / by Align HCM</div>
      <div style={{
        position: 'absolute', top: 80, right: 120,
        fontFamily: 'Geist Mono, monospace', fontSize: 32,
        letterSpacing: '0.28em', textTransform: 'uppercase',
        color: 'rgba(255,220,190,0.5)', fontWeight: 500,
      }}>Post-Impl · Intelligence</div>
      <div style={{
        position: 'absolute', bottom: 80, left: 120,
        fontFamily: 'Geist Mono, monospace', fontSize: 32,
        letterSpacing: '0.28em', textTransform: 'uppercase',
        color: 'rgba(255,220,190,0.5)', fontWeight: 500,
      }}>alignhcm.com/smartcare</div>
      <div style={{
        position: 'absolute', bottom: 80, right: 120,
        display: 'flex', alignItems: 'center', gap: 18,
        fontFamily: 'Geist Mono, monospace', fontSize: 32,
        letterSpacing: '0.28em', textTransform: 'uppercase',
        color: C.orange, fontWeight: 600,
      }}>
        <span style={{
          width: 20, height: 20, borderRadius: '50%',
          background: C.orange,
          boxShadow: `0 0 ${20 * pulse}px ${C.orange}`,
          opacity: pulse,
        }}/>
        Live
      </div>
    </>
  );
}

// ═══════════════════════════════════════════════════════════════
// SCENE 1 — Intro (0–8s)
// ═══════════════════════════════════════════════════════════════
function SceneIntro() {
  return (
    <Sprite start={0} end={8}>
      {({ localTime }) => {
        const logoEntry = Easing.easeOutBack(clamp(localTime / 1.2, 0, 1));
        const ringRot = localTime * 60;
        const taglineEntry = Easing.easeOutCubic(clamp((localTime - 1.4) / 1.0, 0, 1));
        const exitT = localTime > 7 ? clamp((localTime - 7) / 1, 0, 1) : 0;
        const camZoom = 1 + localTime * 0.04 + exitT * 0.3;
        const exitOp = 1 - exitT;
        return (
          <div style={{ position: 'absolute', inset: 0, transform: `scale(${camZoom})`, opacity: exitOp, willChange: 'transform, opacity' }}>
            {/* animated ring */}
            <div style={{
              position: 'absolute', left: '50%', top: '38%',
              transform: `translate(-50%, -50%) scale(${logoEntry}) rotate(${ringRot}deg)`,
              willChange: 'transform',
            }}>
              <svg width="900" height="900" viewBox="0 0 300 300">
                <defs>
                  <linearGradient id="introRing" x1="0" x2="1">
                    <stop offset="0" stopColor="#FFD66B"/>
                    <stop offset="0.5" stopColor="#FF7A2E"/>
                    <stop offset="1" stopColor="#FF4D17"/>
                  </linearGradient>
                  <filter id="introGlow"><feGaussianBlur stdDeviation="6"/></filter>
                </defs>
                <circle cx="150" cy="150" r="130" fill="none" stroke="url(#introRing)" strokeWidth="3" filter="url(#introGlow)" opacity="0.8"/>
                <circle cx="150" cy="150" r="130" fill="none" stroke="url(#introRing)" strokeWidth="1.5"/>
                <circle cx="150" cy="150" r="100" fill="none" stroke="url(#introRing)" strokeWidth="1" opacity="0.5" strokeDasharray="4 8"/>
              </svg>
            </div>
            {/* wordmark */}
            <div style={{
              position: 'absolute',
              left: '50%', top: '38%',
              transform: `translate(-50%, -50%) scale(${logoEntry})`,
              fontFamily: 'Geist, sans-serif',
              fontWeight: 800,
              fontSize: 340,
              letterSpacing: '-0.045em',
              color: C.white,
              textShadow: '0 0 120px rgba(255,180,120,0.4)',
              willChange: 'transform',
            }}>Smart<span style={{
              background: `linear-gradient(92deg, ${C.gold}, ${C.orange}, #FF5F8A)`,
              WebkitBackgroundClip: 'text',
              backgroundClip: 'text',
              color: 'transparent',
            }}>Care</span></div>

            {/* tagline */}
            <div style={{
              position: 'absolute',
              left: '50%', top: '68%',
              transform: `translate(-50%, ${(1-taglineEntry) * 60}px)`,
              opacity: taglineEntry,
              fontFamily: 'Geist Mono, monospace',
              fontSize: 56,
              letterSpacing: '0.32em',
              textTransform: 'uppercase',
              color: C.amber,
              whiteSpace: 'nowrap',
              willChange: 'transform, opacity',
            }}>Post-Implementation Intelligence</div>

            <div style={{
              position: 'absolute',
              left: '50%', top: '76%',
              transform: `translate(-50%, ${(1-taglineEntry) * 60}px)`,
              opacity: taglineEntry * 0.9,
              fontFamily: 'Instrument Serif, serif',
              fontStyle: 'italic',
              fontSize: 88,
              color: C.cream,
              whiteSpace: 'nowrap',
            }}>Your HCM, optimized.</div>
          </div>
        );
      }}
    </Sprite>
  );
}

// ═══════════════════════════════════════════════════════════════
// SCENE 2 — "Now what?" + 82% (8–18s)
// ═══════════════════════════════════════════════════════════════
function SceneHook() {
  return (
    <>
      <Sprite start={8} end={18}>
        {({ localTime }) => {
          const camPan = localTime * 30;
          const exitT = localTime > 9 ? clamp((localTime - 9) / 1, 0, 1) : 0;
          return (
            <div style={{ position: 'absolute', inset: 0, transform: `translateX(${-camPan}px)`, opacity: 1 - exitT * 0.6, willChange: 'transform' }}>
            </div>
          );
        }}
      </Sprite>
      <Eyebrow x={240} y={380} label="The Post-Go-Live Reality" start={8.3} end={17.7}/>
      <BigText x={240} y={500} start={8.7} end={17.5} size={240} maxWidth={3400}>
        Your HCM platform is live.
      </BigText>
      <BigText x={240} y={820} start={9.4} end={17.5} size={260} accent italic>
        Now what?
      </BigText>
      <Lead x={240} y={1240} start={10.2} end={17.3} size={60} maxWidth={2600}>
        Go-live was never the finish line. It was day one.
      </Lead>
      {/* big 82% stat pill */}
      <Sprite start={11.5} end={17.3}>
        {({ localTime, duration }) => {
          const entry = Easing.easeOutBack(clamp(localTime / 1.1, 0, 1));
          const exit = localTime > duration - 0.8 ? clamp((localTime - (duration - 0.8)) / 0.8, 0, 1) : 0;
          const counter = Easing.easeOutCubic(clamp(localTime / 1.8, 0, 1));
          const pct = localTime >= 1.8 ? 82 : Math.floor(counter * 82);
          return (
            <div style={{
              position: 'absolute',
              left: 240, top: 1480,
              transform: `scale(${entry})`,
              opacity: 1 - exit,
              display: 'flex', alignItems: 'center', gap: 80,
              padding: '70px 110px',
              borderRadius: 999,
              border: `3px solid rgba(255,150,90,0.55)`,
              background: `radial-gradient(120% 200% at 0% 50%, rgba(255,120,60,0.28), transparent 60%)`,
              boxShadow: `0 0 120px rgba(255,120,60,0.35)`,
              willChange: 'transform, opacity',
            }}>
              <div style={{
                fontFamily: 'Geist, sans-serif',
                fontWeight: 800,
                fontSize: 280,
                letterSpacing: '-0.04em',
                lineHeight: 0.9,
                background: `linear-gradient(92deg, ${C.gold}, ${C.orange}, #FF5F8A)`,
                WebkitBackgroundClip: 'text',
                backgroundClip: 'text',
                color: 'transparent',
                filter: 'drop-shadow(0 0 40px rgba(255,180,80,0.5))',
                minWidth: 600,
              }}>{pct}%</div>
              <div style={{
                fontFamily: 'Geist, sans-serif',
                fontSize: 52,
                lineHeight: 1.3,
                color: C.cream,
                maxWidth: 1400,
                fontWeight: 500,
              }}>
                of organizations use less than half<br/>of their HCM platform's capabilities.
              </div>
            </div>
          );
        }}
      </Sprite>
    </>
  );
}

// ═══════════════════════════════════════════════════════════════
// SCENE 3 — Journey rings (18–30s)
// ═══════════════════════════════════════════════════════════════
const STAGES = [
  { label: 'Stabilize', sub: 'Month One', grad: ['#FFD66B', '#FF7A2E'] },
  { label: 'Essentials', sub: 'Most Teams', grad: ['#FF8A3D', '#FF5F8A'] },
  { label: 'Accelerate', sub: 'Proactive', grad: ['#FFD66B', '#FF7A2E'] },
  { label: 'Transform', sub: 'Strategic', grad: ['#FF5F8A', '#FFD66B'] },
];

function JourneyRing({ idx, start, xCenter, yCenter, size }) {
  const time = useTime();
  const appear = start + idx * 0.6;
  const localT = time - appear;
  const entry = Easing.easeOutBack(clamp(localT / 0.9, 0, 1));
  const rot = Math.max(0, localT) * (idx % 2 === 0 ? 30 : -30);
  const stage = STAGES[idx];
  return (
    <div style={{
      position: 'absolute',
      left: xCenter - size / 2, top: yCenter - size / 2,
      width: size, height: size,
      transform: `scale(${entry})`,
      opacity: entry,
      willChange: 'transform, opacity',
    }}>
      <svg width={size} height={size} viewBox="0 0 300 300" style={{ position: 'absolute', inset: 0, transform: `rotate(${rot}deg)`, transformOrigin: 'center' }}>
        <defs>
          <linearGradient id={`jrg${idx}`} x1="0" x2="1" y1="0" y2="1">
            <stop offset="0" stopColor={stage.grad[0]}/>
            <stop offset="1" stopColor={stage.grad[1]}/>
          </linearGradient>
          <filter id={`jgl${idx}`}><feGaussianBlur stdDeviation="5"/></filter>
        </defs>
        <circle cx="150" cy="150" r="130" fill="none" stroke={`url(#jrg${idx})`} strokeWidth="5" filter={`url(#jgl${idx})`} opacity="0.8"/>
        <circle cx="150" cy="150" r="130" fill="none" stroke={`url(#jrg${idx})`} strokeWidth="2.5"/>
        <circle cx="150" cy="150" r="105" fill="none" stroke={`url(#jrg${idx})`} strokeWidth="1.5" opacity="0.4" strokeDasharray="4 10"/>
      </svg>
      {/* core */}
      <div style={{
        position: 'absolute', inset: '16%',
        borderRadius: '50%',
        background: `radial-gradient(circle at 30% 30%, #2a0e18, #0a0308 80%)`,
        border: `3px solid rgba(255,140,70,0.5)`,
        display: 'flex', flexDirection: 'column',
        alignItems: 'center', justifyContent: 'center', gap: 12,
        boxShadow: `inset 0 0 60px rgba(255,80,20,0.25), 0 0 120px rgba(255,80,20,0.3)`,
      }}>
        <div style={{
          fontFamily: 'Geist, sans-serif',
          fontWeight: 700,
          fontSize: 64,
          letterSpacing: '-0.01em',
          color: C.white,
        }}>{stage.label}</div>
        <div style={{
          fontFamily: 'Geist Mono, monospace',
          fontSize: 24,
          letterSpacing: '0.24em',
          textTransform: 'uppercase',
          color: 'rgba(255,220,190,0.55)',
        }}>{stage.sub}</div>
      </div>
      {/* number badge */}
      <div style={{
        position: 'absolute',
        top: -40, left: '50%', transform: 'translateX(-50%)',
        width: 96, height: 96,
        borderRadius: '50%',
        background: `linear-gradient(135deg, ${stage.grad[0]}, ${stage.grad[1]})`,
        color: C.white,
        display: 'grid', placeItems: 'center',
        fontFamily: 'Geist, sans-serif',
        fontWeight: 700,
        fontSize: 40,
        boxShadow: `0 20px 60px -6px rgba(255,80,20,0.6), inset 0 2px 0 rgba(255,255,255,0.4)`,
      }}>{String(idx + 1).padStart(2, '0')}</div>
    </div>
  );
}

function SceneJourney() {
  return (
    <Sprite start={18} end={30}>
      {({ localTime, duration }) => {
        const exitT = localTime > duration - 0.9 ? clamp((localTime - (duration - 0.9)) / 0.9, 0, 1) : 0;
        const entryT = clamp(localTime / 0.6, 0, 1);
        const opacity = entryT * (1 - exitT);
        const zoom = 1 + exitT * 0.15;
        return (
          <div style={{ position: 'absolute', inset: 0, opacity, transform: `scale(${zoom})`, willChange: 'transform, opacity' }}>
            <Eyebrow x={240} y={340} label="The SmartCare Journey" start={18.2} end={29.5}/>
            <BigText x={240} y={460} start={18.5} end={29.5} size={160} maxWidth={2000}>
              Stabilize. Essentials.
            </BigText>
            <BigText x={240} y={760} start={19.0} end={29.5} size={160} maxWidth={2200}>
              Accelerate. <span style={{ fontFamily: 'Instrument Serif, serif', fontStyle: 'italic', fontWeight: 400, background: `linear-gradient(92deg, ${C.gold}, ${C.orange}, #FF5F8A)`, WebkitBackgroundClip: 'text', backgroundClip: 'text', color: 'transparent' }}>Transform.</span>
            </BigText>
            <Lead x={240} y={1080} start={20.0} end={29.5} size={54} maxWidth={1800}>
              Every org moves through a maturity path after go-live. Most teams stall at Essentials — without knowing it.
            </Lead>

            {/* ring quad */}
            <div style={{ position: 'absolute', right: 180, top: 340, width: 1600, height: 1600 }}>
              <JourneyRing idx={0} start={18.5} xCenter={420} yCenter={420} size={600} />
              <JourneyRing idx={1} start={18.5} xCenter={1180} yCenter={420} size={600} />
              <JourneyRing idx={2} start={18.5} xCenter={420} yCenter={1180} size={600} />
              <JourneyRing idx={3} start={18.5} xCenter={1180} yCenter={1180} size={600} />
              {/* connecting lines */}
              <svg viewBox="0 0 1600 1600" style={{ position: 'absolute', inset: 0, width: '100%', height: '100%', pointerEvents: 'none' }}>
                <defs>
                  <linearGradient id="jline" x1="0" x2="1">
                    <stop offset="0" stopColor="#FFD66B"/>
                    <stop offset="0.5" stopColor="#FF7A2E"/>
                    <stop offset="1" stopColor="#FF5F8A"/>
                  </linearGradient>
                </defs>
                <path d="M420 420 Q800 260 1180 420 Q1340 800 1180 1180 Q800 1340 420 1180 Q260 800 420 420" stroke="url(#jline)" strokeWidth="3" strokeDasharray="8 16" fill="none" opacity="0.5">
                  <animate attributeName="stroke-dashoffset" from="0" to="-48" dur="2s" repeatCount="indefinite"/>
                </path>
              </svg>
            </div>
          </div>
        );
      }}
    </Sprite>
  );
}

// ═══════════════════════════════════════════════════════════════
// SCENE 4 — Managed services (30–42s)
// ═══════════════════════════════════════════════════════════════
function ServiceCard({ idx, title, body, gradient, start }) {
  const time = useTime();
  const local = time - start - idx * 0.35;
  const entry = Easing.easeOutBack(clamp(local / 0.9, 0, 1));
  return (
    <div style={{
      position: 'relative',
      padding: '80px 88px',
      borderRadius: 44,
      background: 'linear-gradient(180deg, rgba(60,22,30,0.8), rgba(40,14,20,0.85))',
      border: '3px solid rgba(255,200,130,0.45)',
      transform: `translateY(${(1 - entry) * 80}px) scale(${0.9 + entry * 0.1})`,
      opacity: entry,
      overflow: 'hidden',
      willChange: 'transform, opacity',
      minHeight: 560,
    }}>
      <div style={{
        position: 'absolute', top: 0, left: 0, right: 0, height: 3,
        background: `linear-gradient(90deg, transparent, ${C.orange}, transparent)`,
      }}/>
      <div style={{
        width: 128, height: 128, borderRadius: 28,
        background: gradient,
        display: 'grid', placeItems: 'center',
        boxShadow: `0 20px 60px -12px rgba(255,80,20,0.6), inset 0 2px 0 rgba(255,255,255,0.35)`,
        marginBottom: 48,
      }}>
        <svg width="64" height="64" viewBox="0 0 24 24" fill="none" stroke="#fff" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
          <rect x="2" y="5" width="20" height="14" rx="2"/>
          <line x1="2" y1="10" x2="22" y2="10"/>
        </svg>
      </div>
      <div style={{
        fontFamily: 'Geist, sans-serif',
        fontWeight: 700,
        fontSize: 72,
        letterSpacing: '-0.01em',
        color: C.white,
        marginBottom: 28,
      }}>{title}</div>
      <div style={{
        fontFamily: 'Geist, sans-serif',
        fontSize: 40,
        lineHeight: 1.4,
        color: 'rgba(255,228,196,0.9)',
      }}>{body}</div>
    </div>
  );
}

function SceneManaged() {
  return (
    <Sprite start={30} end={42}>
      {({ localTime, duration }) => {
        const exit = localTime > duration - 0.9 ? clamp((localTime - (duration - 0.9)) / 0.9, 0, 1) : 0;
        const entry = clamp(localTime / 0.6, 0, 1);
        return (
          <div style={{ position: 'absolute', inset: 0, opacity: entry * (1 - exit), willChange: 'opacity' }}>
            <Eyebrow x={240} y={340} label="Managed Services" start={30.2} end={41.5}/>
            <BigText x={240} y={460} start={30.5} end={41.5} size={180} maxWidth={3400}>
              We run your ops.
            </BigText>
            <BigText x={240} y={760} start={31.0} end={41.5} size={180} accent italic>
              You keep your platform.
            </BigText>
            <Lead x={240} y={1080} start={31.8} end={41.5} size={52} maxWidth={3400}>
              Replace 2 to 4 FTEs. Payroll, HRIS, or WFM on your existing UKG or Dayforce — no migration, no lock-in.
            </Lead>

            {/* cards */}
            <Sprite start={32.5} end={41.5}>
              <div style={{
                position: 'absolute',
                left: 240, top: 1260, right: 240,
                display: 'grid',
                gridTemplateColumns: 'repeat(3, 1fr)',
                gap: 52,
              }}>
                <ServiceCard idx={0} title="Managed Payroll" body="End-to-end processing, tax filing, compliance reporting." gradient="linear-gradient(135deg, #FF8A3D, #FF4D17)" start={32.5}/>
                <ServiceCard idx={1} title="Managed HRIS" body="Employee data, benefits admin, onboarding workflows." gradient="linear-gradient(135deg, #FF7A2E, #FF5F8A)" start={32.5}/>
                <ServiceCard idx={2} title="Managed WFM" body="Scheduling, time tracking, labor cost optimization." gradient="linear-gradient(135deg, #FFD66B, #FF7A2E)" start={32.5}/>
              </div>
            </Sprite>

            {/* savings pill */}
            <Sprite start={35.5} end={41.5}>
              {({ localTime: lt, duration: dd }) => {
                const e = Easing.easeOutBack(clamp(lt / 0.9, 0, 1));
                const savCounter = Easing.easeOutCubic(clamp(lt / 1.6, 0, 1));
                const savK = lt >= 1.6 ? 400 : Math.floor(200 + savCounter * 200);
                return (
                  <div style={{
                    position: 'absolute',
                    left: 240, top: 1880, right: 240,
                    transform: `scale(${e})`,
                    opacity: e,
                    padding: '56px 88px',
                    borderRadius: 40,
                    background: `linear-gradient(90deg, rgba(255,120,60,0.22), rgba(255,150,80,0.15))`,
                    border: '3px solid rgba(255,160,100,0.5)',
                    display: 'flex', alignItems: 'center', gap: 72,
                    boxShadow: `0 0 120px rgba(255,120,60,0.3)`,
                  }}>
                    <div style={{
                      fontFamily: 'Geist, sans-serif',
                      fontWeight: 800,
                      fontSize: 160,
                      letterSpacing: '-0.03em',
                      lineHeight: 0.9,
                      background: `linear-gradient(92deg, ${C.gold}, ${C.orange}, #FF5F8A)`,
                      WebkitBackgroundClip: 'text', backgroundClip: 'text',
                      color: 'transparent',
                      whiteSpace: 'nowrap',
                    }}>${savK}K+</div>
                    <div style={{
                      fontFamily: 'Geist, sans-serif',
                      fontSize: 48,
                      lineHeight: 1.35,
                      color: C.cream,
                      maxWidth: 1800,
                    }}>Annual savings for a 1,000-employee org<br/>vs. running these in-house.</div>
                  </div>
                );
              }}
            </Sprite>
          </div>
        );
      }}
    </Sprite>
  );
}

// ═══════════════════════════════════════════════════════════════
// SCENE 5 — Live telemetry terminal (42–52s)
// ═══════════════════════════════════════════════════════════════
const LOG_LINES = [
  { t: '[09:14:02]', cmd: 'scan', path: 'payroll.tax-engine', status: 'ok', statusColor: '#9CE877' },
  { t: '[09:14:03]', cmd: 'scan', path: 'wfm.approvals.chain', status: 'broken route (3 hops)', statusColor: C.ember },
  { t: '[09:14:04]', cmd: 'scan', path: 'hris.employee-feed', status: 'drift 12 fields', statusColor: C.amber },
  { t: '[09:14:05]', cmd: 'scan', path: 'integration/ADP → UKG', status: 'latency 4.2s', statusColor: C.amber },
  { t: '[09:14:06]', cmd: 'scan', path: 'reporting.labor-cost', status: 'stale (14d)', statusColor: C.ember },
  { t: '[09:14:07]', cmd: 'scan', path: 'adoption.mgr-self-service', status: '31% active', statusColor: C.ember },
];

function SceneTelemetry() {
  return (
    <Sprite start={42} end={52}>
      {({ localTime, duration }) => {
        const exit = localTime > duration - 0.9 ? clamp((localTime - (duration - 0.9)) / 0.9, 0, 1) : 0;
        const entry = clamp(localTime / 0.6, 0, 1);
        return (
          <div style={{ position: 'absolute', inset: 0, opacity: entry * (1 - exit) }}>
            <Eyebrow x={240} y={340} label="Live Telemetry" start={42.2} end={51.5}/>
            <BigText x={240} y={460} start={42.5} end={51.5} size={180} maxWidth={1800}>
              The dashboard
            </BigText>
            <BigText x={240} y={760} start={43.0} end={51.5} size={200} accent italic>
              never lies.
            </BigText>
            <Lead x={240} y={1080} start={43.8} end={51.5} size={48} maxWidth={1600}>
              Every engagement starts with reading your system as it behaves — not as it was architected.
            </Lead>

            {/* terminal */}
            <Sprite start={43.5} end={51.5}>
              {({ localTime: lt }) => {
                const e = Easing.easeOutCubic(clamp(lt / 0.8, 0, 1));
                const linesShown = Math.min(LOG_LINES.length, Math.floor((lt - 0.6) / 0.8));
                const cursorBlink = Math.floor(lt * 2) % 2 === 0;
                return (
                  <div style={{
                    position: 'absolute',
                    right: 240, top: 340, width: 1840, height: 1540,
                    transform: `translateY(${(1 - e) * 60}px)`,
                    opacity: e,
                    borderRadius: 40,
                    background: 'linear-gradient(180deg, rgba(26,12,32,0.9), rgba(14,6,20,0.95))',
                    border: '3px solid rgba(255,150,90,0.4)',
                    overflow: 'hidden',
                    boxShadow: `0 40px 120px rgba(0,0,0,0.6), inset 0 2px 0 rgba(255,200,130,0.15)`,
                  }}>
                    {/* header */}
                    <div style={{
                      display: 'flex', alignItems: 'center', gap: 24,
                      padding: '36px 56px',
                      borderBottom: '2px solid rgba(255,160,100,0.25)',
                      background: 'rgba(20,8,26,0.7)',
                    }}>
                      <span style={{ width: 26, height: 26, borderRadius: '50%', background: '#FF5F8A', boxShadow: '0 0 20px #FF5F8A' }}/>
                      <span style={{ width: 26, height: 26, borderRadius: '50%', background: C.gold, boxShadow: `0 0 20px ${C.gold}` }}/>
                      <span style={{ width: 26, height: 26, borderRadius: '50%', background: '#5EE6FF', boxShadow: '0 0 20px #5EE6FF' }}/>
                      <span style={{
                        marginLeft: 28, fontFamily: 'Geist Mono, monospace', fontSize: 36,
                        color: 'rgba(255,220,190,0.65)', letterSpacing: '0.1em',
                      }}>smartcare@align ~ /audit/live.log</span>
                      <span style={{
                        marginLeft: 'auto', fontFamily: 'Geist Mono, monospace', fontSize: 32,
                        color: '#5EE6FF', fontWeight: 600,
                      }}>● STREAMING</span>
                    </div>
                    {/* body */}
                    <div style={{
                      padding: '56px 64px',
                      fontFamily: 'Geist Mono, monospace',
                      fontSize: 40,
                      lineHeight: 1.8,
                      color: C.cream,
                      fontWeight: 500,
                    }}>
                      {LOG_LINES.slice(0, linesShown).map((ln, i) => (
                        <div key={i} style={{ opacity: 1, animation: 'none' }}>
                          <span style={{ color: 'rgba(255,220,190,0.55)' }}>{ln.t}</span>{' '}
                          <span style={{ color: '#5EE6FF' }}>{ln.cmd}</span> → {ln.path} …{' '}
                          <span style={{ color: ln.statusColor, fontWeight: 600 }}>{ln.status}</span>
                        </div>
                      ))}
                      {linesShown >= LOG_LINES.length && (
                        <>
                          <div style={{ color: C.gold, marginTop: 32, fontWeight: 600 }}>
                            ▸ 127 friction points identified across 6 disciplines.
                          </div>
                          <div style={{ marginTop: 24 }}>
                            <span style={{ color: 'rgba(255,220,190,0.55)' }}>[09:14:09]</span>{' '}
                            <span style={{ color: '#FF7A2E' }}>smartcare</span> → queue triage plan
                          </div>
                          <div>
                            <span style={{ color: 'rgba(255,220,190,0.55)' }}>[09:14:10]</span>{' '}
                            <span style={{ color: '#FF7A2E' }}>smartcare</span> → ETA to{' '}
                            <span style={{ color: C.gold, fontWeight: 700 }}>Accelerate</span>: 74 days
                          </div>
                        </>
                      )}
                      <div style={{ marginTop: 24, color: C.gold }}>
                        $ _{cursorBlink && <span style={{ display: 'inline-block', width: 20, height: 46, background: C.gold, verticalAlign: 'middle', marginLeft: 6, boxShadow: `0 0 20px ${C.gold}` }}/>}
                      </div>
                    </div>
                  </div>
                );
              }}
            </Sprite>
          </div>
        );
      }}
    </Sprite>
  );
}

// ═══════════════════════════════════════════════════════════════
// SCENE 6 — CTA Close (52–60s)
// ═══════════════════════════════════════════════════════════════
function SceneCTA() {
  return (
    <Sprite start={52} end={60}>
      {({ localTime, duration }) => {
        const entry = Easing.easeOutCubic(clamp(localTime / 1.0, 0, 1));
        const zoom = 1 + (1 - entry) * 0.1;
        return (
          <div style={{ position: 'absolute', inset: 0, opacity: entry, transform: `scale(${zoom})`, willChange: 'transform, opacity' }}>
            <SunGlow x="50%" y="50%" size={3200} intensity={1.4}/>
            {/* centered eyebrow */}
            <Sprite start={52.3} end={59.8}>
              {({ localTime: lt }) => {
                const e = Easing.easeOutCubic(clamp(lt / 0.8, 0, 1));
                const lineW = e * 104;
                return (
                  <div style={{
                    position: 'absolute',
                    left: '50%', top: 500,
                    transform: 'translateX(-50%)',
                    display: 'flex', alignItems: 'center', gap: 36,
                    opacity: e,
                  }}>
                    <div style={{ width: lineW, height: 4, background: `linear-gradient(90deg, ${C.ember}, ${C.gold})`, boxShadow: `0 0 28px ${C.orange}`, borderRadius: 2 }}/>
                    <div style={{
                      fontFamily: 'Geist Mono, monospace',
                      fontSize: 40, letterSpacing: '0.28em',
                      textTransform: 'uppercase',
                      color: C.orange, fontWeight: 600,
                    }}>The Starting Point</div>
                    <div style={{ width: lineW, height: 4, background: `linear-gradient(90deg, ${C.gold}, ${C.ember})`, boxShadow: `0 0 28px ${C.orange}`, borderRadius: 2 }}/>
                  </div>
                );
              }}
            </Sprite>
            <BigText x={240} y={720} start={52.8} end={59.8} size={220} accent={false} align="center" maxWidth={3360}>
              <div style={{ textAlign: 'center', width: 3360 }}>
                Your platform has more{' '}
                <span style={{ fontFamily: 'Instrument Serif, serif', fontStyle: 'italic', fontWeight: 400, background: `linear-gradient(92deg, ${C.gold}, ${C.orange}, #FF5F8A)`, WebkitBackgroundClip: 'text', backgroundClip: 'text', color: 'transparent' }}>to give.</span>
              </div>
            </BigText>
            <BigText x={240} y={1060} start={53.3} end={59.8} size={220} align="center" maxWidth={3360}>
              <div style={{ textAlign: 'center', width: 3360 }}>We'll show you where.</div>
            </BigText>
            <Lead x={240} y={1480} start={54.0} end={59.8} size={60} maxWidth={3360} align="center">
              <div style={{ textAlign: 'center' }}>
                Every HCM environment holds hidden capacity. See yours mapped out.
              </div>
            </Lead>

            {/* CTA button */}
            <Sprite start={54.8} end={59.8}>
              {({ localTime: lt }) => {
                const e = Easing.easeOutBack(clamp(lt / 0.9, 0, 1));
                const spin = lt * 90;
                return (
                  <div style={{
                    position: 'absolute',
                    left: '50%', top: 1780,
                    transform: `translateX(-50%) scale(${e})`,
                    opacity: e,
                    display: 'flex', alignItems: 'center', gap: 60,
                  }}>
                    <div style={{
                      position: 'relative',
                      padding: '52px 84px',
                      borderRadius: 28,
                      fontFamily: 'Geist, sans-serif',
                      fontWeight: 700, fontSize: 48,
                      letterSpacing: '0.18em', textTransform: 'uppercase',
                      color: '#fff',
                      background: `linear-gradient(180deg, #FF9148 0%, #FF5F1E 100%)`,
                      boxShadow: `inset 0 2px 0 rgba(255,255,255,0.35), inset 0 -3px 0 rgba(120,30,0,0.4), 0 40px 120px -20px rgba(255,90,30,0.7)`,
                      display: 'flex', alignItems: 'center', gap: 28,
                    }}>
                      <div style={{
                        position: 'absolute', inset: -8, borderRadius: 36,
                        background: `conic-gradient(from ${spin}deg, transparent 0%, ${C.gold} 20%, transparent 40%, #FF5F8A 60%, transparent 80%)`,
                        filter: 'blur(24px)', opacity: 0.55,
                        zIndex: -1,
                      }}/>
                      Explore SmartCare
                      <span style={{ display: 'inline-flex', transform: `translateX(${Math.sin(lt * 3) * 8}px)` }}>
                        <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                          <line x1="5" y1="12" x2="19" y2="12"/>
                          <polyline points="12 5 19 12 12 19"/>
                        </svg>
                      </span>
                    </div>
                    <div style={{
                      fontFamily: 'Geist Mono, monospace',
                      fontSize: 36,
                      letterSpacing: '0.2em',
                      textTransform: 'uppercase',
                      color: C.cream,
                    }}>alignhcm.com/smartcare</div>
                  </div>
                );
              }}
            </Sprite>
          </div>
        );
      }}
    </Sprite>
  );
}

// ═══════════════════════════════════════════════════════════════
// Root: Scene dispatcher with persistent bg layers
// ═══════════════════════════════════════════════════════════════
function SmartCareVideo() {
  const time = useTime();
  // scene 5 (managed) uses the bright bg
  const bright = time >= 30 && time < 42 || time >= 52;
  // fade sun position across scenes
  const sunX = time < 8 ? '50%'
             : time < 18 ? '85%'
             : time < 30 ? '15%'
             : time < 42 ? '88%'
             : time < 52 ? '18%'
             : '50%';
  const sunY = time < 8 ? '38%' : '50%';
  const sunSize = time >= 52 ? 2800 : 1800;

  // update data-screen-label every second for commenting
  React.useEffect(() => {
    const root = document.querySelector('[data-video-root]');
    if (root) root.setAttribute('data-screen-label', `${Math.floor(time)}s`);
  }, [Math.floor(time)]);

  return (
    <div data-video-root style={{ position: 'absolute', inset: 0, overflow: 'hidden' }}>
      <SceneBg bright={bright}/>
      <Grid/>
      <SunGlow x={sunX} y={sunY} size={sunSize} intensity={bright ? 1.4 : 1}/>
      <Tokens dense={time < 20 || (time >= 42 && time < 52)}/>
      <Sparks count={time >= 52 ? 70 : 50}/>

      <SceneIntro/>
      <SceneHook/>
      <SceneJourney/>
      <SceneManaged/>
      <SceneTelemetry/>
      <SceneCTA/>

      <Chrome/>

      {/* top progress bar */}
      <div style={{
        position: 'absolute', top: 0, left: 0, right: 0, height: 8,
        background: 'rgba(255,255,255,0.04)',
      }}>
        <div style={{
          height: '100%',
          width: `${(time / 60) * 100}%`,
          background: `linear-gradient(90deg, ${C.gold}, ${C.orange}, #FF5F8A)`,
          boxShadow: `0 0 24px ${C.orange}`,
          transition: 'none',
        }}/>
      </div>
    </div>
  );
}

window.SmartCareVideo = SmartCareVideo;
