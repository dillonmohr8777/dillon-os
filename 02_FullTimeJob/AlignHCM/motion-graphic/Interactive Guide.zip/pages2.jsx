// ==============================================================
// Pages 3, 4, 5
// ==============================================================

function Page3({ active }) {
  const ref = React.useRef(null);

  React.useEffect(() => {
    if (!active || !ref.current) return;
    const rules = ref.current.querySelectorAll('.p3-rule');
    rules.forEach(r => r.style.opacity = 0);
    rules.forEach((r, i) => {
      setTimeout(() => {
        gsap.fromTo(r, { opacity: 0, y: 8 }, { opacity: 1, y: 0, duration: 0.5, ease: 'expo.out' });
      }, 200 + i * 70);
    });
  }, [active]);

  const base = [
    ['40h week', 'OT threshold', 'FLSA standard'],
    ['1.5×', 'OT multiplier', 'Flat rate'],
    ['None', 'Daily OT', 'Not triggered'],
    ['None', 'Weekend premium', 'Regular rate'],
    ['None', 'Rest period impact', 'Not factored'],
    ['Regular', 'Holiday pay', 'No bump'],
  ];
  const union = [
    ['8h day', 'Daily OT trigger', 'CBA Art. 7.2'],
    ['2.0×', 'Double time', 'After 12h worked'],
    ['+15%', 'Weekend premium', 'Sat, Sun, Mon 00:00'],
    ['1.5×', 'Rest-period breach', 'Under 8h turnaround'],
    ['3.0×', 'Holiday worked', '7 designated days'],
    ['Reset', 'Shift swap effect', 'OT accrual restarts'],
  ];

  return (
    <div className="page" ref={ref}>
      <div className="page__corner-mark"><strong>Chapter 03</strong> · Union Rule Sets</div>

      <div className="ph">
        <div className="ph__left">
          <span className="ph__chapter">03</span>
          <div className="ph__label">
            <strong>Union Rule Sets</strong>
            <span>Stacked rules payroll has to honor</span>
          </div>
        </div>
        <div className="ph__right">Pg. 08</div>
      </div>

      <div className="p3-hero">
        <span className="eyebrow">Chapter Three</span>
        <h2 style={{ marginTop: 10 }}>A CBA can quietly redefine every <em>overtime calculation</em> in the building.</h2>
      </div>

      <div className="p3-grid">
        <div className="p3-panel">
          <div className="p3-panel__head">
            <div className="p3-panel__name">Standard Logic</div>
            <div className="p3-panel__code">Rule Set · Base / 01</div>
          </div>
          {base.map(([v, n, c], i) => (
            <div className="p3-rule" key={i}>
              <span className="p3-rule__n">R.{String(i+1).padStart(2,'0')}</span>
              <span className="p3-rule__name">{n}<span>{c}</span></span>
              <span className="p3-rule__v">{v}</span>
            </div>
          ))}
        </div>

        <div className="p3-panel p3-panel--union">
          <div className="p3-panel__head">
            <div className="p3-panel__name">Union <em>Modified</em></div>
            <div className="p3-panel__code">Rule Set · CBA / 07</div>
          </div>
          {union.map(([v, n, c], i) => (
            <div className="p3-rule" key={i}>
              <span className="p3-rule__n">R.{String(i+1).padStart(2,'0')}</span>
              <span className="p3-rule__name">{n}<span>{c}</span></span>
              <span className="p3-rule__v">{v}</span>
            </div>
          ))}
        </div>
      </div>

      <div className="p3-compare">
        <div>
          <div className="p3-compare__v">6 rules</div>
          <div className="p3-compare__l">Federal default logic</div>
        </div>
        <div className="p3-compare__arrow">→</div>
        <div>
          <div className="p3-compare__v"><em>34 rules</em></div>
          <div className="p3-compare__l">Live inside a real CBA</div>
        </div>
      </div>

      <div className="page__folio">
        <span>Align HCM Field Guide · Vol. IV</span>
        <span className="num">08</span>
        <span>Manufacturing Payroll</span>
      </div>
    </div>
  );
}

function Page4({ active }) {
  const ref = React.useRef(null);

  React.useEffect(() => {
    if (!active || !ref.current) return;
    const rows = ref.current.querySelectorAll('.p4-feed__row');
    rows.forEach(r => r.classList.remove('is-shown'));
    rows.forEach((r, i) => setTimeout(() => r.classList.add('is-shown'), 600 + i * 180));
    const dots = ref.current.querySelectorAll('.region-dot');
    dots.forEach((d, i) => {
      d.style.opacity = 0;
      setTimeout(() => { d.style.opacity = 1; }, 400 + i * 60);
    });
  }, [active]);

  const regions = [
    {x:130,y:140,l:'CA',sev:'hi'},{x:180,y:170,l:'NV',sev:'md'},
    {x:240,y:155,l:'UT',sev:'lo'},{x:200,y:210,l:'AZ',sev:'md'},
    {x:290,y:130,l:'CO',sev:'hi'},{x:360,y:170,l:'KS',sev:'lo'},
    {x:460,y:140,l:'IL',sev:'hi'},{x:500,y:110,l:'MI',sev:'md'},
    {x:560,y:150,l:'OH',sev:'hi'},{x:400,y:225,l:'TX',sev:'hi'},
    {x:620,y:110,l:'PA',sev:'hi'},{x:660,y:90,l:'NY',sev:'hi'},
    {x:600,y:220,l:'NC',sev:'md'},{x:560,y:260,l:'GA',sev:'md'},
    {x:530,y:295,l:'FL',sev:'md'},{x:280,y:80,l:'WA',sev:'hi'},
    {x:300,y:100,l:'OR',sev:'md'},{x:340,y:70,l:'MN',sev:'md'},
  ];

  const feed = [
    ['14:02','CA-LA','Split-shift premium recorded, rest window under watch'],
    ['14:03','NY-BX','Spread-of-hours threshold crossed on shift 2'],
    ['14:05','IL-CK','Meal waiver on record, ledger reconciled'],
    ['14:06','PA-PH','Act 73 filing window at 9 days'],
    ['14:08','CO-DN','Daily OT trigger at 12h, double-time active'],
    ['14:10','OH-CV','Prevailing wage update applied'],
  ];

  return (
    <div className="page" ref={ref}>
      <div className="page__corner-mark"><strong>Chapter 04</strong> · Compliance Signals</div>

      <div className="ph">
        <div className="ph__left">
          <span className="ph__chapter">04</span>
          <div className="ph__label">
            <strong>Compliance Signals</strong>
            <span>An environment, not a rule book</span>
          </div>
        </div>
        <div className="ph__right">Pg. 10</div>
      </div>

      <div className="p4-hero">
        <h2>Compliance shows up as a continuous <em>signal stream.</em></h2>
        <p>Recordkeeping, overtime, meal and rest breaks, spread-of-hours, prevailing wage, paid sick. Each jurisdiction sends its own signal into the system. Payroll has to answer every cycle.</p>
      </div>

      <div className="p4-top">
        <div className="dash">
          <div className="dash__title">Active Jurisdictions</div>
          <div className="dash__value">18<span className="unit">live</span></div>
          <div className="dash__delta">across 3 plants</div>
        </div>
        <div className="dash">
          <div className="dash__title">Open Signals</div>
          <div className="dash__value">47<span className="unit">today</span></div>
          <div className="dash__delta">12 high priority</div>
        </div>
        <div className="dash">
          <div className="dash__title">Auto-Resolved</div>
          <div className="dash__value">94<span className="unit">%</span></div>
          <div className="dash__delta">last 30 days</div>
        </div>
      </div>

      <div className="p4-map">
        <div className="p4-map__hdr">
          <span><strong>JURISDICTION GRID</strong> · 18 regions streaming</span>
          <span className="p4-map__live">LIVE</span>
        </div>
        <svg viewBox="0 0 720 340" preserveAspectRatio="xMidYMid meet">
          <defs>
            <radialGradient id="gh"><stop offset="0%" stopColor="#F39200" stopOpacity="0.8"/><stop offset="100%" stopColor="#F39200" stopOpacity="0"/></radialGradient>
            <radialGradient id="gm"><stop offset="0%" stopColor="#F2A93B" stopOpacity="0.5"/><stop offset="100%" stopColor="#F2A93B" stopOpacity="0"/></radialGradient>
          </defs>
          {Array.from({length:18}).map((_,i)=>(<line key={'v'+i} x1={i*40} y1="0" x2={i*40} y2="340" stroke="rgba(255,255,255,0.03)"/>))}
          {Array.from({length:9}).map((_,i)=>(<line key={'h'+i} x1="0" y1={i*40} x2="720" y2={i*40} stroke="rgba(255,255,255,0.03)"/>))}
          <path d="M 70 160 L 140 100 L 260 80 L 380 90 L 500 100 L 600 115 L 670 145 L 680 200 L 650 250 L 580 290 L 480 305 L 380 295 L 290 275 L 210 245 L 150 215 L 100 190 Z"
            fill="none" stroke="rgba(246,241,231,0.1)" strokeWidth="1" strokeDasharray="3 4"/>
          {regions.map((r,i)=>{
            const col = r.sev==='hi'?'#F39200':r.sev==='md'?'#F2A93B':'#7AA3C7';
            const glow = r.sev==='hi'?'url(#gh)':r.sev==='md'?'url(#gm)':null;
            return (
              <g key={i} className="region-dot" style={{transition:'opacity 500ms'}}>
                {glow && <circle cx={r.x} cy={r.y} r="18" fill={glow}/>}
                <circle cx={r.x} cy={r.y} r="3" fill={col}>
                  {r.sev==='hi' && <animate attributeName="r" values="3;6;3" dur="2.2s" repeatCount="indefinite"/>}
                </circle>
                <text x={r.x+6} y={r.y+3} fontFamily="JetBrains Mono" fontSize="8" fill="rgba(200,196,187,0.7)">{r.l}</text>
              </g>
            );
          })}
          <circle cx="460" cy="140" r="6" fill="none" stroke="#F39200" strokeWidth="1" opacity="0.5">
            <animate attributeName="r" values="6;100;6" dur="4s" repeatCount="indefinite"/>
            <animate attributeName="opacity" values="0.6;0;0.6" dur="4s" repeatCount="indefinite"/>
          </circle>
        </svg>
      </div>

      <div className="p4-feed">
        <div className="p4-feed__hdr">
          <span>Compliance Feed · Illustrative</span>
          <span className="p4-map__live">LIVE</span>
        </div>
        {feed.map(([ts,r,m],i)=>(
          <div className="p4-feed__row" key={i}>
            <span className="ts">{ts}</span>
            <span className="reg">{r}</span>
            <span className="msg">{m}</span>
          </div>
        ))}
      </div>

      <div className="page__folio">
        <span>Align HCM Field Guide · Vol. IV</span>
        <span className="num">10</span>
        <span>Manufacturing Payroll</span>
      </div>
    </div>
  );
}

function Page5({ active }) {
  const ref = React.useRef(null);
  const [vals, setVals] = React.useState([0,0,0,0,0,0]);

  React.useEffect(() => {
    if (!active || !ref.current) return;
    setVals([0,0,0,0,0,0]);
    const targets = [428, 1.24, 6.3, 11.8, 19, 340];
    const o = { v: 0 };
    gsap.to(o, { v: 1, duration: 1.5, ease: 'expo.out', delay: 0.2,
      onUpdate: () => setVals(targets.map(t => t * o.v))
    });
    setTimeout(() => {
      ref.current?.querySelectorAll('.p5-side__fill').forEach((m, i) => {
        m.style.width = [86, 34][i] + '%';
      });
    }, 500);
    return () => gsap.killTweensOf(o);
  }, [active]);

  return (
    <div className="page" ref={ref}>
      <div className="page__corner-mark"><strong>Chapter 05</strong> · Where Time Goes</div>

      <div className="ph">
        <div className="ph__left">
          <span className="ph__chapter">05</span>
          <div className="ph__label">
            <strong>Where Time Goes</strong>
            <span>The shape of operational drag</span>
          </div>
        </div>
        <div className="ph__right">Pg. 12</div>
      </div>

      <div className="p5-hero">
        <h2>Teams lose hours first, then dollars, then trust. All three show up in the same <em>dashboard.</em></h2>
      </div>

      <div className="p5-grid">
        <div className="dash">
          <div className="dash__title">Rework / month</div>
          <div className="dash__value">{Math.round(vals[0]).toLocaleString()}<span className="unit">hrs</span></div>
          <div className="dash__delta">↑ 22% vs prior Q</div>
        </div>
        <div className="dash">
          <div className="dash__title">Exception ratio</div>
          <div className="dash__value">{vals[1].toFixed(1)}<span className="unit">%</span></div>
          <div className="dash__delta">trending upward</div>
        </div>
        <div className="dash">
          <div className="dash__title">Approval lag</div>
          <div className="dash__value">{vals[2].toFixed(1)}<span className="unit">days</span></div>
          <div className="dash__delta">baseline 2.1 days</div>
        </div>
        <div className="dash">
          <div className="dash__title">Labor leakage</div>
          <div className="dash__value">${vals[3].toFixed(1)}<span className="unit">M / yr</span></div>
          <div className="dash__delta">directional estimate</div>
        </div>
        <div className="dash">
          <div className="dash__title">Mgr. escalations</div>
          <div className="dash__value">{Math.round(vals[4])}<span className="unit">/ wk</span></div>
          <div className="dash__delta">↑ 4 vs prior</div>
        </div>
        <div className="dash">
          <div className="dash__title">Aging items</div>
          <div className="dash__value">{Math.round(vals[5])}<span className="unit">open</span></div>
          <div className="dash__delta">over 30 days</div>
        </div>
      </div>

      <div className="p5-donut">
        <div className="p5-donut__viz">
          <svg viewBox="0 0 130 130">
            <circle cx="65" cy="65" r="50" fill="none" stroke="rgba(30,27,20,0.08)" strokeWidth="16"/>
            <circle cx="65" cy="65" r="50" fill="none" stroke="#F39200" strokeWidth="16"
              strokeDasharray="188 314" strokeDashoffset="0" transform="rotate(-90 65 65)"/>
            <circle cx="65" cy="65" r="50" fill="none" stroke="#5A5443" strokeWidth="16"
              strokeDasharray="78 314" strokeDashoffset="-188" transform="rotate(-90 65 65)"/>
            <circle cx="65" cy="65" r="50" fill="none" stroke="#9A8D71" strokeWidth="16"
              strokeDasharray="48 314" strokeDashoffset="-266" transform="rotate(-90 65 65)"/>
          </svg>
          <div className="p5-donut__center">
            <div>
              <div className="v">60%</div>
              <div className="l">Config Drift</div>
            </div>
          </div>
        </div>
        <div className="p5-donut__legend">
          <div className="p5-donut__leg">
            <span className="sw" style={{background:'#F39200'}}/>
            <span>Configuration drift</span>
            <span className="v">60%</span>
          </div>
          <div className="p5-donut__leg">
            <span className="sw" style={{background:'#5A5443'}}/>
            <span>Training gaps</span>
            <span className="v">25%</span>
          </div>
          <div className="p5-donut__leg">
            <span className="sw" style={{background:'#9A8D71'}}/>
            <span>Source data quality</span>
            <span className="v">15%</span>
          </div>
        </div>
      </div>

      <div className="p5-bottom">
        <div className="p5-side">
          <div className="p5-side__tag">Config · Poor</div>
          <div className="p5-side__h">Rules get patched on top of rules. Every edge case becomes a ticket.</div>
          <div className="p5-side__meter"><div className="p5-side__fill"/></div>
        </div>
        <div className="p5-side p5-side--good">
          <div className="p5-side__tag">Config · Aligned</div>
          <div className="p5-side__h">Rules get modeled from policy. Edge cases become parameters, not fixes.</div>
          <div className="p5-side__meter"><div className="p5-side__fill"/></div>
        </div>
      </div>

      <div className="page__folio">
        <span>Align HCM Field Guide · Vol. IV</span>
        <span className="num">12</span>
        <span>Manufacturing Payroll</span>
      </div>
    </div>
  );
}

Object.assign(window, { Page3, Page4, Page5 });
