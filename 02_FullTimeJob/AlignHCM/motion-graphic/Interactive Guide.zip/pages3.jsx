// ==============================================================
// Pages 6, 7 (Configuration + CTA)
// ==============================================================

function Page6({ active }) {
  const ref = React.useRef(null);
  React.useEffect(() => {
    if (!active || !ref.current) return;
    const before = ref.current.querySelectorAll('.p6-col--before .p6-node');
    const after = ref.current.querySelectorAll('.p6-col--after .p6-node');
    gsap.fromTo(before, { opacity: 0 }, { opacity: 1, duration: 0.5, stagger: 0.07, delay: 0.2 });
    gsap.fromTo(after, { opacity: 0, x: 20 }, { opacity: 1, x: 0, duration: 0.5, stagger: 0.08, delay: 0.8 });
  }, [active]);

  const nodes = [
    { ix: 'A', name: 'Time Collection', sub: 'Clocks · Bio · Mobile' },
    { ix: 'B', name: 'Policy Layer', sub: 'CBAs · Differentials' },
    { ix: 'C', name: 'Calculation Engine', sub: 'OT · Premiums' },
    { ix: 'D', name: 'Compliance Check', sub: 'Fed · State · Local' },
    { ix: 'E', name: 'Payroll Run', sub: 'Net · Ledger · Filings' },
    { ix: 'F', name: 'Audit · Reporting', sub: 'Trace · Drill · Certify' },
  ];

  return (
    <div className="page" ref={ref}>
      <div className="page__corner-mark"><strong>Chapter 06</strong> · Configuration First</div>

      <div className="ph">
        <div className="ph__left">
          <span className="ph__chapter">06</span>
          <div className="ph__label">
            <strong>Configuration First</strong>
            <span>Platform power versus actual setup</span>
          </div>
        </div>
        <div className="ph__right">Pg. 14</div>
      </div>

      <div className="p6-hero">
        <h2>The platform rarely breaks. The <em>setup</em> does.</h2>
      </div>

      <div className="p6-cols">
        <div className="p6-col p6-col--before">
          <div className="p6-col__lbl">Before · Tangled</div>
          {nodes.map((n, i) => (
            <div className="p6-node" key={i}>
              <div className="p6-node__ix">{n.ix}</div>
              <div className="p6-node__name">{n.name}<span>{n.sub}</span></div>
              <div className="p6-node__st">Drift</div>
            </div>
          ))}
        </div>

        <div className="p6-arrow">
          <svg viewBox="0 0 36 36" fill="none" width="36" height="36">
            <circle cx="18" cy="18" r="16" stroke="rgba(243,146,0,0.3)"/>
            <path d="M 10 18 L 26 18 M 22 14 L 26 18 L 22 22" stroke="#F39200" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"/>
          </svg>
        </div>

        <div className="p6-col p6-col--after">
          <div className="p6-col__lbl">After · Aligned</div>
          {nodes.map((n, i) => (
            <div className="p6-node" key={i}>
              <div className="p6-node__ix">{n.ix}</div>
              <div className="p6-node__name">{n.name}<span>{n.sub}</span></div>
              <div className="p6-node__st">Clean</div>
            </div>
          ))}
        </div>
      </div>

      <div className="p6-bottom">
        <div className="dash">
          <div className="dash__title">Time to close payroll</div>
          <div className="dash__value">2.1<span className="unit">days</span></div>
          <div className="dash__delta">from 4.8 days</div>
        </div>
        <div className="dash">
          <div className="dash__title">Retro adjustments</div>
          <div className="dash__value">-72<span className="unit">%</span></div>
          <div className="dash__delta">run over run</div>
        </div>
        <div className="dash">
          <div className="dash__title">Audit traceability</div>
          <div className="dash__value">100<span className="unit">%</span></div>
          <div className="dash__delta">policy to paycheck</div>
        </div>
      </div>

      <div className="page__folio">
        <span>Align HCM Field Guide · Vol. IV</span>
        <span className="num">14</span>
        <span>Manufacturing Payroll</span>
      </div>
    </div>
  );
}

function Page7() {
  return (
    <div className="page">
      <div className="page__corner-mark"><strong>Chapter 07</strong> · Work With Align</div>

      <div className="ph">
        <div className="ph__left">
          <span className="ph__chapter">07</span>
          <div className="ph__label">
            <strong>Work With Align</strong>
            <span>From field guide to implementation</span>
          </div>
        </div>
        <div className="ph__right">Pg. 16</div>
      </div>

      <div className="p7">
        <div className="p7__eyebrow">Final chapter · Next step</div>
        <h2 className="p7__title">
          Let us help you get your manufacturing payroll <em>aligned.</em>
        </h2>
        <p className="p7__body">
          This guide covered three areas where manufacturing payroll teams lose the most time and money, plus what better configuration looks like inside a live HCM environment. The next step is simple.
        </p>

        <div className="p7__steps">
          <div className="p7__step">
            <div className="p7__step-n">01</div>
            <div className="p7__step-t">Assess your setup</div>
            <div className="p7__step-b">Walk through current configuration with an Align consultant. Ninety minutes, no cost, no sales pitch.</div>
          </div>
          <div className="p7__step">
            <div className="p7__step-n">02</div>
            <div className="p7__step-t">Scope the fix</div>
            <div className="p7__step-b">Targeted remediation or a full re-implementation, mapped to your specific policy stack and timelines.</div>
          </div>
          <div className="p7__step">
            <div className="p7__step-n">03</div>
            <div className="p7__step-t">Align the system</div>
            <div className="p7__step-b">Your team keeps running payroll while we clean up the config underneath. No surprise cutovers.</div>
          </div>
        </div>

        <div className="p7__cta-wrap">
          <div>
            <div className="p7__cta-h">Ready to get your payroll <em>aligned?</em></div>
            <div className="p7__cta-s">Email hello@alignhcm.com or book time at alignhcm.com/connect</div>
          </div>
          <a className="p7__cta-btn" href="#">
            Book a Config Review
            <svg viewBox="0 0 16 16" fill="none" width="14" height="14"><path d="M3 8h10 M9 4l4 4-4 4" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/></svg>
          </a>
        </div>

        <div className="p7__foot">
          <div>
            <strong>Align HCM</strong><br/>
            HR, payroll, and workforce management<br/>
            for complex environments<br/>
            alignhcm.com
          </div>
          <img src={(window.__resources && window.__resources.alignLogo) || "align-logo-white.png"} className="p7__foot-logo" alt="Align HCM"/>
        </div>
      </div>
    </div>
  );
}

Object.assign(window, { Page6, Page7 });
