// ==============================================================
// App — 8.5x11 single-page book with smooth page-flip mechanic
// ==============================================================

const TOTAL = 8; // cover + 7 pages
const CHAPTERS = [
  { label: 'Cover' },
  { label: 'Problem Surface' },
  { label: 'Differentials' },
  { label: 'Union Rules' },
  { label: 'Compliance' },
  { label: 'Time & Money' },
  { label: 'Configuration' },
  { label: 'Work With Align' },
];
const DURATIONS = [10, 12, 13, 14, 14, 13, 13, 18];

// Ambient background canvas
function Ambient() {
  const ref = React.useRef(null);
  React.useEffect(() => {
    const c = ref.current; if (!c) return;
    const ctx = c.getContext('2d');
    c.width = 1400; c.height = 960;
    const N = 50;
    const P = Array.from({length:N}, () => ({
      x: Math.random()*1400, y: Math.random()*960,
      vx: (Math.random()-0.5)*0.1, vy: (Math.random()-0.5)*0.05,
      r: Math.random()*1.2+0.2, a: Math.random()*0.35+0.1,
      o: Math.random() < 0.2,
    }));
    let raf;
    const tick = () => {
      ctx.clearRect(0,0,1400,960);
      for (const p of P) {
        p.x += p.vx; p.y += p.vy;
        if (p.x < 0) p.x = 1400; if (p.x > 1400) p.x = 0;
        if (p.y < 0) p.y = 960; if (p.y > 960) p.y = 0;
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.r, 0, Math.PI*2);
        ctx.fillStyle = p.o ? `rgba(243,146,0,${p.a})` : `rgba(200,196,187,${p.a*0.4})`;
        ctx.fill();
      }
      raf = requestAnimationFrame(tick);
    };
    tick();
    return () => cancelAnimationFrame(raf);
  }, []);
  return <canvas ref={ref} className="atm-canvas"/>;
}

// Ambient data lines — flowing orange horizontals + pulsing nodes
function DataLines() {
  const lines = [
    { top: '12%', delay: 0, dur: 14 },
    { top: '28%', delay: 3, dur: 17 },
    { top: '47%', delay: 7, dur: 13 },
    { top: '66%', delay: 1, dur: 19 },
    { top: '84%', delay: 9, dur: 15 },
  ];
  const nodes = [
    { top: '18%', left: '12%', delay: 0 },
    { top: '38%', left: '86%', delay: 1.4 },
    { top: '62%', left: '22%', delay: 2.1 },
    { top: '74%', left: '78%', delay: 0.7 },
    { top: '22%', left: '64%', delay: 2.8 },
  ];
  return (
    <div className="data-lines">
      {lines.map((l, i) => (
        <div key={'l'+i} className="data-lines__line"
             style={{ top: l.top, animationDelay: l.delay+'s', animationDuration: l.dur+'s' }}/>
      ))}
      {nodes.map((n, i) => (
        <div key={'n'+i} className="data-node"
             style={{ top: n.top, left: n.left, animationDelay: n.delay+'s' }}/>
      ))}
    </div>
  );
}

function Chrome({ current }) {
  const [t, setT] = React.useState(new Date());
  React.useEffect(() => { const id = setInterval(() => setT(new Date()), 1000); return () => clearInterval(id); }, []);
  return (
    <div className="chrome">
      <img src={(window.__resources && window.__resources.alignLogo) || "align-logo-white.png"} className="chrome__logo-img" alt="Align HCM"/>
      <div className="chrome__meta">
        <span>Field Guide <strong>07/12</strong></span>
        <span>Page <strong>{String(current+1).padStart(2,'0')} / {String(TOTAL).padStart(2,'0')}</strong></span>
        <span className="chrome__live"><span className="chrome__live-dot"/>LIVE</span>
        <span style={{fontVariantNumeric:'tabular-nums'}}>{t.toLocaleTimeString('en-US',{hour12:false})}</span>
      </div>
    </div>
  );
}

function ChapterRail({ current, onPick }) {
  return (
    <div className="chapter-rail">
      {CHAPTERS.map((c, i) => (
        <button key={i} className={'chapter-tab' + (i === current ? ' is-active' : '')} onClick={() => onPick(i)}>
          <span className="chapter-tab__num">{String(i).padStart(2,'0')}</span>
          <span className="chapter-tab__lbl">{c.label}</span>
        </button>
      ))}
    </div>
  );
}

function renderPage(i, active) {
  if (i === 0) return <PageCover/>;
  if (i === 1) return <Page1/>;
  if (i === 2) return <Page2 active={active}/>;
  if (i === 3) return <Page3 active={active}/>;
  if (i === 4) return <Page4 active={active}/>;
  if (i === 5) return <Page5 active={active}/>;
  if (i === 6) return <Page6 active={active}/>;
  if (i === 7) return <Page7/>;
  return null;
}

function App() {
  const [scale, setScale] = React.useState(1);
  const [current, setCurrent] = React.useState(() => {
    const v = parseInt(localStorage.getItem('align:pg') || '0', 10);
    return isNaN(v) ? 0 : Math.min(TOTAL - 1, Math.max(0, v));
  });
  const [autoplay, setAutoplay] = React.useState(true);
  const [flipping, setFlipping] = React.useState(false);
  const [flipDir, setFlipDir] = React.useState(1); // 1 = forward
  const [flipSrc, setFlipSrc] = React.useState(null); // page index showing on flip-front

  React.useEffect(() => {
    const measure = () => {
      const s = Math.min(window.innerWidth / 1400, window.innerHeight / 960);
      setScale(s);
    };
    measure();
    window.addEventListener('resize', measure);
    return () => window.removeEventListener('resize', measure);
  }, []);

  React.useEffect(() => { localStorage.setItem('align:pg', String(current)); }, [current]);

  // Autoplay
  React.useEffect(() => {
    if (!autoplay || flipping) return;
    const dur = DURATIONS[current] * 1000;
    const id = setTimeout(() => {
      if (current < TOTAL - 1) goTo(current + 1, 1);
      else setAutoplay(false);
    }, dur);
    return () => clearTimeout(id);
  }, [autoplay, current, flipping]);

  const flipRef = React.useRef(null);

  const goTo = (next, dir = 1) => {
    if (flipping || next === current || next < 0 || next >= TOTAL) return;
    setFlipDir(dir);
    setFlipSrc(dir === 1 ? current : next);
    setFlipping(true);

    // Run flip animation
    requestAnimationFrame(() => {
      const el = flipRef.current;
      if (!el) { setFlipping(false); setCurrent(next); return; }

      if (dir === 1) {
        // Forward: flip starts flat, rotates to -180
        gsap.fromTo(el,
          { rotateY: 0 },
          { rotateY: -180, duration: 0.85, ease: 'power3.inOut',
            onComplete: () => {
              setCurrent(next);
              setFlipping(false);
              setFlipSrc(null);
            }
          });
      } else {
        // Backward: flip starts at -180, rotates to 0
        gsap.fromTo(el,
          { rotateY: -180 },
          { rotateY: 0, duration: 0.85, ease: 'power3.inOut',
            onComplete: () => {
              setCurrent(next);
              setFlipping(false);
              setFlipSrc(null);
            }
          });
      }
    });
  };

  const onPrev = () => { setAutoplay(false); goTo(current - 1, -1); };
  const onNext = () => { setAutoplay(false); goTo(current + 1, 1); };

  React.useEffect(() => {
    const onKey = (e) => {
      if (e.key === 'ArrowRight' || e.key === ' ') { e.preventDefault(); setAutoplay(false); goTo(current + 1, 1); }
      else if (e.key === 'ArrowLeft') { e.preventDefault(); setAutoplay(false); goTo(current - 1, -1); }
      else if (e.key >= '1' && e.key <= '8') { setAutoplay(false); const n = parseInt(e.key) - 1; goTo(n, n > current ? 1 : -1); }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [current, flipping]);

  // Tweaks
  const [tweaks, setTweaks] = React.useState(() => window.__TWEAKS || {
    lightning: 'on', autoplay: true, palette: 'ink'
  });
  const [editMode, setEditMode] = React.useState(false);
  const [tweaksOpen, setTweaksOpen] = React.useState(false);
  React.useEffect(() => {
    const onMsg = (e) => {
      if (e.data?.type === '__activate_edit_mode') setEditMode(true);
      if (e.data?.type === '__deactivate_edit_mode') { setEditMode(false); setTweaksOpen(false); }
    };
    window.addEventListener('message', onMsg);
    window.parent.postMessage({ type: '__edit_mode_available' }, '*');
    return () => window.removeEventListener('message', onMsg);
  }, []);
  const setTweak = (k, v) => {
    const next = { ...tweaks, [k]: v };
    setTweaks(next);
    window.parent.postMessage({ type: '__edit_mode_set_keys', edits: { [k]: v } }, '*');
  };

  const lightningOn = tweaks.lightning !== 'off';

  return (
    <div className="stage-wrap">
      <div className="stage" style={{transform:`translate(-50%,-50%) scale(${scale})`}} data-screen-label={`${String(current+1).padStart(2,'0')} ${CHAPTERS[current].label}`}>
        <div className="vignette"/>
        <Chrome current={current}/>

        {/* autoplay button removed */}
        {false && <button/>}

        <div className="nav-side is-left">
          <button className="nav-btn" onClick={onPrev} disabled={current === 0 || flipping}>
            <svg viewBox="0 0 14 14"><path d="M10 2L4 7l6 5V2z" fill="currentColor"/></svg>
          </button>
        </div>
        <div className="nav-side is-right">
          <button className="nav-btn" onClick={onNext} disabled={current === TOTAL - 1 || flipping}>
            <svg viewBox="0 0 14 14"><path d="M4 2l6 5-6 5V2z" fill="currentColor"/></svg>
          </button>
        </div>

        <div className="book-area">
          <div className="book-shadow"/>

          {/* Base page: shows current, or next (during forward flip) / previous (during back flip) */}
          <div className="page-base" style={{position:'absolute', inset: 0}}>
            {flipping && flipDir === 1
              ? renderPage(current + 1 >= TOTAL ? current : current + 1, false)
              : flipping && flipDir === -1
                ? renderPage(Math.max(0, current - 1), false)
                : renderPage(current, !flipping)}
          </div>

          {/* Lightning removed per user request */}

          {/* Flipping page */}
          {flipping && flipSrc != null && (
            <div className="page-flip" ref={flipRef}>
              <div className="page-flip__face page-flip__front">
                {renderPage(flipSrc, false)}
              </div>
              <div className="page-flip__face page-flip__back"/>
            </div>
          )}
        </div>

        <ChapterRail current={current} onPick={(i) => { setAutoplay(false); goTo(i, i > current ? 1 : -1); }}/>
      </div>

      {editMode && (
        <>
          <button className="tweaks-fab is-visible" onClick={() => setTweaksOpen(o => !o)}>
            <svg width="16" height="16" viewBox="0 0 18 18" fill="none"><path d="M9 2l1.5 3.5L14 7l-3.5 1.5L9 12 7.5 8.5 4 7l3.5-1.5L9 2z" stroke="currentColor" strokeWidth="1.2"/></svg>
          </button>
          <div className={'tweaks-panel' + (tweaksOpen ? ' is-open' : '')}>
            <h3>Tweaks</h3>
            <label>Lightning</label>
            <select value={tweaks.lightning} onChange={e => setTweak('lightning', e.target.value)}>
              <option value="on">On · Natural</option>
              <option value="off">Off</option>
            </select>
            <label>Auto-play</label>
            <select value={tweaks.autoplay ? 'on' : 'off'} onChange={e => { setTweak('autoplay', e.target.value === 'on'); setAutoplay(e.target.value === 'on'); }}>
              <option value="on">On</option>
              <option value="off">Off</option>
            </select>
            <label>Palette</label>
            <select value={tweaks.palette} onChange={e => setTweak('palette', e.target.value)}>
              <option value="ink">Ink Studio (default)</option>
              <option value="dossier">Dossier Warm</option>
              <option value="foundry">Foundry Black</option>
            </select>
          </div>
        </>
      )}
    </div>
  );
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<App/>);

Object.assign(window, { App });
