// ==============================================================
// Pages — cover + 7 content pages, 8.5x11 portrait
// Copy: natural language, no em dashes, no "it is/do not/that is"
// ==============================================================

// Lightning generator — strikes around a target box
function LightningBurst({ active }) {
  const [bolts, setBolts] = React.useState([]);
  const ref = React.useRef(null);

  React.useEffect(() => {
    if (!active) return;

    const generate = () => {
      const newBolts = [];
      const count = 2 + Math.floor(Math.random() * 2);
      const sides = ['top', 'right', 'bottom', 'left'];

      for (let i = 0; i < count; i++) {
        const side = sides[Math.floor(Math.random() * 4)];
        let x1, y1, x2, y2;

        if (side === 'top') {
          x1 = 50 + Math.random() * 620;
          y1 = -30 - Math.random() * 40;
          x2 = x1 + (Math.random() - 0.5) * 80;
          y2 = 20 + Math.random() * 30;
        } else if (side === 'bottom') {
          x1 = 50 + Math.random() * 620;
          y1 = 810 + Math.random() * 40;
          x2 = x1 + (Math.random() - 0.5) * 80;
          y2 = 770 - Math.random() * 30;
        } else if (side === 'left') {
          x1 = -30 - Math.random() * 40;
          y1 = 80 + Math.random() * 700;
          x2 = 20 + Math.random() * 30;
          y2 = y1 + (Math.random() - 0.5) * 80;
        } else {
          x1 = 720 + Math.random() * 40;
          y1 = 80 + Math.random() * 700;
          x2 = 700 - Math.random() * 30;
          y2 = y1 + (Math.random() - 0.5) * 80;
        }

        // Build jagged path between endpoints
        const segs = 5 + Math.floor(Math.random() * 3);
        let d = `M ${x1.toFixed(1)} ${y1.toFixed(1)}`;
        for (let s = 1; s < segs; s++) {
          const t = s / segs;
          const lx = x1 + (x2 - x1) * t + (Math.random() - 0.5) * 28;
          const ly = y1 + (y2 - y1) * t + (Math.random() - 0.5) * 28;
          d += ` L ${lx.toFixed(1)} ${ly.toFixed(1)}`;
          // occasional fork
          if (Math.random() < 0.3 && s < segs - 1) {
            const fx = lx + (Math.random() - 0.5) * 40;
            const fy = ly + (Math.random() - 0.5) * 40;
            d += ` M ${lx.toFixed(1)} ${ly.toFixed(1)} L ${fx.toFixed(1)} ${fy.toFixed(1)} M ${lx.toFixed(1)} ${ly.toFixed(1)}`;
          }
        }
        d += ` L ${x2.toFixed(1)} ${y2.toFixed(1)}`;
        newBolts.push({ d, id: Math.random(), width: 0.8 + Math.random() * 1.2 });
      }
      setBolts(newBolts);
      setTimeout(() => setBolts([]), 180);
    };

    const firstDelay = 1200 + Math.random() * 1400;
    const timers = [];
    timers.push(setTimeout(() => {
      generate();
      const interval = setInterval(() => {
        if (Math.random() < 0.55) generate();
      }, 2800 + Math.random() * 2400);
      timers.push(interval);
    }, firstDelay));

    return () => timers.forEach(t => { clearTimeout(t); clearInterval(t); });
  }, [active]);

  return (
    <svg className="lightning-svg" viewBox="0 0 720 932" preserveAspectRatio="none" ref={ref}>
      {bolts.map(b => (
        <path key={b.id} d={b.d} style={{ strokeWidth: b.width }}>
          <animate attributeName="opacity" values="0;1;0.2;1;0" dur="0.18s" repeatCount="1"/>
        </path>
      ))}
    </svg>
  );
}

// ────────────────────────────────────────────────────────────────
// COVER
// ────────────────────────────────────────────────────────────────
function PageCover() {
  return (
    <div className="page">
      <div className="cover">
        <div className="cover__top">
          <img src={(window.__resources && window.__resources.alignLogo) || "align-logo-white.png"} className="cover__logo" alt="Align HCM"/>
          <div className="cover__meta-r">
            <strong>Field Guide</strong><br/>
            Manufacturing Series<br/>
            Edition 07 / Vol. IV
          </div>
        </div>

        <div className="cover__center">
          <div className="cover__kicker">For payroll and HR leaders on the plant floor</div>
          <h1 className="cover__title">
            Manufacturing payroll means more than <em>cutting checks.</em>
          </h1>
          <p className="cover__sub">
            Shift differentials, union agreements, and compliance rules all live inside every paycheck.
            Here is the field guide for teams who want those paychecks to come out right the first time.
          </p>

          <div className="cover__chapters">
            {[
              ['01', 'The Problem Surface'],
              ['02', 'Shift Differentials'],
              ['03', 'Union Rule Sets'],
              ['04', 'Compliance Signals'],
              ['05', 'Where Time Goes'],
              ['06', 'Configuration First'],
              ['07', 'Work With Align'],
            ].map(([n, t]) => (
              <div className="cover__chapter" key={n}>
                <span className="n">{n}</span>
                <span className="t">{t}</span>
              </div>
            ))}
          </div>
        </div>

        <div className="cover__bottom">
          <div className="cover__bottom-l">
            Published by<br/>
            <strong>Align HCM</strong><br/>
            HR, Payroll & Workforce Management
          </div>
          <div>
            <div className="cover__edition-sub">Spring · 2026</div>
          </div>
        </div>
      </div>
    </div>
  );
}

// ────────────────────────────────────────────────────────────────
// PAGE 1 — Problem Surface
// ────────────────────────────────────────────────────────────────
function Page1() {
  const items = [
    { n: '01', tag: 'Shifts', title: 'Three shifts, three pay models',
      desc: 'First, second, and third shift each come with their own premium math, meal windows, and bump-up rules.' },
    { n: '02', tag: 'Premiums', title: 'Differentials shift by role and site',
      desc: 'A machine operator covering QA triggers a different rate. Hours crossing a shift boundary split across two premiums.' },
    { n: '03', tag: 'Union', title: 'Agreements redefine overtime',
      desc: 'Contract language can reshape daily overtime, double-time thresholds, rest premiums, and holiday math.' },
    { n: '04', tag: 'Compliance', title: 'Federal rules will never be enough',
      desc: 'State, county, and industry thresholds layer on top. They conflict with each other, and they change every year.' },
  ];

  return (
    <div className="page">
      <div className="page__corner-mark"><strong>Chapter 01</strong> · The Problem Surface</div>

      <div className="ph">
        <div className="ph__left">
          <span className="ph__chapter">01</span>
          <div className="ph__label">
            <strong>The Problem Surface</strong>
            <span>Why manufacturing payroll feels different</span>
          </div>
        </div>
      </div>

      <div className="p1-hero">
        <span className="eyebrow">Chapter One</span>
        <h2 style={{ marginTop: 10 }}>Payroll breaks <em>before</em> payroll runs.</h2>
        <p>
          Most manufacturing payroll errors never start in the payroll system. They start upstream, inside how
          shift rules, policies, contracts, and compliance layers got translated into system configuration months
          or years before anyone noticed the problem.
        </p>
      </div>

      <div className="p1-grid">
        {items.map((it) => (
          <div className="p1-card" key={it.n}>
            <div className="p1-card__top">
              <span className="p1-card__num">{it.n}</span>
              <span className="p1-card__tag">{it.tag}</span>
            </div>
            <div className="p1-card__title">{it.title}</div>
            <div className="p1-card__body">{it.desc}</div>
          </div>
        ))}
      </div>

      <div className="p1-strip">
        <div>
          <div className="p1-strip__v"><em>90</em></div>
          <div className="p1-strip__l">Rule paths per<br/>pay period</div>
        </div>
        <div>
          <div className="p1-strip__v"><em>3×</em></div>
          <div className="p1-strip__l">Average retro<br/>adjustments</div>
        </div>
        <div>
          <div className="p1-strip__v"><em>5</em></div>
          <div className="p1-strip__l">Layers of<br/>complexity stacked</div>
        </div>
      </div>

      <div className="page__folio">
        <span>Align HCM Field Guide · Vol. IV</span>
        <span className="num">04</span>
        <span>Manufacturing Payroll</span>
      </div>
    </div>
  );
}

// ────────────────────────────────────────────────────────────────
// PAGE 2 — Shift Differentials
// ────────────────────────────────────────────────────────────────
function Page2({ active }) {
  const ref = React.useRef(null);
  const [eq, setEq] = React.useState({ base: 0, prem: 0, ot: 0, gross: 0 });

  React.useEffect(() => {
    if (!active || !ref.current) return;
    ref.current.querySelectorAll('.p2-bar').forEach(b => b.style.height = '0%');
    const heights = [[58,62,66],[55,68,78],[60,74,88],[52,70,84],[48,66,82]];
    const groups = ref.current.querySelectorAll('.p2-bargroup');
    groups.forEach((g, gi) => {
      g.querySelectorAll('.p2-bar').forEach((b, bi) => {
        setTimeout(() => { b.style.height = heights[gi][bi] + '%'; }, 300 + gi * 120 + bi * 40);
      });
    });
    const tl = { v: 0 };
    gsap.to(tl, { v: 1, duration: 1.5, ease: 'expo.out', delay: 0.4,
      onUpdate: () => setEq({
        base: Math.round(1240 * tl.v),
        prem: Math.round(186 * tl.v),
        ot: Math.round(314 * tl.v),
        gross: Math.round(1740 * tl.v),
      })
    });
    return () => gsap.killTweensOf(tl);
  }, [active]);

  const usd = (n) => '$' + n.toLocaleString();

  return (
    <div className="page" ref={ref}>
      <div className="page__corner-mark"><strong>Chapter 02</strong> · Shift Differentials</div>

      <div className="ph">
        <div className="ph__left">
          <span className="ph__chapter">02</span>
          <div className="ph__label">
            <strong>Shift Differentials</strong>
            <span>A bar chart that never stays still</span>
          </div>
        </div>
        <div className="ph__right">Pg. 06</div>
      </div>

      <div className="p2-hero">
        <h2 className="anim-headline">
          {'Differentials sound simple, until the rules change per site, per role, and per shift.'.split(' ').map((w,i)=>(
            <span key={i} className="anim-word" style={{animationDelay: (0.05 + i*0.035)+'s'}}>{w}&nbsp;</span>
          ))}
          <span className="anim-underline"/>
        </h2>
      </div>

      <div className="p2-kpis">
        <CountDash active={active} title="Roles Tracked" target={24} unit="roles" delta="across 3 plants" delay={0}/>
        <CountDash active={active} title="Active Shifts" target={3} unit="lines" delta="24h coverage" delay={100}/>
        <CountDash active={active} title="Rule Combinations" target={90} unit="paths" delta="per pay cycle" delay={200}/>
        <CountDash active={active} title="Weekly Hours" target={1.8} suffix="k" unit="hrs" delta="avg plant volume" delay={300}/>
      </div>

      <div className="p2-chart">
        <div className="p2-chart__head">
          <span className="p2-chart__title">Hourly pay composition · sample week</span>
          <div className="p2-chart__legend">
            <span><span className="p2-legend-sw a"/>Base</span>
            <span><span className="p2-legend-sw b"/>Differential</span>
            <span><span className="p2-legend-sw c"/>OT Premium</span>
          </div>
        </div>
        <div className="p2-chart__body">
          <div className="p2-y">
            <span>$48</span><span>$36</span><span>$24</span><span>$12</span><span>$0</span>
          </div>
          <div className="p2-bars">
            {[['Line Op','P-04'],['Machine','P-04'],['QA Tech','P-11'],['Maint.','P-11'],['Forklift','P-18']].map(([r,p],i)=>(
              <div className="p2-bargroup" key={i} data-l={r + ' / ' + p}>
                <div className="p2-bar"/>
                <div className="p2-bar b"/>
                <div className="p2-bar c"/>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="p2-equation">
        <div className="p2-equation__cell">
          <div className="p2-equation__v">{usd(eq.base)}</div>
          <div className="p2-equation__l">Base · 40h</div>
        </div>
        <div className="p2-equation__op">+</div>
        <div className="p2-equation__cell">
          <div className="p2-equation__v">{usd(eq.prem)}</div>
          <div className="p2-equation__l">Premium · 15%</div>
        </div>
        <div className="p2-equation__op">+</div>
        <div className="p2-equation__cell">
          <div className="p2-equation__v">{usd(eq.ot)}</div>
          <div className="p2-equation__l">OT · 6.75h</div>
        </div>
        <div className="p2-equation__op">=</div>
        <div className="p2-equation__cell p2-equation__total">
          <div className="p2-equation__v">{usd(eq.gross)}</div>
          <div className="p2-equation__l">Gross · illustrative</div>
        </div>
      </div>

      <div className="page__folio">
        <span>Align HCM Field Guide · Vol. IV</span>
        <span className="num">06</span>
        <span>Manufacturing Payroll</span>
      </div>
    </div>
  );
}

// Animated headline: word-by-word blur→sharp with orange underline sweep
function AnimHeadline({ children, className = '', style, delay = 0 }) {
  // Parse children into words, preserving <em> spans
  const tokens = [];
  const push = (text, italic = false) => {
    text.split(' ').filter(Boolean).forEach((w, i, arr) => {
      tokens.push({ w, italic });
    });
  };
  React.Children.forEach(children, (child) => {
    if (typeof child === 'string') push(child, false);
    else if (child && child.props && child.type === 'em') {
      push(child.props.children, true);
    } else if (child && child.props) {
      push(String(child.props.children || ''), false);
    }
  });
  return (
    <h2 className={'anim-headline ' + className} style={style}>
      {tokens.map((t, i) => (
        <span key={i} className="anim-word"
              style={{ animationDelay: (delay + 0.05 + i * 0.035) + 's', fontStyle: t.italic ? 'italic' : undefined, color: t.italic ? 'var(--align-orange-deep)' : undefined }}>
          {t.w}&nbsp;
        </span>
      ))}
      <span className="anim-underline" style={{animationDelay: (delay + 0.5) + 's'}}/>
    </h2>
  );
}

// Live-counting dashboard card
function CountDash({ active, title, target, unit, delta, delay = 0, suffix = '', decimals = 0, prefix = '' }) {
  const [v, setV] = React.useState(0);
  React.useEffect(() => {
    if (!active) { setV(0); return; }
    const obj = { n: 0 };
    const tw = gsap.to(obj, { n: target, duration: 1.4, delay: delay/1000 + 0.2, ease: 'expo.out',
      onUpdate: () => setV(obj.n) });
    return () => tw.kill();
  }, [active, target]);
  const display = decimals > 0 ? v.toFixed(decimals) : Math.round(v).toLocaleString();
  return (
    <div className="dash dash--live">
      <div className="dash__title">{title}<span className="dash__pulse"/></div>
      <div className="dash__value">{prefix}{display}{suffix}<span className="unit">{unit}</span></div>
      <div className="dash__delta">{delta}</div>
      <div className="dash__scan"/>
    </div>
  );
}

Object.assign(window, { AnimHeadline, CountDash });

Object.assign(window, { LightningBurst, PageCover, Page1, Page2, CountDash });
