// HCM Maturity Assessment — auto-play timeline
(function(){
  const QUESTIONS = [
    {cat:'System Adoption', q:"How much of your HCM platform is your team actively using?",
      opts:["Less than 30%","About half","Most modules","Fully adopted"], pick:2, score:3},
    {cat:'Manual Work', q:"How often does your team use spreadsheets for tasks the system should handle?",
      opts:["Daily","A few times weekly","Occasionally","Rarely or never"], pick:2, score:3},
    {cat:'Reporting', q:"How confident are you in the accuracy of your HCM reports?",
      opts:["Don't trust data","Some reliable","Mostly accurate","Leadership relies on it"], pick:2, score:3},
    {cat:'Support Load', q:"How would you describe your HCM support ticket volume?",
      opts:["Overwhelmed","Steady recurring","Manageable","Minimal"], pick:2, score:3},
    {cat:'Workflows', q:"How well do configured workflows match how your org operates?",
      opts:["Major gaps","Some work","Mostly functional","Reflect processes"], pick:2, score:3},
    {cat:'Integrations', q:"How stable are your HCM integrations with payroll and benefits?",
      opts:["Frequent errors","Occasional issues","Generally stable","Fully monitored"], pick:2, score:3},
    {cat:'Config Drift', q:"When policies change, how quickly does the system get updated?",
      opts:["Months behind","Some slip through","Within weeks","Defined process"], pick:2, score:3},
    {cat:'Training', q:"How well equipped is your team to use the system effectively?",
      opts:["Still struggling","Power users fine","Role-based","Ongoing with docs"], pick:1, score:2},
    {cat:'Efficiency', q:"How long do key processes take vs. expectations?",
      opts:["Significantly longer","Somewhat slower","Close to target","Meeting goals"], pick:2, score:3},
    {cat:'Readiness', q:"Is your platform ready to support 12 to 18 months of growth?",
      opts:["Hitting limits","Needs reconfig","Mostly ready","Built for future"], pick:2, score:3}
  ];

  // ========== DOM ==========
  const $ = s => document.querySelector(s);
  const intro = $('#intro');
  const runtime = $('#runtime');
  const results = $('#results');
  const stage = $('#stage');
  const cardWrap = $('#qcardWrap');
  const card = $('#qcard');
  const qmeta = $('#qmeta');
  const qnum = $('#qnum');
  const qcat = $('#qcat');
  const qtext = $('#qtext');
  const qghost = $('#qghost');
  const qopts = $('#qopts');
  const qCountEl = $('#qCount');
  const scoreNowEl = $('#scoreNow');
  const ansNowEl = $('#ansNow');
  const ladder = $('#ladder');
  const speed = $('#speed');
  const flash = $('#flash');
  const lightning = $('#lightning');
  const lctx = lightning.getContext('2d');
  const ringFill = $('#ringFill');
  const ringScore = $('#ringScore');
  const track = $('#track');

  // Ladder segments
  for(let i=0;i<10;i++){
    const s = document.createElement('div');
    s.className = 'seg';
    s.dataset.i = i;
    ladder.appendChild(s);
  }
  const segs = Array.from(ladder.children);

  // ========== HELPERS ==========
  function wait(ms){ return new Promise(r=>setTimeout(r,ms)); }
  function pad(n){ return String(n).padStart(2,'0'); }

  function sweepSpeed(){
    speed.classList.remove('go');
    void speed.offsetWidth;
    speed.classList.add('go');
  }
  function flashGo(){
    flash.classList.remove('go');
    void flash.offsetWidth;
    flash.classList.add('go');
  }
  function shakeGo(){
    stage.classList.remove('shake');
    void stage.offsetWidth;
    stage.classList.add('shake');
    setTimeout(()=>stage.classList.remove('shake'),260);
  }

  function tween(from,to,ms,cb,done){
    const t0 = performance.now();
    function step(t){
      const k = Math.min(1,(t-t0)/ms);
      const e = 1-Math.pow(1-k,3); // ease-out cubic
      cb(from + (to-from)*e);
      if(k<1) requestAnimationFrame(step);
      else if(done) done();
    }
    requestAnimationFrame(step);
  }

  function setScore(to){
    const from = parseInt(scoreNowEl.textContent,10)||0;
    tween(from,to,440,v=>{ scoreNowEl.textContent = Math.round(v); });
  }
  function setAnswered(to){
    ansNowEl.textContent = to;
  }

  // ========== LIGHTNING (on answer) ==========
  function sizeLightning(){
    const r = card.getBoundingClientRect();
    lightning.width = (r.width+20)*2;
    lightning.height = (r.height+20)*2;
    lightning.style.width = (r.width+20)+'px';
    lightning.style.height = (r.height+20)+'px';
    lctx.setTransform(2,0,0,2,0,0);
  }

  function drawBolt(x1,y1,x2,y2,displace,detail){
    if(displace < detail){
      lctx.lineTo(x2,y2); return;
    }
    const mx = (x1+x2)/2 + (Math.random()-0.5)*displace;
    const my = (y1+y2)/2 + (Math.random()-0.5)*displace;
    drawBolt(x1,y1,mx,my,displace/2,detail);
    drawBolt(mx,my,x2,y2,displace/2,detail);
  }

  function lightningBurst(){
    sizeLightning();
    const w = lightning.clientWidth, h = lightning.clientHeight;
    const t0 = performance.now();
    const DUR = 600;
    function frame(t){
      const k = (t-t0)/DUR;
      if(k>=1){ lctx.clearRect(0,0,w,h); return; }
      lctx.clearRect(0,0,w,h);
      const alpha = Math.max(0,1 - Math.pow(k,2));

      // choose perimeter points
      const edges = [];
      const step = 40;
      for(let x=0;x<w;x+=step){ edges.push([x,0]); edges.push([x,h]); }
      for(let y=0;y<h;y+=step){ edges.push([0,y]); edges.push([w,y]); }

      const bolts = 5 + Math.floor(Math.random()*4);
      for(let b=0;b<bolts;b++){
        const a = edges[(Math.random()*edges.length)|0];
        const target = edges[(Math.random()*edges.length)|0];

        // GLOW pass
        lctx.beginPath();
        lctx.moveTo(a[0],a[1]);
        drawBolt(a[0],a[1],target[0],target[1],80,4);
        lctx.strokeStyle = `rgba(255,165,0,${0.35*alpha})`;
        lctx.lineWidth = 8;
        lctx.shadowColor = 'rgba(240,90,40,0.9)';
        lctx.shadowBlur = 18;
        lctx.stroke();

        // STROKE pass
        lctx.beginPath();
        lctx.moveTo(a[0],a[1]);
        drawBolt(a[0],a[1],target[0],target[1],60,3);
        lctx.strokeStyle = `rgba(240,90,40,${0.9*alpha})`;
        lctx.lineWidth = 2.5;
        lctx.shadowBlur = 10;
        lctx.stroke();

        // CORE pass
        lctx.beginPath();
        lctx.moveTo(a[0],a[1]);
        drawBolt(a[0],a[1],target[0],target[1],40,3);
        lctx.strokeStyle = `rgba(255,240,220,${0.95*alpha})`;
        lctx.lineWidth = 1;
        lctx.shadowBlur = 4;
        lctx.stroke();
      }
      requestAnimationFrame(frame);
    }
    requestAnimationFrame(frame);
  }

  // ========== QUESTION RENDER ==========
  function renderQuestion(i){
    const Q = QUESTIONS[i];
    qghost.textContent = pad(i+1);
    qnum.textContent = i+1;
    qcat.textContent = Q.cat;
    qtext.textContent = Q.q;
    qopts.innerHTML = '';
    Q.opts.forEach((o,oi)=>{
      const el = document.createElement('div');
      el.className = 'opt';
      el.innerHTML = `<span class="check"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3.5" stroke-linecap="round" stroke-linejoin="round" style="color:#fff"><path d="M5 12l5 5L20 7"/></svg></span><span>${o}</span>`;
      qopts.appendChild(el);
    });
    qCountEl.textContent = i+1;

    // animate-in
    cardWrap.classList.remove('out');
    cardWrap.classList.remove('in');
    card.classList.remove('in');
    qmeta.classList.remove('in');
    Array.from(qopts.children).forEach(c=>c.classList.remove('in'));

    void cardWrap.offsetWidth;
    cardWrap.classList.add('in');
    card.classList.add('in');
    qmeta.classList.add('in');
    Array.from(qopts.children).forEach(c=>c.classList.add('in'));

    // ladder current
    segs.forEach((s,si)=>{
      s.classList.remove('now');
      if(si<i) s.classList.add('done');
      else s.classList.remove('done');
    });
    segs[i].classList.add('now');
  }

  async function runQuestion(i, runningScore){
    renderQuestion(i);
    card.classList.remove('answered');

    // 0 -> 4.5s: entrance + generous read time for question & all four options
    await wait(4500);

    // 4.5 -> 4.9s: quiet professional lock-in
    const optEls = Array.from(qopts.children);
    optEls[QUESTIONS[i].pick].classList.add('sel');
    await wait(400);
    card.classList.add('answered');

    const newScore = runningScore + QUESTIONS[i].score;
    setScore(newScore);
    setAnswered(i+1);

    // 4.9 -> 7.6s: sit on the locked answer so viewer registers it
    await wait(2700);

    segs[i].classList.remove('now');
    segs[i].classList.add('done');

    // exit
    sweepSpeed();
    cardWrap.classList.remove('in');
    cardWrap.classList.add('out');
    await wait(500);

    return newScore;
  }

  // ========== RESULTS ==========
  function showResults(finalScore){
    runtime.classList.remove('show');
    results.classList.add('show');

    // ring animation
    const total = 40;
    const pct = Math.min(1, finalScore/total);
    const circum = 2*Math.PI*130; // ~816
    const target = circum - circum*pct;
    // start from full offset
    ringFill.style.strokeDashoffset = circum;
    // tick score
    setTimeout(()=>{
      tween(0,finalScore,1600,v=>{ ringScore.textContent = Math.round(v); });
      tween(circum,target,1600,v=>{ ringFill.style.strokeDashoffset = v; });
    }, 600);

    // ladder stages + continuous fill
    const stages = track.querySelectorAll('.ltr');
    const fill = document.getElementById('trackFill');
    setTimeout(()=>{ if(fill) fill.style.width = '62.5%'; }, 1400); // fill through center of 3rd of 4
    setTimeout(()=>stages[0].classList.add('on'), 1400);
    setTimeout(()=>stages[1].classList.add('on'), 1720);
    setTimeout(()=>{
      stages[2].classList.add('on');
      stages[2].classList.add('current');
    }, 2040);
  }

  // ========== MAIN TIMELINE ==========
  async function run(){
    // 0 - 7s intro: let the hero title breathe
    await wait(7000);
    sweepSpeed();
    intro.classList.add('hide');
    await wait(200);
    runtime.classList.add('show');

    let score = 0;
    for(let i=0;i<QUESTIONS.length;i++){
      score = await runQuestion(i, score);
    }

    // finale transition
    sweepSpeed();
    await wait(400);
    showResults(score);

    // optional loop (extended hold on final frame)
    if(new URLSearchParams(location.search).get('loop')==='1'){
      await wait(12000);
      location.reload();
    }
  }

  // kick off
  window.addEventListener('load', ()=>{ setTimeout(run, 120); });
})();
