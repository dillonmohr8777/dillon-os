// Background canvas: flowing data particles + drifting orbs
(function(){
  const c = document.getElementById('bgCanvas');
  const ctx = c.getContext('2d');
  let w=0,h=0,dpr=Math.min(window.devicePixelRatio||1,2);
  function resize(){
    w = c.clientWidth = window.innerWidth;
    h = c.clientHeight = window.innerHeight;
    c.width = w*dpr; c.height = h*dpr;
    ctx.setTransform(dpr,0,0,dpr,0,0);
  }
  resize();
  window.addEventListener('resize', resize);

  const GLYPHS = ['0','1','%','$','HCM','ROI','UKG','HR','KPI','ADP','SLA','★','▲','◆'];
  const particles = [];
  const N = Math.min(100, Math.floor(w*h/18000));
  for(let i=0;i<N;i++){
    particles.push({
      x: Math.random()*w,
      y: Math.random()*h,
      vy: -(0.15 + Math.random()*0.55),
      vx: (Math.random()-0.5)*0.12,
      g: GLYPHS[(Math.random()*GLYPHS.length)|0],
      s: 10 + Math.random()*16,
      a: 0.03 + Math.random()*0.14,
      hue: Math.random()<0.75 ? 18 : 32 // orangey
    });
  }

  const orbs = [
    {x:0.18,y:0.35,r:420,col:'rgba(240,90,40,.14)',vx:0.00008,vy:0.00005},
    {x:0.82,y:0.22,r:340,col:'rgba(255,107,53,.12)',vx:-0.00006,vy:0.00007},
    {x:0.65,y:0.78,r:460,col:'rgba(255,165,0,.10)',vx:0.00005,vy:-0.00006},
    {x:0.30,y:0.82,r:300,col:'rgba(201,74,32,.10)',vx:-0.00004,vy:-0.00008},
    {x:0.50,y:0.48,r:380,col:'rgba(255,230,200,.06)',vx:0.00003,vy:0.00004}
  ];

  let frame=0;
  function tick(){
    frame++;
    if(frame%2!==0){ requestAnimationFrame(tick); return; } // 30fps cap

    // base fill
    ctx.fillStyle = '#23232A';
    ctx.fillRect(0,0,w,h);

    // orbs
    for(const o of orbs){
      o.x += o.vx; o.y += o.vy;
      if(o.x<0||o.x>1) o.vx*=-1;
      if(o.y<0||o.y>1) o.vy*=-1;
      const g = ctx.createRadialGradient(o.x*w,o.y*h,0,o.x*w,o.y*h,o.r);
      g.addColorStop(0,o.col);
      g.addColorStop(1,'rgba(10,10,10,0)');
      ctx.fillStyle=g;
      ctx.fillRect(0,0,w,h);
    }

    // particles
    ctx.font = '';
    for(const p of particles){
      p.x += p.vx; p.y += p.vy;
      if(p.y < -20){ p.y = h + 20; p.x = Math.random()*w; }
      if(p.x < -20) p.x = w+20; if(p.x > w+20) p.x = -20;
      ctx.font = `${p.s}px 'Plus Jakarta Sans',sans-serif`;
      ctx.fillStyle = `rgba(${240+(p.hue-18)*0.8},${90+p.hue*1.2},${40+p.hue*0.4},${p.a})`;
      ctx.fillText(p.g, p.x, p.y);
    }

    requestAnimationFrame(tick);
  }
  requestAnimationFrame(tick);
})();
