// scenes.jsx — Align HCM cinematic motion graphic scenes

const ORANGE = '#FF6A13';
const ORANGE_BRIGHT = '#FF8A3D';
const ORANGE_DEEP = '#D94A00';
const INK = '#0A0B0D';
const INK_2 = '#121418';
const INK_3 = '#1A1D23';
const LINE = 'rgba(255,255,255,0.08)';
const LINE_2 = 'rgba(255,255,255,0.14)';
const TEXT = '#F5F5F7';
const DIM = 'rgba(245,245,247,0.58)';
const FAINT = 'rgba(245,245,247,0.32)';

const SANS = "'Space Grotesk', 'Inter', system-ui, sans-serif";
const MONO = "'JetBrains Mono', ui-monospace, monospace";

// ── BACKGROUND: animated grid + flowing data lines + particles ────────────

function FlowingBackground() {
  const t = useTime();

  // Generate static-ish particle field (seeded)
  const particles = React.useMemo(() => {
    const arr = [];
    for (let i = 0; i < 60; i++) {
      const seed = i * 9301 + 49297;
      const r1 = (seed % 233280) / 233280;
      const r2 = ((seed * 2) % 233280) / 233280;
      const r3 = ((seed * 7) % 233280) / 233280;
      arr.push({
        x: r1 * 1080,
        y: r2 * 1350,
        size: 1 + r3 * 2.5,
        speed: 0.3 + r3 * 0.8,
        phase: r1 * Math.PI * 2,
      });
    }
    return arr;
  }, []);

  return (
    <div style={{ position: 'absolute', inset: 0, overflow: 'hidden', background: INK }}>
      {/* Radial gradient glow */}
      <div style={{
        position: 'absolute', inset: 0,
        background: `radial-gradient(ellipse 80% 60% at 50% 40%, rgba(255,106,19,0.08), transparent 70%)`,
      }}/>

      {/* Subtle grid */}
      <svg width="1080" height="1350" style={{ position: 'absolute', inset: 0, opacity: 0.25 }}>
        <defs>
          <pattern id="grid" width="60" height="60" patternUnits="userSpaceOnUse">
            <path d="M 60 0 L 0 0 0 60" fill="none" stroke="rgba(255,255,255,0.04)" strokeWidth="1"/>
          </pattern>
          <pattern id="gridSmall" width="12" height="12" patternUnits="userSpaceOnUse">
            <path d="M 12 0 L 0 0 0 12" fill="none" stroke="rgba(255,255,255,0.02)" strokeWidth="0.5"/>
          </pattern>
        </defs>
        <rect width="1080" height="1350" fill="url(#gridSmall)"/>
        <rect width="1080" height="1350" fill="url(#grid)"/>
      </svg>

      {/* Flowing horizontal data lines */}
      <svg width="1080" height="1350" style={{ position: 'absolute', inset: 0 }}>
        {[0, 1, 2, 3, 4, 5].map(i => {
          const y = 150 + i * 200 + Math.sin(t * 0.5 + i) * 8;
          const offset = ((t * (40 + i * 15)) % 1400) - 200;
          return (
            <g key={i}>
              <line x1={0} y1={y} x2={1080} y2={y}
                stroke="rgba(255,255,255,0.04)" strokeWidth="1"/>
              <line
                x1={offset} y1={y}
                x2={offset + 180} y2={y}
                stroke={ORANGE}
                strokeWidth="1.5"
                opacity={0.5}
                style={{ filter: 'blur(0.5px)' }}
              />
              <circle cx={offset + 180} cy={y} r="3" fill={ORANGE_BRIGHT} opacity="0.9"/>
            </g>
          );
        })}
      </svg>

      {/* Waveform at bottom */}
      <svg width="1080" height="1350" style={{ position: 'absolute', inset: 0, opacity: 0.4 }}>
        <path
          d={(() => {
            let d = 'M 0 1200';
            for (let x = 0; x <= 1080; x += 10) {
              const y = 1200 + Math.sin(x * 0.015 + t * 2) * 12 + Math.sin(x * 0.04 + t * 3) * 6;
              d += ` L ${x} ${y}`;
            }
            return d;
          })()}
          stroke={ORANGE}
          strokeWidth="1.5"
          fill="none"
          opacity="0.6"
        />
        <path
          d={(() => {
            let d = 'M 0 1240';
            for (let x = 0; x <= 1080; x += 10) {
              const y = 1240 + Math.sin(x * 0.02 + t * 1.5 + 1) * 8 + Math.cos(x * 0.05 + t * 2) * 4;
              d += ` L ${x} ${y}`;
            }
            return d;
          })()}
          stroke={ORANGE}
          strokeWidth="1"
          fill="none"
          opacity="0.3"
        />
      </svg>

      {/* Particles */}
      <svg width="1080" height="1350" style={{ position: 'absolute', inset: 0 }}>
        {particles.map((p, i) => {
          const yOff = ((t * p.speed * 30) % 1400);
          const y = (p.y - yOff + 1350) % 1350;
          const pulse = 0.3 + 0.7 * Math.abs(Math.sin(t * 2 + p.phase));
          return (
            <circle
              key={i}
              cx={p.x}
              cy={y}
              r={p.size}
              fill={i % 5 === 0 ? ORANGE_BRIGHT : '#fff'}
              opacity={pulse * (i % 5 === 0 ? 0.8 : 0.3)}
            />
          );
        })}
      </svg>

      {/* Vignette */}
      <div style={{
        position: 'absolute', inset: 0,
        background: 'radial-gradient(ellipse 100% 100% at 50% 50%, transparent 40%, rgba(0,0,0,0.6) 100%)',
        pointerEvents: 'none',
      }}/>

      {/* Subtle scan line */}
      <div style={{
        position: 'absolute', left: 0, right: 0,
        top: ((t * 80) % 1400) - 50,
        height: 120,
        background: 'linear-gradient(to bottom, transparent, rgba(255,106,19,0.04), transparent)',
        pointerEvents: 'none',
      }}/>
    </div>
  );
}

// ── CHROME: header + footer that persist ──────────────────────────────────

function Chrome() {
  const t = useTime();
  const pulse = 0.6 + 0.4 * Math.sin(t * 3);
  return (
    <>
      {/* Top chrome */}
      <div style={{
        position: 'absolute', top: 0, left: 0, right: 0,
        padding: '36px 48px',
        display: 'flex', justifyContent: 'space-between', alignItems: 'center',
        zIndex: 50,
      }}>
        <img src="align-logo.png" alt="Align Human Capital Management"
          style={{ height: 110, width: 'auto', display: 'block' }}/>

        <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
          <div style={{
            width: 10, height: 10, borderRadius: '50%',
            background: ORANGE,
            boxShadow: `0 0 ${8 + pulse * 8}px ${ORANGE}`,
            opacity: pulse,
          }}/>
          <div style={{
            fontFamily: MONO, fontSize: 16, color: TEXT, fontWeight: 700,
            letterSpacing: '0.12em', textTransform: 'uppercase',
          }}>
            LIVE // HCM AUDIT
          </div>
        </div>
      </div>

      {/* Bottom chrome */}
      <div style={{
        position: 'absolute', bottom: 0, left: 0, right: 0,
        padding: '28px 48px',
        display: 'flex', justifyContent: 'space-between', alignItems: 'center',
        zIndex: 50,
        fontFamily: MONO, fontSize: 14, color: TEXT, fontWeight: 600,
        letterSpacing: '0.15em', textTransform: 'uppercase',
      }}>
        <div>SYSTEM / UTIL / V3.2</div>
        <div style={{ display: 'flex', gap: 20 }}>
          <span style={{ color: ORANGE }}>● STREAM</span>
          <span>SIG {Math.floor(70 + Math.sin(t * 2) * 20)}%</span>
        </div>
      </div>
    </>
  );
}

// ── SCENE 1: Hook — "Are you getting your money's worth?" (0–2.5s) ────────

function Scene1_Hook() {
  const { localTime, duration } = useSprite();
  const exit = duration - 0.6;

  // Pulse expansion
  const pulseRadius = interpolate([0, 0.6, 1.8], [0, 400, 900], Easing.easeOutQuart)(localTime);
  const pulseOpacity = interpolate([0, 0.3, 0.8, 1.8], [0, 1, 0.6, 0], Easing.linear)(localTime);

  // Title fade with tiny glitch
  const titleOp = interpolate([0.5, 1.0, exit, duration], [0, 1, 1, 0], Easing.easeOutCubic)(localTime);
  const titleY = interpolate([0.5, 1.1], [20, 0], Easing.easeOutCubic)(localTime);

  const glitchActive = localTime < 1.3;
  const glitchX = glitchActive ? (Math.random() - 0.5) * 3 : 0;

  // Subtitle
  const subOp = interpolate([1.1, 1.5, exit, duration], [0, 1, 1, 0])(localTime);

  return (
    <div style={{ position: 'absolute', inset: 0 }}>
      {/* Pulse rings */}
      <svg width="1080" height="1350" style={{ position: 'absolute', inset: 0 }}>
        <circle cx="540" cy="675" r={pulseRadius}
          fill="none" stroke={ORANGE} strokeWidth="2" opacity={pulseOpacity}/>
        <circle cx="540" cy="675" r={pulseRadius * 0.7}
          fill="none" stroke={ORANGE} strokeWidth="1" opacity={pulseOpacity * 0.5}/>
        <circle cx="540" cy="675" r={pulseRadius * 0.4}
          fill={ORANGE} opacity={pulseOpacity * 0.08}/>
      </svg>

      {/* Central title */}
      <div style={{
        position: 'absolute', inset: 0,
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        flexDirection: 'column', gap: 28,
        padding: '0 80px',
      }}>
        <div style={{
          fontFamily: MONO, fontSize: 18, color: ORANGE, fontWeight: 700,
          letterSpacing: '0.3em', textTransform: 'uppercase',
          opacity: subOp,
          display: 'flex', alignItems: 'center', gap: 14,
        }}>
          <span style={{
            display: 'inline-block', width: 32, height: 2, background: ORANGE,
          }}/>
          DIAGNOSTIC INITIATED
          <span style={{
            display: 'inline-block', width: 32, height: 2, background: ORANGE,
          }}/>
        </div>

        <h1 style={{
          fontFamily: SANS,
          fontSize: 84,
          fontWeight: 700,
          color: TEXT,
          textAlign: 'center',
          lineHeight: 1.02,
          letterSpacing: '-0.03em',
          margin: 0,
          opacity: titleOp,
          transform: `translate(${glitchX}px, ${titleY}px)`,
          textShadow: glitchActive
            ? `2px 0 ${ORANGE}, -2px 0 #0ff`
            : 'none',
        }}>
          Are you getting<br/>
          your <span style={{ color: ORANGE, fontStyle: 'italic' }}>money's worth</span><br/>
          out of your HCM?
        </h1>
      </div>
    </div>
  );
}

// ── SCENE 2: Tension — renewal cadence (2.5–5.5s) ─────────────────────────

function Scene2_Tension() {
  const { localTime, duration } = useSprite();
  const exit = duration - 0.6;

  const textOp1 = interpolate([0.1, 0.6, exit, duration], [0, 1, 1, 0])(localTime);
  const textOp2 = interpolate([0.7, 1.2, exit, duration], [0, 1, 1, 0])(localTime);

  // Timeline progression
  const barProgress = interpolate([1.3, 4.0], [0, 1], Easing.easeInOutCubic)(localTime);
  const barOp = interpolate([1.1, 1.4, exit, duration], [0, 1, 1, 0])(localTime);

  return (
    <div style={{ position: 'absolute', inset: 0, padding: '180px 80px' }}>
      {/* Label */}
      <div style={{
        fontFamily: MONO, fontSize: 18, color: ORANGE, fontWeight: 700,
        letterSpacing: '0.25em', textTransform: 'uppercase',
        opacity: textOp1, marginBottom: 28,
      }}>
        OBSERVATION // 01
      </div>

      {/* Main copy */}
      <div style={{
        fontFamily: SANS, fontSize: 52, fontWeight: 600, color: TEXT,
        lineHeight: 1.15, letterSpacing: '-0.025em',
        opacity: textOp1, marginBottom: 24,
      }}>
        Most organizations <span style={{ color: ORANGE }}>renew</span><br/>
        their HCM every 3 years.
      </div>

      <div style={{
        fontFamily: SANS, fontSize: 36, fontWeight: 600, color: TEXT,
        lineHeight: 1.3, letterSpacing: '-0.015em',
        opacity: textOp2, marginBottom: 80,
      }}>
        Very few stop to ask<br/>
        what they're actually using.
      </div>

      {/* Timeline visualization */}
      <div style={{ opacity: barOp, marginTop: 40 }}>
        <div style={{
          display: 'flex', justifyContent: 'space-between',
          fontFamily: MONO, fontSize: 18, color: TEXT, fontWeight: 700,
          letterSpacing: '0.15em', marginBottom: 20,
          textTransform: 'uppercase',
        }}>
          <span>Y1 · GO-LIVE</span>
          <span>Y2 · ADOPTION</span>
          <span style={{ color: ORANGE }}>Y3 · RENEW</span>
        </div>

        <div style={{
          position: 'relative', height: 12,
          background: 'rgba(255,255,255,0.06)',
          borderRadius: 6, border: `1px solid ${LINE}`,
        }}>
          <div style={{
            position: 'absolute', left: 0, top: 0, bottom: 0,
            width: `${barProgress * 100}%`,
            background: `linear-gradient(90deg, ${ORANGE_DEEP}, ${ORANGE}, ${ORANGE_BRIGHT})`,
            borderRadius: 6,
            boxShadow: `0 0 20px ${ORANGE}66`,
          }}/>
          {/* Year ticks */}
          {[0.333, 0.666, 1.0].map((pos, i) => (
            <div key={i} style={{
              position: 'absolute', left: `${pos * 100}%`, top: -8, bottom: -8,
              width: 2, background: i === 2 ? ORANGE : LINE_2,
              transform: 'translateX(-1px)',
            }}/>
          ))}
          {/* Traveling head */}
          {barProgress > 0.02 && barProgress < 1 && (
            <div style={{
              position: 'absolute',
              left: `${barProgress * 100}%`, top: '50%',
              width: 18, height: 18,
              marginLeft: -9, marginTop: -9,
              background: '#fff',
              borderRadius: '50%',
              boxShadow: `0 0 24px ${ORANGE}, 0 0 4px #fff`,
            }}/>
          )}
        </div>

        {/* Warning flickers below bar */}
        <div style={{
          display: 'flex', gap: 12, marginTop: 28, flexWrap: 'wrap',
          fontFamily: MONO, fontSize: 16, fontWeight: 700, letterSpacing: '0.1em',
          textTransform: 'uppercase',
        }}>
          {[
            { t: 0.4, label: 'cost drift' },
            { t: 0.6, label: 'unused modules' },
            { t: 0.85, label: 'renewal due' },
          ].map((w, i) => {
            const show = barProgress > w.t;
            const flicker = show ? (0.5 + 0.5 * Math.sin(localTime * 8 + i)) : 0;
            return (
              <div key={i} style={{
                padding: '10px 14px',
                border: `1.5px solid ${ORANGE}`,
                color: ORANGE,
                background: `rgba(255,106,19,${0.08 + flicker * 0.12})`,
                opacity: show ? 0.6 + flicker * 0.4 : 0,
                transform: `translateY(${show ? 0 : 8}px)`,
                transition: 'opacity 120ms',
                borderRadius: 4,
              }}>
                ⚠ {w.label}
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}

// ── SCENE 3: Problem — 5 failing indicators (5.5–10s) ─────────────────────

function Scene3_Problems() {
  const { localTime, duration } = useSprite();
  const exit = duration - 0.6;

  const headerOp = interpolate([0.1, 0.5, exit, duration], [0, 1, 1, 0])(localTime);

  const indicators = [
    { label: 'Manual Workflows', value: '+38%', type: 'rising', delay: 0.3 },
    { label: 'Payroll Exceptions', value: '147', type: 'alert', delay: 0.55 },
    { label: 'Report Accuracy', value: '62%', type: 'dropping', delay: 0.8 },
    { label: 'Workflow Alignment', value: 'BROKEN', type: 'broken', delay: 1.05 },
    { label: 'Shadow Spreadsheets', value: '24 FILES', type: 'outside', delay: 1.3 },
  ];

  return (
    <div style={{ position: 'absolute', inset: 0, padding: '140px 60px 160px' }}>
      {/* Header */}
      <div style={{ opacity: headerOp, marginBottom: 36 }}>
        <div style={{
          fontFamily: MONO, fontSize: 18, color: ORANGE, fontWeight: 700,
          letterSpacing: '0.25em', textTransform: 'uppercase',
          marginBottom: 16,
          display: 'flex', alignItems: 'center', gap: 14,
        }}>
          <span style={{ display: 'inline-block', width: 12, height: 12,
            background: ORANGE, borderRadius: '50%',
            boxShadow: `0 0 12px ${ORANGE}`,
          }}/>
          SYSTEM SCAN // 5 ANOMALIES DETECTED
        </div>
        <div style={{
          fontFamily: SANS, fontSize: 44, fontWeight: 700,
          color: TEXT, letterSpacing: '-0.025em', lineHeight: 1.1,
        }}>
          Where value <span style={{ color: ORANGE }}>quietly leaks</span>.
        </div>
      </div>

      {/* Indicator panels */}
      <div style={{
        display: 'grid',
        gridTemplateColumns: '1fr 1fr',
        gap: 16,
      }}>
        {indicators.slice(0, 4).map((ind, i) => (
          <IndicatorPanel key={i} {...ind} localTime={localTime}/>
        ))}
        {/* 5th spans both columns */}
        <div style={{ gridColumn: 'span 2' }}>
          <IndicatorPanel {...indicators[4]} localTime={localTime} wide/>
        </div>
      </div>

      {/* Footnote */}
      <div style={{
        position: 'absolute', bottom: 110, left: 60, right: 60,
        opacity: interpolate([3.0, 3.4, exit, duration], [0, 1, 1, 0])(localTime),
        fontFamily: SANS, fontSize: 28, fontWeight: 600,
        color: TEXT, lineHeight: 1.3, letterSpacing: '-0.015em',
      }}>
        If your team is still doing manual work your<br/>
        system should be handling, <span style={{ color: ORANGE, fontWeight: 700 }}>you're leaving value on the table.</span>
      </div>
    </div>
  );
}

function IndicatorPanel({ label, value, type, delay, localTime, wide }) {
  const panelOp = interpolate([delay, delay + 0.4], [0, 1], Easing.easeOutCubic)(localTime);
  const panelY = interpolate([delay, delay + 0.4], [16, 0], Easing.easeOutCubic)(localTime);
  const active = localTime > delay + 0.3;
  const pulse = active ? 0.5 + 0.5 * Math.sin((localTime - delay) * 6) : 0;

  // Per-type visualization
  let viz;
  if (type === 'rising') {
    const barH = active ? interpolate([delay + 0.3, delay + 0.9], [0, 1], Easing.easeOutCubic)(localTime) : 0;
    viz = (
      <svg width="100%" height="56" viewBox="0 0 200 56">
        {[0,1,2,3,4,5,6,7].map(i => {
          const h = (12 + i * 5) * barH;
          return <rect key={i} x={i*25+4} y={56-h} width={18} height={h}
            fill={i > 4 ? ORANGE : ORANGE_DEEP} opacity={i > 4 ? 0.9 : 0.5}/>;
        })}
      </svg>
    );
  } else if (type === 'alert') {
    viz = (
      <div style={{ display: 'flex', gap: 4, alignItems: 'flex-end', height: 56 }}>
        {[...Array(16)].map((_, i) => {
          const h = 8 + Math.abs(Math.sin(localTime * 3 + i)) * (i === 10 ? 46 : 20);
          const isAlert = i === 10;
          return <div key={i} style={{
            width: 8, height: h,
            background: isAlert ? ORANGE : 'rgba(255,255,255,0.2)',
            boxShadow: isAlert ? `0 0 ${8 + pulse * 8}px ${ORANGE}` : 'none',
          }}/>;
        })}
      </div>
    );
  } else if (type === 'dropping') {
    // Gauge arc
    const fill = active ? 0.62 : 0;
    const angle = -90 + fill * 180;
    return (
      <div style={{
        background: `linear-gradient(135deg, ${INK_3}, ${INK_2})`,
        border: `1px solid ${ORANGE}33`,
        borderRadius: 14,
        padding: 20,
        opacity: panelOp,
        transform: `translateY(${panelY}px)`,
        backdropFilter: 'blur(8px)',
        position: 'relative', overflow: 'hidden',
      }}>
        <div style={{
          position: 'absolute', top: 12, right: 12,
          width: 6, height: 6, borderRadius: '50%',
          background: ORANGE, boxShadow: `0 0 8px ${ORANGE}`,
          opacity: 0.5 + pulse * 0.5,
        }}/>
        <div style={{ fontFamily: MONO, fontSize: 15, color: TEXT, fontWeight: 700, letterSpacing: '0.15em', textTransform: 'uppercase', marginBottom: 12 }}>{label}</div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 14 }}>
          <svg width="70" height="44" viewBox="0 0 70 44">
            <path d="M 8 40 A 28 28 0 0 1 62 40" fill="none" stroke="rgba(255,255,255,0.1)" strokeWidth="6" strokeLinecap="round"/>
            <path d="M 8 40 A 28 28 0 0 1 62 40" fill="none" stroke={ORANGE} strokeWidth="6" strokeLinecap="round"
              strokeDasharray="88" strokeDashoffset={88 * (1 - fill)}
              style={{ transition: 'stroke-dashoffset 400ms' }}/>
            <line x1="35" y1="40" x2={35 + Math.cos(angle * Math.PI/180) * 22} y2={40 + Math.sin(angle * Math.PI/180) * 22}
              stroke="#fff" strokeWidth="2" strokeLinecap="round"/>
            <circle cx="35" cy="40" r="3" fill="#fff"/>
          </svg>
          <div style={{ fontFamily: SANS, fontSize: 38, fontWeight: 800, color: ORANGE, letterSpacing: '-0.02em' }}>
            {value} <span style={{ fontSize: 20, color: TEXT, fontWeight: 700 }}>↓</span>
          </div>
        </div>
      </div>
    );
  } else if (type === 'broken') {
    viz = (
      <svg width="100%" height="56" viewBox="0 0 200 56">
        {/* Two disconnected line segments with jagged break */}
        <line x1="4" y1="28" x2="80" y2="28" stroke={ORANGE} strokeWidth="2"/>
        <circle cx="4" cy="28" r="3" fill={ORANGE}/>
        <circle cx="80" cy="28" r="4" fill={ORANGE}/>
        {/* Jag */}
        <path d="M 80 28 L 92 22 L 96 32 L 104 24 L 110 32" stroke={ORANGE} strokeWidth="2" fill="none"
          opacity={0.6 + pulse * 0.4}/>
        {/* Broken side */}
        <line x1="120" y1="28" x2="196" y2="28" stroke="rgba(255,255,255,0.25)" strokeWidth="2" strokeDasharray="4 4"/>
        <circle cx="120" cy="28" r="4" fill="rgba(255,255,255,0.4)"/>
        <circle cx="196" cy="28" r="3" fill="rgba(255,255,255,0.4)"/>
      </svg>
    );
  } else if (type === 'outside') {
    return (
      <div style={{
        background: `linear-gradient(135deg, ${INK_3}, ${INK_2})`,
        border: `1px solid ${ORANGE}33`,
        borderRadius: 14,
        padding: 20,
        opacity: panelOp,
        transform: `translateY(${panelY}px)`,
        backdropFilter: 'blur(8px)',
        position: 'relative', overflow: 'hidden',
      }}>
        <div style={{ fontFamily: MONO, fontSize: 15, color: TEXT, fontWeight: 700, letterSpacing: '0.15em', textTransform: 'uppercase', marginBottom: 12 }}>{label}</div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 16, justifyContent: 'space-between' }}>
          <div style={{ fontFamily: SANS, fontSize: 38, fontWeight: 800, color: ORANGE, letterSpacing: '-0.02em' }}>
            {value}
          </div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, flex: 1, marginLeft: 20 }}>
            {/* System boundary */}
            <div style={{
              flex: 1, height: 40,
              border: `1.5px dashed ${LINE_2}`,
              borderRadius: 6,
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              fontFamily: MONO, fontSize: 13, color: TEXT, fontWeight: 700, letterSpacing: '0.15em',
              textTransform: 'uppercase',
            }}>SYSTEM</div>
            {/* Spreadsheets floating outside */}
            <div style={{ display: 'flex', gap: 3 }}>
              {[0,1,2,3,4].map(i => {
                const drift = Math.sin(localTime * 2 + i) * 3;
                return (
                  <div key={i} style={{
                    width: 16, height: 22,
                    background: 'rgba(255,255,255,0.12)',
                    border: `1px solid ${ORANGE}66`,
                    borderRadius: 2,
                    transform: `translateY(${drift}px) rotate(${(i-2)*3}deg)`,
                    display: 'flex', flexDirection: 'column', gap: 2, padding: 3,
                  }}>
                    <div style={{ height: 1, background: ORANGE, opacity: 0.7 }}/>
                    <div style={{ height: 1, background: 'rgba(255,255,255,0.3)' }}/>
                    <div style={{ height: 1, background: 'rgba(255,255,255,0.3)' }}/>
                    <div style={{ height: 1, background: 'rgba(255,255,255,0.3)' }}/>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div style={{
      background: `linear-gradient(135deg, ${INK_3}, ${INK_2})`,
      border: `1px solid ${ORANGE}33`,
      borderRadius: 14,
      padding: 20,
      opacity: panelOp,
      transform: `translateY(${panelY}px)`,
      backdropFilter: 'blur(8px)',
      position: 'relative', overflow: 'hidden',
    }}>
      {/* Corner pulse dot */}
      <div style={{
        position: 'absolute', top: 12, right: 12,
        width: 6, height: 6, borderRadius: '50%',
        background: ORANGE, boxShadow: `0 0 8px ${ORANGE}`,
        opacity: 0.5 + pulse * 0.5,
      }}/>
      <div style={{ fontFamily: MONO, fontSize: 15, color: TEXT, fontWeight: 700, letterSpacing: '0.15em', textTransform: 'uppercase', marginBottom: 12 }}>
        {label}
      </div>
      <div style={{
        fontFamily: SANS, fontSize: 38, fontWeight: 800, color: ORANGE,
        letterSpacing: '-0.02em', marginBottom: 12,
      }}>
        {value}
      </div>
      {viz}
    </div>
  );
}

// ── SCENE 4: Transformation — SmartCare activates (10–12.5s) ──────────────

function Scene4_Transformation() {
  const { localTime, duration } = useSprite();
  const exit = duration - 0.6;

  // Sweep across
  const sweepX = interpolate([0, 0.9], [-300, 1400], Easing.easeInOutCubic)(localTime);
  const sweepOp = interpolate([0, 0.2, 0.7, 0.9], [0, 1, 1, 0])(localTime);

  const headerOp = interpolate([0.8, 1.2, exit, duration], [0, 1, 1, 0])(localTime);
  const smartcareOp = interpolate([1.1, 1.5, exit, duration], [0, 1, 1, 0])(localTime);

  const metrics = [
    { label: 'AUTOMATION', from: 42, to: 94, suffix: '%' },
    { label: 'ACCURACY', from: 62, to: 99, suffix: '%' },
    { label: 'CYCLE TIME', from: 12, to: 3, suffix: 'D', invert: true },
  ];

  return (
    <div style={{ position: 'absolute', inset: 0, padding: '180px 60px' }}>
      {/* Energy sweep */}
      <div style={{
        position: 'absolute', top: 0, bottom: 0,
        left: sweepX, width: 300,
        background: `linear-gradient(90deg, transparent, ${ORANGE}40, ${ORANGE}, ${ORANGE}40, transparent)`,
        opacity: sweepOp,
        filter: 'blur(2px)',
        pointerEvents: 'none',
      }}/>
      <div style={{
        position: 'absolute', top: 0, bottom: 0,
        left: sweepX + 140, width: 4,
        background: '#fff',
        opacity: sweepOp,
        boxShadow: `0 0 40px #fff, 0 0 80px ${ORANGE}`,
        pointerEvents: 'none',
      }}/>

      {/* Header */}
      <div style={{ opacity: headerOp, marginBottom: 48 }}>
        <div style={{
          fontFamily: MONO, fontSize: 18, color: ORANGE, fontWeight: 700,
          letterSpacing: '0.25em', textTransform: 'uppercase', marginBottom: 16,
        }}>
          OPTIMIZATION // ACTIVE
        </div>
        <div style={{
          fontFamily: SANS, fontSize: 52, fontWeight: 700,
          color: TEXT, letterSpacing: '-0.025em', lineHeight: 1.05,
        }}>
          System <span style={{ color: ORANGE }}>realigns</span>.<br/>
          Value returns.
        </div>
      </div>

      {/* SmartCare layer badge */}
      <div style={{
        opacity: smartcareOp,
        background: `linear-gradient(135deg, ${ORANGE}22, ${ORANGE}08)`,
        border: `1.5px solid ${ORANGE}`,
        borderRadius: 16,
        padding: '20px 24px',
        marginBottom: 32,
        position: 'relative', overflow: 'hidden',
        backdropFilter: 'blur(12px)',
      }}>
        <div style={{
          position: 'absolute', inset: 0,
          background: `radial-gradient(ellipse at ${50 + Math.sin(localTime*2)*30}% 50%, ${ORANGE}22, transparent 60%)`,
        }}/>
        <div style={{ position: 'relative', display: 'flex', alignItems: 'center', gap: 16 }}>
          <div style={{
            width: 40, height: 40, borderRadius: 10,
            background: ORANGE,
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            boxShadow: `0 0 24px ${ORANGE}`,
          }}>
            <svg width="22" height="22" viewBox="0 0 22 22">
              <path d="M11 2 L20 17 L2 17 Z" fill={INK} strokeLinejoin="round"/>
              <circle cx="11" cy="13" r="2.5" fill={ORANGE}/>
            </svg>
          </div>
          <div>
            <div style={{ fontFamily: MONO, fontSize: 15, color: ORANGE_BRIGHT, fontWeight: 700, letterSpacing: '0.2em', textTransform: 'uppercase' }}>
              LAYER ACTIVATED
            </div>
            <div style={{ fontFamily: SANS, fontSize: 32, fontWeight: 800, color: TEXT, letterSpacing: '-0.02em' }}>
              SmartCare<span style={{ color: ORANGE }}>™</span> Optimization
            </div>
          </div>
        </div>
      </div>

      {/* Metrics counting up */}
      <div style={{
        display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 14,
        opacity: smartcareOp,
      }}>
        {metrics.map((m, i) => {
          const countProg = interpolate([1.4 + i * 0.1, 2.1 + i * 0.1], [0, 1], Easing.easeOutCubic)(localTime);
          const val = Math.round(m.from + (m.to - m.from) * countProg);
          return (
            <div key={i} style={{
              background: INK_2,
              border: `1px solid ${ORANGE}44`,
              borderRadius: 12,
              padding: 16,
              position: 'relative', overflow: 'hidden',
            }}>
              <div style={{ fontFamily: MONO, fontSize: 14, color: TEXT, fontWeight: 700, letterSpacing: '0.2em', marginBottom: 10, textTransform: 'uppercase' }}>
                {m.label}
              </div>
              <div style={{ fontFamily: SANS, fontSize: 42, fontWeight: 800, color: TEXT, letterSpacing: '-0.02em' }}>
                {val}<span style={{ color: ORANGE, fontSize: 24 }}>{m.suffix}</span>
              </div>
              <div style={{ fontFamily: MONO, fontSize: 15, color: ORANGE, fontWeight: 700, marginTop: 6 }}>
                {m.invert ? '↓' : '↑'} {m.invert ? Math.round(((m.from - m.to) / m.from) * 100) : Math.round(((m.to - m.from) / m.from) * 100)}%
              </div>
            </div>
          );
        })}
      </div>

      {/* Flowing connection lines */}
      <svg width="100%" height="120" viewBox="0 0 960 120" style={{ marginTop: 24, opacity: smartcareOp }}>
        {[0,1,2,3,4].map(i => {
          const x1 = 60 + i * 210;
          const x2 = x1 + 210;
          const flow = ((localTime * 2 + i * 0.3) % 1);
          return (
            <g key={i}>
              <path d={`M ${x1} 60 Q ${(x1+x2)/2} 30 ${x2} 60`}
                stroke={ORANGE} strokeWidth="1.5" fill="none" opacity="0.3"/>
              <circle cx={x1 + (x2-x1) * flow}
                cy={60 + Math.sin(flow * Math.PI) * -30 + (1 - flow) * 0}
                r="4" fill={ORANGE}>
              </circle>
              <circle cx={x1} cy="60" r="5" fill={ORANGE}/>
            </g>
          );
        })}
      </svg>
    </div>
  );
}

// ── SCENE 5: CTA — 5 things / checklist (12.5–15s) ────────────────────────

function Scene5_CTA() {
  const { localTime, duration } = useSprite();
  const exit = duration - 0.6;

  const titleOp = interpolate([0.1, 0.6, exit, duration], [0, 1, 1, 0], Easing.easeOutCubic)(localTime);

  const items = [
    'Utilization of purchased modules',
    'Workflow vs. configuration debt',
    'Hidden payroll exceptions',
    'Reporting & data integrity',
    'Shadow spreadsheets & exports',
  ];

  return (
    <div style={{ position: 'absolute', inset: 0, padding: '160px 60px 160px' }}>
      <div style={{ opacity: titleOp, marginBottom: 32 }}>
        <div style={{
          fontFamily: MONO, fontSize: 18, color: ORANGE, fontWeight: 700,
          letterSpacing: '0.25em', textTransform: 'uppercase', marginBottom: 16,
        }}>
          CHECKLIST // PRE-RENEWAL
        </div>
        <div style={{
          fontFamily: SANS, fontSize: 54, fontWeight: 800,
          color: TEXT, letterSpacing: '-0.03em', lineHeight: 1.05,
        }}>
          5 things most teams<br/>
          <span style={{ color: ORANGE, fontStyle: 'italic' }}>don't check</span> before renewing.
        </div>
      </div>

      {/* Checklist */}
      <div style={{ display: 'flex', flexDirection: 'column', gap: 10, marginBottom: 36 }}>
        {items.map((item, i) => {
          const itemDelay = 0.7 + i * 0.13;
          const op = interpolate([itemDelay, itemDelay + 0.3], [0, 1], Easing.easeOutCubic)(localTime);
          const tx = interpolate([itemDelay, itemDelay + 0.3], [-16, 0], Easing.easeOutCubic)(localTime);
          const checked = localTime > itemDelay + 0.25;
          return (
            <div key={i} style={{
              display: 'flex', alignItems: 'center', gap: 16,
              padding: '16px 20px',
              background: 'rgba(255,255,255,0.03)',
              border: `1.5px solid ${checked ? ORANGE + '66' : LINE}`,
              borderRadius: 10,
              opacity: op,
              transform: `translateX(${tx}px)`,
              backdropFilter: 'blur(6px)',
            }}>
              <div style={{
                width: 30, height: 30, borderRadius: 7,
                border: `2px solid ${checked ? ORANGE : LINE_2}`,
                background: checked ? ORANGE : 'transparent',
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                transition: 'all 200ms',
                flexShrink: 0,
              }}>
                {checked && (
                  <svg width="18" height="18" viewBox="0 0 14 14">
                    <path d="M 3 7 L 6 10 L 11 4" stroke={INK} strokeWidth="2.8" fill="none" strokeLinecap="round" strokeLinejoin="round"/>
                  </svg>
                )}
              </div>
              <div style={{
                fontFamily: MONO, fontSize: 16, color: ORANGE, fontWeight: 700,
                letterSpacing: '0.15em', width: 32,
              }}>0{i+1}</div>
              <div style={{
                fontFamily: SANS, fontSize: 26, fontWeight: 700,
                color: checked ? TEXT : DIM, letterSpacing: '-0.015em',
                flex: 1,
              }}>
                {item}
              </div>
            </div>
          );
        })}
      </div>

      {/* CTA */}
      <div style={{
        opacity: interpolate([1.6, 2.0, exit, duration], [0, 1, 1, 0], Easing.easeOutCubic)(localTime),
        marginTop: 12,
      }}>
        <div style={{
          display: 'inline-flex', alignItems: 'center', gap: 14,
          padding: '20px 28px',
          background: ORANGE,
          borderRadius: 12,
          boxShadow: `0 0 40px ${ORANGE}66, 0 8px 32px rgba(0,0,0,0.4)`,
        }}>
          <div style={{
            fontFamily: SANS, fontSize: 28, fontWeight: 800, color: INK,
            letterSpacing: '-0.015em',
          }}>
            Book a 30-min HCM audit
          </div>
          <div style={{
            width: 32, height: 32, borderRadius: '50%',
            background: INK,
            display: 'flex', alignItems: 'center', justifyContent: 'center',
          }}>
            <svg width="14" height="14" viewBox="0 0 14 14">
              <path d="M 3 7 L 11 7 M 7 3 L 11 7 L 7 11" stroke={ORANGE} strokeWidth="2" fill="none" strokeLinecap="round" strokeLinejoin="round"/>
            </svg>
          </div>
        </div>
        <div style={{
          fontFamily: MONO, fontSize: 16, color: TEXT, fontWeight: 700,
          letterSpacing: '0.15em', textTransform: 'uppercase',
          marginTop: 18,
        }}>
          alignhcm.com / audit
        </div>
      </div>
    </div>
  );
}

// ── SCENE 6: Picket signs — "Align HCM helps you spot these" (16.8–22s) ───

function PicketSign({ number, label, x, y, rotation, delay, localTime, color = ORANGE, big = false }) {
  const appearProg = interpolate([delay, delay + 0.5], [0, 1], Easing.easeOutBack)(localTime);
  const sway = Math.sin(localTime * 1.8 + delay * 3) * 1.5;
  const scale = appearProg;
  const yDrop = (1 - appearProg) * -80;

  const w = big ? 280 : 230;
  const h = big ? 200 : 170;
  const stickH = big ? 220 : 180;

  return (
    <div style={{
      position: 'absolute',
      left: x, top: y,
      transform: `translate(-50%, 0) translateY(${yDrop}px) rotate(${rotation + sway}deg) scale(${scale})`,
      transformOrigin: 'center bottom',
      opacity: appearProg,
    }}>
      {/* Stick */}
      <div style={{
        position: 'absolute',
        left: '50%', top: h - 10,
        width: 10, height: stickH,
        marginLeft: -5,
        background: 'linear-gradient(90deg, #6b4a2a, #a6744a, #6b4a2a)',
        borderRadius: 2,
        boxShadow: '2px 0 4px rgba(0,0,0,0.4)',
      }}/>
      {/* Sign */}
      <div style={{
        width: w, height: h,
        background: '#fafaf5',
        border: `4px solid ${color}`,
        boxShadow: '0 12px 32px rgba(0,0,0,0.5), inset 0 0 0 2px #fff',
        display: 'flex', flexDirection: 'column',
        alignItems: 'center', justifyContent: 'center',
        padding: 14,
        position: 'relative',
      }}>
        {/* Tape corners */}
        <div style={{ position: 'absolute', top: -4, left: -4, width: 24, height: 14, background: 'rgba(255,200,80,0.85)', transform: 'rotate(-25deg)' }}/>
        <div style={{ position: 'absolute', top: -4, right: -4, width: 24, height: 14, background: 'rgba(255,200,80,0.85)', transform: 'rotate(25deg)' }}/>

        <div style={{
          fontFamily: SANS, fontSize: big ? 64 : 52, fontWeight: 900,
          color: color, lineHeight: 1, letterSpacing: '-0.04em',
          marginBottom: 8,
        }}>
          #{number}
        </div>
        <div style={{
          fontFamily: SANS, fontSize: big ? 20 : 16, fontWeight: 800,
          color: INK, textAlign: 'center', lineHeight: 1.1,
          letterSpacing: '-0.01em', textTransform: 'uppercase',
        }}>
          {label}
        </div>
      </div>
    </div>
  );
}

function Scene6_PicketSign() {
  const { localTime } = useSprite();

  const signs = [
    { n: 1, label: 'Manual\nWorkflows',   x: 180,  y: 320, rot: -8,  d: 0.1 },
    { n: 2, label: 'Payroll\nExceptions', x: 540,  y: 280, rot: 4,   d: 0.25, big: true },
    { n: 3, label: 'Report\nAccuracy',    x: 900,  y: 330, rot: 10,  d: 0.4 },
    { n: 4, label: 'Workflow\nMisalignment', x: 310, y: 620, rot: 6,  d: 0.55 },
    { n: 5, label: 'Shadow\nSpreadsheets', x: 770, y: 640, rot: -7, d: 0.7 },
  ];

  const headerOp = interpolate([1.4, 1.9], [0, 1], Easing.easeOutCubic)(localTime);
  const ctaOp = interpolate([2.6, 3.1], [0, 1], Easing.easeOutBack)(localTime);

  return (
    <div style={{ position: 'absolute', inset: 0 }}>
      {/* Signs */}
      {signs.map(s => (
        <PicketSign key={s.n} number={s.n} label={s.label}
          x={s.x} y={s.y} rotation={s.rot} delay={s.d}
          localTime={localTime} big={s.big}/>
      ))}

      {/* Bottom text block */}
      <div style={{
        position: 'absolute', left: 0, right: 0, bottom: 130,
        padding: '0 60px',
        display: 'flex', flexDirection: 'column', alignItems: 'center',
      }}>
        <div style={{
          fontFamily: MONO, fontSize: 18, color: ORANGE, fontWeight: 700,
          letterSpacing: '0.3em', textTransform: 'uppercase',
          opacity: headerOp, marginBottom: 18,
        }}>
          THE 5 SIGNS
        </div>
        <div style={{
          fontFamily: SANS, fontSize: 52, fontWeight: 800,
          color: TEXT, textAlign: 'center', lineHeight: 1.05,
          letterSpacing: '-0.03em',
          opacity: headerOp, marginBottom: 28,
          maxWidth: 900,
        }}>
          Align HCM helps you <span style={{ color: ORANGE, fontStyle: 'italic' }}>spot them</span><br/>
          before renewal hits.
        </div>

        {/* CTA button */}
        <div style={{
          opacity: ctaOp,
          transform: `scale(${0.9 + ctaOp * 0.1})`,
          display: 'inline-flex', alignItems: 'center', gap: 16,
          padding: '22px 32px',
          background: ORANGE,
          borderRadius: 14,
          boxShadow: `0 0 60px ${ORANGE}88, 0 12px 40px rgba(0,0,0,0.5)`,
        }}>
          <div style={{
            fontFamily: SANS, fontSize: 28, fontWeight: 800, color: INK,
            letterSpacing: '-0.015em',
          }}>
            Get your free HCM audit
          </div>
          <div style={{
            width: 36, height: 36, borderRadius: '50%',
            background: INK,
            display: 'flex', alignItems: 'center', justifyContent: 'center',
          }}>
            <svg width="16" height="16" viewBox="0 0 14 14">
              <path d="M 3 7 L 11 7 M 7 3 L 11 7 L 7 11" stroke={ORANGE} strokeWidth="2.2" fill="none" strokeLinecap="round" strokeLinejoin="round"/>
            </svg>
          </div>
        </div>
      </div>
    </div>
  );
}

// ── SCENE TIMING CONSTANTS ────────────────────────────────────────────────

const SCENE_1_START = 0.0;
const SCENE_1_END   = 7.0;
const SCENE_2_START = 7.0;
const SCENE_2_END   = 15.0;
const SCENE_3_START = 15.0;
const SCENE_3_END   = 25.0;
const SCENE_4_START = 25.0;
const SCENE_4_END   = 32.0;
const SCENE_5_START = 32.0;
const SCENE_5_END   = 40.0;
const SCENE_6_START = 40.0;
const SCENE_6_END   = 48.0;

// Timestamp watermark — updates data-screen-label every second for commenting
function TimestampWatermark() {
  const t = useTime();
  const sec = Math.floor(t);
  React.useEffect(() => {
    const root = document.querySelector('[data-video-root]');
    if (root) root.setAttribute('data-screen-label', `t=${sec.toFixed(0)}s`);
  }, [sec]);
  return null;
}

// ── MAIN COMPOSITION ──────────────────────────────────────────────────────

function AlignMotionGraphic() {
  return (
    <>
      <FlowingBackground/>
      <Chrome/>
      <Sprite start={SCENE_1_START} end={SCENE_1_END}>
        <Scene1_Hook/>
      </Sprite>
      <Sprite start={SCENE_2_START} end={SCENE_2_END}>
        <Scene2_Tension/>
      </Sprite>
      <Sprite start={SCENE_3_START} end={SCENE_3_END}>
        <Scene3_Problems/>
      </Sprite>
      <Sprite start={SCENE_4_START} end={SCENE_4_END}>
        <Scene4_Transformation/>
      </Sprite>
      <Sprite start={SCENE_5_START} end={SCENE_5_END}>
        <Scene5_CTA/>
      </Sprite>
      <Sprite start={SCENE_6_START} end={SCENE_6_END}>
        <Scene6_PicketSign/>
      </Sprite>
      <TimestampWatermark/>
    </>
  );
}

Object.assign(window, {
  AlignMotionGraphic,
  Scene1_Hook, Scene2_Tension, Scene3_Problems, Scene4_Transformation, Scene5_CTA, Scene6_PicketSign,
  FlowingBackground, Chrome,
  ORANGE, INK, TEXT, SANS, MONO,
});
